package com.americanexpress.acquisitions.services.address.client;


import com.americanexpress.acquisitions.commons.exceptions.core.AcquisitionServiceException;
import com.americanexpress.acquisitions.services.address.data.AddressValidationRequest;
import com.americanexpress.acquisitions.services.address.data.AddressValidationResponse;
import com.americanexpress.acquisitions.services.address.utils.AddressServiceUtil;

import com.address.web.QAAddressType;
import com.address.web.QAPortType;
import com.address.web.QASearchResult;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.legacy.PowerMockRunner;

/**
 * AddressValidationServiceImplTest
 *
 * @author 348842
 * @version $Id$
 */

public class AddressValidationServiceImplTest {
	AddressValidationServiceImpl serviceImpl = new AddressValidationServiceImpl();
	AddressValidationRequest addressValidationRequest=new AddressValidationRequest();
	AddressValidationResponse addressValidationResponse=new AddressValidationResponse();
	
	@Before
	public void beforeClass() {
		boolean test1=true;

		//QAPortType qasWService=new qasWService();
		//MockitoAnnotations.initMocks(this);
	}

	@Test (expected = IllegalStateException.class)
	public void testDoSearch() throws  Throwable {
		AddressValidationRequest addressValidationRequest = new AddressValidationRequest();
		String serviceURL = "http://qas.addrverify.ipc.us.aexp.com:2021/QAPortType";
		int timeout = 2000;
		serviceImpl.setTimeout(timeout);
		serviceImpl.setServiceUrl(serviceURL);
		addressValidationRequest.setAddress("1889 BROADWAY");
		addressValidationRequest.setCountry("USA");
		AddressValidationResponse addressValidationResponse;
		addressValidationResponse = serviceImpl.doSearch(addressValidationRequest);
		//Assert.assertNull(addressValidationResponse);		
	}
	
	@Test (expected = AcquisitionServiceException.class)
	public void testDoSearchThrowsASE2() throws  Throwable {
		AddressValidationRequest addressValidationRequest = new AddressValidationRequest();
		addressValidationRequest=null;
		String serviceURL = "http://qas.addrverify.ipc.us.aexp.com:2021/QAPortType";
		//serviceImpl.setServiceUrl(serviceURL);
		int timeout = 2000;
		serviceImpl.setTimeout(timeout);
		serviceImpl.setServiceUrl(serviceURL);
		serviceImpl.doSearch(addressValidationRequest);
	}	
	
	
	@Test (expected = AcquisitionServiceException.class)
	public void testDoSearchThrowsASE3() throws  Throwable {
		AddressValidationRequest addressValidationRequest = new AddressValidationRequest();
		String serviceURL = null;
		int timeout = 2000;
		serviceImpl.setTimeout(timeout);
		serviceImpl.setServiceUrl(serviceURL);
		serviceImpl.doSearch(addressValidationRequest);
	}	
	@Test (expected = IllegalStateException.class)
	public void testDoSearchThrowsASE4() throws  Throwable {
		AddressValidationRequest addressValidationRequest = new AddressValidationRequest();
		String serviceURL = "sdgsdfg";
		int timeout = 0;
		serviceImpl.setTimeout(timeout);
		addressValidationRequest.setAddress("1889 BROADWAY");
		addressValidationRequest.setCountry("USA");
		addressValidationResponse.setAddresJsonResponse(null);
		addressValidationResponse.setQaSearchResult(null);
		serviceImpl.setTimeout(timeout);
		serviceImpl.setServiceUrl(serviceURL);
		serviceImpl.doSearch(addressValidationRequest);
	}
	/*
	@Test
	public void testDoSearchThrowsASE5() throws  Throwable {
		AddressValidationRequest addressValidationRequest = new AddressValidationRequest();
		String serviceURL = "http://qas.addrverify.ipc.us.aexp.com:2021/QAPortType";
		int timeout = 2000;
		QAPortType qaPortType=PowerMock.createMock(QAPortType.class);
		AddressServiceUtil addressServiceUtil=PowerMock.createMock(AddressServiceUtil.class);
		serviceImpl.setTimeout(timeout);
		serviceImpl.setServiceUrl(serviceURL);
		serviceImpl.doSearch(addressValidationRequest);
	}*/
	/*	/*@Test
	//public void testDoSearchThrowsASE5() throws  Throwable {
		AddressValidationRequest addressValidationRequest = new AddressValidationRequest();
		AddressValidationResponse addressValidationResponse= createNiceMock(AddressValidationResponse.class);
		QASearchResult qasSearchResult=createNiceMock(QASearchResult.class);
		QAPicklistType qaPicklist=createNiceMock(QAPicklistType.class);
		QAAddressType qaAddress=createNiceMock(QAAddressType.class);
	//	expect(qaAddress.setDPVStatus("DPV_NOT_CONFIGURED")).andReturn(DPV_NOT_CONFIGURED);
		String serviceURL = "sdgsdfg";
		int timeout = 0;
		serviceImpl.setTimeout(timeout);
		addressValidationRequest.setAddress("1889 BROADWAY");
		addressValidationRequest.setCountry("USA");	
		
		addressValidationResponse.setAddresJsonResponse(null);
		addressValidationResponse.setQaSearchResult(null);
		serviceImpl.setTimeout(timeout);
		serviceImpl.setServiceUrl(serviceURL);
		serviceImpl.doSearch(addressValidationRequest);
	}*
	
/*	
	//@Mock private AddressValidationRequest addressValidationRequest;
	//@Mock private AddressValidationResponse addressValidationResponse;
	@Test (expectedExceptions = AcquisitionServiceException.class)
	public void testDoSearch1() throws  Throwable {
		addressValidationRequest.setAddress("1889 BROADWAY");
		addressValidationRequest.setCountry("UNITED STATES OF AMERICA");
		serviceImpl=new AddressValidationServiceImpl();
		serviceImpl.setServiceUrl("http://qas.addrverify.ipc.us.aexp.com:2021/QAPortType");
		addressValidationResponse=serviceImpl.doSearch(addressValidationRequest);
		//AssertionError
		//Assert.assertNotNull(addressValidationResponse);
		}
		*/
	
	@Test (expected = AcquisitionServiceException.class)
	public void testDoSearch2() throws  Throwable {
		addressValidationRequest.setAddress("1889 BROADWAY");
		addressValidationRequest.setCountry("UNITED STATES OF AMERICA");
		serviceImpl=new AddressValidationServiceImpl();
		serviceImpl.setServiceUrl(null);
		addressValidationResponse=serviceImpl.doSearch(addressValidationRequest);
		//AssertionError
		//Assert.assertNotNull(addressValidationResponse);
		}
	
	@Test(expected = IllegalStateException.class)
	public void testDoSearch3() throws  Throwable {
		serviceImpl=new AddressValidationServiceImpl();
		serviceImpl.setServiceUrl("http://qas.addrverify.ipc.us.aexp.com:2021/QAPortType");
		addressValidationRequest=new AddressValidationRequest();
		addressValidationRequest.setAddress("1889 BROADWAY");
		addressValidationRequest.setCountry("USA");
		addressValidationResponse=new AddressValidationResponse();
		Assert.assertNull(serviceImpl.doSearch(addressValidationRequest));
		//serviceImpl.doSearch(addressValidationRequest);
		Assert.assertNull(addressValidationResponse.getAddresJsonResponse());
	
		//QAPortType qasWService = AddressValidationSrvcEndPntLocator.getQASWService("http://qas.addrverify.ipc.us.aexp.com:2021/QAPortType", 2000);
		QASearchResult qasResult=new QASearchResult();
		QAAddressType qaaAddress=new QAAddressType();
		qaaAddress.setDPVStatus(null);
		qaaAddress.setMissingSubPremise(null);
		qaaAddress.setTruncated(null);
		qaaAddress.setMissingSubPremise(null);
		qasResult.setQAAddress(qaaAddress);
		qasResult.setQAPicklist(null);
		qasResult.setVerifyLevel(null);
		qasResult.setVerificationFlags(null); 
//		serviceImpl.doSearch(addressValidationRequest);
		//qasResult.setQAAddress(value)
		//serviceImpl=new AddressValidationServiceImpl();
	}
	
	@Test(expected = IllegalStateException.class)
	public void testDoSearch5() throws  Throwable {
		addressValidationRequest.setAddress("1889 BROADWAY");
		addressValidationRequest.setCountry("UNITED STATES OF AMERICA");
		serviceImpl=new AddressValidationServiceImpl();
		serviceImpl.setServiceUrl("http://qas.addrve.ipc.us.aexp.com:2021/QAPortType");
		addressValidationRequest.setAddress("1889 BROADWAY");
		addressValidationRequest.setCountry("USA");
		int timeout = 9;
		serviceImpl.setTimeout(timeout);
		addressValidationResponse=serviceImpl.doSearch(addressValidationRequest);
		//AssertionError
		//Assert.assertNotNull(addressValidationResponse);
		}
/*
	
	@Test (expectedExceptions = AcquisitionServiceException.class)
	public void testDoSearch4() throws  Throwable {
		addressValidationRequest.setAddress("cxcx");
		addressValidationRequest.setCountry("USA");
		serviceImpl=new AddressValidationServiceImpl();
		serviceImpl.setServiceUrl("http://qas.addrverify.ipc.us.aexp.com:2021/QAPortType");
		addressValidationResponse=serviceImpl.doSearch(addressValidationRequest);
		//AssertionError
		//Assert.assertNotNull(addressValidationResponse);
		}
	*/
}
