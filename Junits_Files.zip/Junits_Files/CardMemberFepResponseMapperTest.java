/*
 * -------------------------------------------------------------------------
 *
 * (C) Copyright / American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.
 *
 * -------------------------------------------------------------------------
 */

package com.americanexpress.acquisitions.open.web.Test;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.replay;
import static org.easymock.EasyMock.verify;
import static org.junit.Assert.assertEquals;
import com.americanexpress.acquisitions.open.web.shortapp.mappers.CardMemberFepResponseMapper;
import com.americanexpress.acquisitions.services.ccc.domain.AcquisitionResponse;
import com.americanexpress.acquisitions.services.ccc.domain.Status;
import static org.easymock.EasyMock.*;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;


/**
 * CardMemberFepResponseMapperTest
 *
 * @author 387142
 * @version $Id$
 */
public class CardMemberFepResponseMapperTest {
	Status status=null;
	String flowstatus=null;
	String flowType=null;
	
	@Before
	public void setUp() throws Exception {						
		 AcquisitionResponse acqResponse=EasyMock.createMock(AcquisitionResponse.class);
		//AcquisitionResponse acqResponse=new AcquisitionResponse();
		CardMemberFepResponseMapper cardMemberFepResponseMapper=new CardMemberFepResponseMapper(acqResponse);
	}
	@Test
	public void testgetAcqStatusTextSuccess(){
		AcquisitionResponse acqResponse=EasyMock.createMock(AcquisitionResponse.class);
		//AcquisitionResponse acqResponse=new AcquisitionResponse();
		CardMemberFepResponseMapper cardMemberFepResponseMapper=new CardMemberFepResponseMapper(acqResponse);		
	    status=acqResponse.getAcquisitionStatus();		
		expect(status.getStatusCode()).andReturn("00");
		expect(cardMemberFepResponseMapper.getAcqStatusText()).andReturn("SUCCESS");
		replay(cardMemberFepResponseMapper);		
		try{			
			cardMemberFepResponseMapper.getAcqStatusText();			
		}catch(RuntimeException e){
			e.printStackTrace();
		}
		assertEquals("Success",cardMemberFepResponseMapper.getAcqStatusText());
		verify(cardMemberFepResponseMapper);
	}
	
	/*@Test
	public void testgetAcqStatusTextFailure(){
		AcquisitionResponse acqResponse=createNiceMock(AcquisitionResponse.class);		
		CardMemberFepResponseMapper cardMemberFepResponseMapper=new CardMemberFepResponseMapper(acqResponse);
		Status status=acqResponse.getAcquisitionStatus();			
		expect(status.getStatusCode()).andReturn("23");
		expect(cardMemberFepResponseMapper.getAcqStatusText()).andReturn("FAILED");
		replay(cardMemberFepResponseMapper);		
		try{			
			cardMemberFepResponseMapper.getAcqStatusText();			
		}catch(RuntimeException e){
			e.printStackTrace();
		}
		assertEquals("Failed",cardMemberFepResponseMapper.getAcqStatusText());
		verify(cardMemberFepResponseMapper);
	}*/
	
	@Test
	public void testgetLoggedInPageAcqStatus(){
		AcquisitionResponse acqResponse=EasyMock.createMock(AcquisitionResponse.class);
		CardMemberFepResponseMapper cardMemberFepResponseMapper=new CardMemberFepResponseMapper(acqResponse);
		Status acquisitionStatus = acqResponse.getAcquisitionStatus();		
		String statusCode =acquisitionStatus.getStatusCode();
		expect(statusCode).andReturn("00");
		expect(acquisitionStatus).andReturn(status);
		replay(cardMemberFepResponseMapper);
		try{
			cardMemberFepResponseMapper.getLoggedInPageAcqStatus();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		assertEquals("SUCCESS",cardMemberFepResponseMapper.getLoggedInPageAcqStatus());
		verify(cardMemberFepResponseMapper);
	}
	
	@Test
	public void testgetDisplayLoginPagStatus(){		
		AcquisitionResponse acqResponse=EasyMock.createMock(AcquisitionResponse.class);
		CardMemberFepResponseMapper cardMemberFepResponseMapper=new CardMemberFepResponseMapper(acqResponse);
		Status acquisitionStatus = acqResponse.getAcquisitionStatus();
		String statusCode=acquisitionStatus.getStatusCode();
		expect(statusCode).andReturn("00");
		expect(flowstatus).andReturn("SUCCESS");
		replay(cardMemberFepResponseMapper);
		try{
			cardMemberFepResponseMapper.getDisplayLoginPagStatus(flowType);
		}catch(Exception e)
		{
		 e.printStackTrace();	
		}
		assertEquals("SUCCESS",cardMemberFepResponseMapper.getDisplayLoginPagStatus(flowType));
		verify(cardMemberFepResponseMapper);
	 }
}
