/*
 * -------------------------------------------------------------------------
 *
 * (C) Copyright / American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.
 *
 * -------------------------------------------------------------------------
 */

package com.americanexpress.acquisitions.open.web.Test;
import static org.easymock.EasyMock.*;
import static org.junit.Assert.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.americanexpress.acquisitions.open.web.shortapp.helpers.CardMemberHelper;
import org.apache.struts.action.ActionForm;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import static org.easymock.EasyMock.expect;

public class CardMemberHelperTest {
	
    public CardMemberHelper cardMemberHelper;   
    ActionForm form=null;
	HttpServletRequest request;
	HttpServletResponse response;   
    HttpSession session;      
	@Before
	public void setup() throws Exception {
		// NiceMocks return default values for
		// unimplemented methods		     	
     	request =EasyMock.createMock(HttpServletRequest.class);
        response = EasyMock.createMock(HttpServletResponse.class);      
        cardMemberHelper = new CardMemberHelper(form, request, response);			
		//EasyMock.replay();
	}
	
	@Test
	public void testisAlreadyLoggedinSuccess(){
		request =EasyMock.createMock(HttpServletRequest.class);		
		response =EasyMock.createMock(HttpServletResponse.class);		
		cardMemberHelper = new CardMemberHelper(form, request, response);				
		session = EasyMock.createMock(HttpSession.class);
		expect(request.getSession(true)).andReturn(session);
		//expect(cardMemberHelper.isAlreadyLoggedin()).andReturn(true);
		replay(cardMemberHelper);			
		try{			
			cardMemberHelper.isAlreadyLoggedin();			
		}catch(RuntimeException e){
			e.printStackTrace();
		}
		assertEquals(true,cardMemberHelper.isAlreadyLoggedin());
		verify(cardMemberHelper);		
		
   }
	
	/*@Test
	public void testIsAlreadyLoggedinFailure(){		
	    request =EasyMock.createMock(HttpServletRequest.class);		
	    response =EasyMock.createMock(HttpServletResponse.class);		
		cardMemberHelper = new CardMemberHelper(form, request, response);
		session = EasyMock.createMock(HttpSession.class);		
		expect(request.getSession(false)).andReturn(session);
		replay(cardMemberHelper);			
		try{			
			cardMemberHelper.isAlreadyLoggedin();			
		}catch(RuntimeException e){
			e.printStackTrace();
		}
		assertFalse(cardMemberHelper.isAlreadyLoggedin());
		verify(cardMemberHelper);
   }*/

}