/*
 * -------------------------------------------------------------------------
 *
 * (C) Copyright / American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.
 *
 * -------------------------------------------------------------------------
 */

package com.americanexpress.acquisitions.open.web.Test;

import static org.easymock.EasyMock.createNiceMock;
import static org.easymock.EasyMock.verify;
import static org.junit.Assert.assertEquals;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import static org.easymock.EasyMock.replay;
import com.americanexpress.acquisitions.open.commons.formbeans.LoginForm;
import com.americanexpress.acquisitions.open.web.shortapp.dto.CardMemberAppDTO;
import com.americanexpress.acquisitions.open.web.shortapp.helpers.CardMemberLoginHelper;
import com.americanexpress.acquisitions.services.ccc.domain.CardData;

import org.apache.struts.action.ActionForm;
import org.easymock.EasyMock;

import org.junit.Before;
import org.junit.Test;
import static org.easymock.EasyMock.*;

/**
 * CardMemberLoginHelperJTest
 *
 * @author 387142
 * @version $Id$
 */
public class CardMemberLoginHelperTest  {
	
	/**
	 * Test for method: CardMemberLoginHelper()
	 * @throws Throwable Tests may throw any Throwable
	 * @see CardMemberLoginHelper#CardMemberLoginHelper()
	 * @author 387142 
	 */
	@Before
	public void setUp() throws Exception {
		// NiceMocks return default values for
		// unimplemented methods		
		ActionForm form=createNiceMock(ActionForm.class);
		HttpServletRequest request = EasyMock.createMock(HttpServletRequest.class);
		HttpServletResponse response =EasyMock.createMock(HttpServletResponse.class);
		CardMemberLoginHelper cardMemberLoginHelper=new CardMemberLoginHelper(form,request,response);
	}
	
	@Test
	public void testvalidateUserLoginInfoTest1() throws Throwable{
		ActionForm form=createNiceMock(ActionForm.class);
		HttpServletRequest request = EasyMock.createMock(HttpServletRequest.class);
		HttpServletResponse response =EasyMock.createMock(HttpServletResponse.class);
		CardMemberLoginHelper cardMemberLoginHelper=new CardMemberLoginHelper(form,request,response);
		LoginForm	loginform =new LoginForm();		
		CardMemberAppDTO cardMemberAppDTO=new CardMemberAppDTO ();
		cardMemberAppDTO.setFlowType("shortNPA");
		cardMemberAppDTO.setStableAndSingleCard(true);		
		CardData cardData=new CardData();
		cardMemberAppDTO.setCardData(cardData);		
		expect("pageName").andReturn("applicationPage");
		replay(cardMemberLoginHelper);
		try{			
			cardMemberLoginHelper.validateUserLoginInfo(loginform);			
		}catch(RuntimeException e){
			e.printStackTrace();
		}
		assertEquals("userid",cardMemberLoginHelper.validateUserLoginInfo(loginform));
		verify(cardMemberLoginHelper);
	}
	
	@Test
	public void testvalidateUserLoginInfoTest2() throws Throwable{
		ActionForm form=createNiceMock(ActionForm.class);
		HttpServletRequest request = EasyMock.createMock(HttpServletRequest.class);
		HttpServletResponse response =EasyMock.createMock(HttpServletResponse.class);
		CardMemberLoginHelper cardMemberLoginHelper=new CardMemberLoginHelper(form,request,response);
		LoginForm	loginform =new LoginForm();		
		CardMemberAppDTO cardMemberAppDTO=new CardMemberAppDTO ();
		cardMemberAppDTO.setFlowType("shortNPA");
		cardMemberAppDTO.setStableAndSingleCard(true);		
		CardData cardData=new CardData();
		cardMemberAppDTO.setCardData(cardData);		
		expect("pageName").andReturn("cidPage");
		replay(cardMemberLoginHelper);
		try{			
			cardMemberLoginHelper.validateUserLoginInfo(loginform);			
		}catch(RuntimeException e){
			e.printStackTrace();
		}
		assertEquals("userid",cardMemberLoginHelper.validateUserLoginInfo(loginform));
		verify(cardMemberLoginHelper);
	}
		
}

