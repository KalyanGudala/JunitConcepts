package com.americanexpress.acquisitions.open.web.managers;

import javax.servlet.http.HttpServletRequest;

import com.americanexpress.acquisitions.commons.log.AcquisitionsLogger;
import com.americanexpress.acquisitions.commons.log.constants.Group;
import com.americanexpress.acquisitions.commons.traversepath.TraversePath;
import com.americanexpress.acquisitions.commons.traversepath.TraversePathConstants;
import com.americanexpress.acquisitions.commons.url.constants.URLConstants;
import com.americanexpress.acquisitions.open.commons.common.constants.OPENConstants;
import com.americanexpress.acquisitions.open.commons.formbeans.OSBNForm;
import com.americanexpress.acquisitions.open.commons.mapper.ResponseInterpretter;
import com.americanexpress.acquisitions.open.commons.mapper.constants.OPENMapperConstants;
import com.americanexpress.acquisitions.open.commons.util.data.DataBasket;
import com.americanexpress.acquisitions.services.ccc.domain.AcquisitionResponse;
import com.americanexpress.acquisitions.services.ccc.domain.FormData;
import com.americanexpress.acquisitions.services.ccc.domain.PricingFeature;
import com.americanexpress.acquisitions.services.ccc.domain.ProductRate;
import com.americanexpress.acquisitions.services.ccc.domain.Status;

/**
 * ApplicationPageResponseMapper
 * 
 * @author kalpana X Ramanaidu@aexp.com
 * @version $Id: ApplicationPageResponseMapper.java 28418 2013-10-31 10:45:09Z sgajula $
 */
public class ApplicationPageResponseMapper extends ResponseInterpretter {

	/** Property for logger **/
	private static final AcquisitionsLogger LOGGER = new AcquisitionsLogger(
			ApplicationPageResponseMapper.class);

	/** Property to hold ApplicationPageResponseMapper class name **/
	private static final String CLASS_APP_RESPONSE_MAPPER = "ApplicationPageResponseMapper";

	private String pageIdentifier;
	private HttpServletRequest httpRequest;
	protected Status acquisitionStatus = null;

	/**
	 * @param fepResponse
	 *            AcquisitionResponse
	 */
	public ApplicationPageResponseMapper(AcquisitionResponse fepResponse) {
		super(fepResponse);

	}

	/**
	 * @param fepResponse
	 *            AcquisitionResponse
	 * @param httpRequest
	 *            HttpServletRequest
	 */
	public ApplicationPageResponseMapper(AcquisitionResponse fepResponse,
			HttpServletRequest httpRequest) {
		super(fepResponse);
		this.httpRequest = httpRequest;
	}

	/**
	 * @param pageIdentifier
	 *            the pageIdentifier to set
	 */
	/**
	 * @return the pageIdentifier
	 */
	public String getPageIdentifier() {
		return pageIdentifier;
	}

	/** Property to hold updateDataBasket method name **/
	private static final String METHOD_UPDATE_DATABASKET = "updateDataBasket";

	/**
	 * @param dataBasket
	 *            DataBasket
	 * @return DataBasket
	 */

	public DataBasket updateDataBasket(DataBasket dataBasket) {

		LOGGER.entry(Group.OPEN, OPENMapperConstants.BUSINESS_UNIT);

		String componentName = CLASS_APP_RESPONSE_MAPPER + URLConstants.COLON
				+ METHOD_UPDATE_DATABASKET;

		// String variable tpathKey is used to hold traverse path start
		// component
		String tpathKey = TraversePath.startComponentCall(componentName);
		// String variable statusFlag is used to hold the flag("T"/"F") which
		// indicates if the traverse path component is successfully executed or
		// not
		String statusFlag = TraversePathConstants.TRAVERSE_PATH_FAILURE;
		// String variable statusDesc is used to hold the status description
		// which contains the message if the traverse path component is
		// successfully
		// executed or not

		String statusDesc = OPENMapperConstants.MAPPER_FAILURE;

		try {
			Status acqStatus = acquisitionResponse.getAcquisitionStatus();

			dataBasket.put("acqStatus", acqStatus);

			if (acquisitionResponse.getPricingFeature() != null) {
				PricingFeature pricingFeature = acquisitionResponse
						.getPricingFeature();
				dataBasket.put("pricingFeature", pricingFeature);
			}
			if (acquisitionResponse.getProductRate() != null) {
				ProductRate productRate = acquisitionResponse.getProductRate();
				dataBasket.put("productRate", productRate);
			}
			if (acquisitionResponse.getFormData() != null) {
				FormData formData = acquisitionResponse.getFormData();
				dataBasket.put("formData", formData);
			}

			/*
			 * DynamicOffersHelper objDynamicOffersHelper = new
			 * DynamicOffersHelper();
			 * 
			 * objDynamicOffersHelper.processOffers(httpRequest,
			 * acquisitionResponse);
			 * 
			 * Properties finaloffer = objDynamicOffersHelper.getFinaloffer();
			 * 
			 * dataBasket.put("finaloffer", finaloffer);
			 */

			statusFlag = TraversePathConstants.TRAVERSE_PATH_SUCCESS;
			statusDesc = OPENMapperConstants.MAPPER_SUCCESS;
		} finally {
			// Ending the traverse path component
			TraversePath.endComponentCall(tpathKey, componentName,
					OPENMapperConstants.PARSER_TRV_VERSION, statusFlag, 0,
					statusDesc);

			// LOGGER.debug(Group.OPEN, OPENMapperConstants.BUSINESS_UNIT,
			// "dataBasket: " + dataBasket);
			LOGGER.exit(Group.OPEN, OPENMapperConstants.BUSINESS_UNIT);
		}

		return dataBasket;

	}

	/** Property to hold updateDataBasket method name **/
	private static final String METHOD_UPDATE_FORMDATA = "updateFormData";

	public OSBNForm updateFormData(OSBNForm objNewOsbnForm) {

		LOGGER.entry(Group.OPEN, OPENMapperConstants.BUSINESS_UNIT);

		String componentName = CLASS_APP_RESPONSE_MAPPER + URLConstants.COLON
				+ METHOD_UPDATE_FORMDATA;

		// String variable tpathKey is used to hold traverse path start
		// component
		String tpathKey = TraversePath.startComponentCall(componentName);
		// String variable statusFlag is used to hold the flag("T"/"F") which
		// indicates if the traverse path component is successfully executed or
		// not
		String statusFlag = TraversePathConstants.TRAVERSE_PATH_FAILURE;
		// String variable statusDesc is used to hold the status description
		// which contains the message if the traverse path component is
		// successfully
		// executed or not
		String statusDesc = OPENMapperConstants.MAPPER_FAILURE;

		try {
			// FormData formData = acquisitionResponse.getFormData();

			// String cmaxKey = formData.getCmaxKey();
			// Have to change once we resolve form Data issue
			String cmaxKey = "30_b_9";
			String cmaxValue = "US_en/Acquisition/OPEN/81/00_1000_PAS_NPA_PS_B_LongOffer1_Def";
			httpRequest.setAttribute("pathkey", cmaxKey);
			httpRequest.setAttribute("pathkeyValue", cmaxValue);
			String appId = "2a48e49c62dcc7396bf60641fd8a34300dd1ae73";//formData.
			// getAppID();

			httpRequest.getSession().putValue("appid", appId);
			// objNewOsbnForm.setAppId(appId);

			statusFlag = TraversePathConstants.TRAVERSE_PATH_SUCCESS;
			statusDesc = OPENMapperConstants.MAPPER_SUCCESS;
		} finally {
			// Ending the traverse path component
			TraversePath.endComponentCall(tpathKey, componentName,
					OPENMapperConstants.PARSER_TRV_VERSION, statusFlag, 0,
					statusDesc);

			// LOGGER.debug(Group.OPEN, OPENMapperConstants.BUSINESS_UNIT,
			// "objNewCCSGForm: " + objNewCCSGForm);
			LOGGER.exit(Group.OPEN, OPENMapperConstants.BUSINESS_UNIT);
		}

		return objNewOsbnForm;
	}

	/*
	 * Method to check the Status
	 * 
	 * @see
	 * com.americanexpress.acquisitions.OPEN.commons.mapper.ResponseInterpretter
	 * #getacquisitionStatus(javax.servlet.http.HttpServletRequest)
	 */

	public String getacquisitionStatus(HttpServletRequest request) {
		
		String statusCode;
		if (acquisitionResponse != null) {
			acquisitionStatus = acquisitionResponse.getAcquisitionStatus();
			statusCode = acquisitionStatus.getStatusCode();
		
			if (OPENConstants.FEP_ERROR_STATUS_CODE.equals(statusCode)) {
				request.setAttribute("acquisitionStatus", acquisitionStatus);
				return "FAILED";
			} else {
				return "SUCCESS";
			}
		} else {
			return "FAILED";
		}

	}

}
