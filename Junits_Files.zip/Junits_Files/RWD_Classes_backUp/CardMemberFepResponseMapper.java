/*
 * -------------------------------------------------------------------------
 *
 * (C) Copyright / American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.
 *
 * -------------------------------------------------------------------------
 */

package com.americanexpress.acquisitions.open.web.managers;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.americanexpress.acquisitions.commons.log.AcquisitionsLogger;
import com.americanexpress.acquisitions.commons.log.constants.Group;
import com.americanexpress.acquisitions.commons.sfwk.shr.StringUtil;
import com.americanexpress.acquisitions.commons.url.constants.URLConstants;
import com.americanexpress.acquisitions.open.commons.common.constants.Keys;
import com.americanexpress.acquisitions.open.commons.common.constants.OPENConstants;
import com.americanexpress.acquisitions.open.commons.common.constants.Pages;
import com.americanexpress.acquisitions.open.commons.mapper.constants.OPENMapperConstants;
import com.americanexpress.acquisitions.open.commons.shortapp.cardservice.Eligiblecard;
import com.americanexpress.acquisitions.open.commons.shortapp.helper.SBSHelper;
import com.americanexpress.acquisitions.open.commons.url.constants.OPENURLConstants;
import com.americanexpress.acquisitions.open.web.beans.CardMemberAppDTO;
import com.americanexpress.acquisitions.services.ccc.commons.Constants;
import com.americanexpress.acquisitions.services.ccc.domain.AcquisitionResponse;
import com.americanexpress.acquisitions.services.ccc.domain.CardData;
import com.americanexpress.acquisitions.services.ccc.domain.EligibilityData;
import com.americanexpress.acquisitions.services.ccc.domain.FormData;
import com.americanexpress.acquisitions.services.ccc.domain.Reason;
import com.americanexpress.acquisitions.services.ccc.domain.SecurityData;
import com.americanexpress.acquisitions.services.ccc.domain.Status;
import com.americanexpress.acquisitions.services.mycariskengineservice.data.MycaRiskAnalyzeResponse;
import com.americanexpress.wss.shr.authorization.token.SecurityToken;

import org.apache.commons.lang.StringUtils;

/**
 * CardMemberFepResponseMapper will maps the AcquisitionResponse to
 * cardMemberAppDTO
 * 
 * @author Viswanatha.Sanapareddy@aexp.com
 * @version $Id: CardMemberFepResponseMapper.java 31891 2013-12-22 11:50:21Z sgajula $
 */
public class CardMemberFepResponseMapper {
	private static final AcquisitionsLogger LOGGER = new AcquisitionsLogger(
			CardMemberFepResponseMapper.class);
	private AcquisitionResponse acqResponse;

	/**
	 * Parameterized constructor.
	 * 
	 * @param fepResponse
	 */
	public CardMemberFepResponseMapper(AcquisitionResponse fepResponse) {

		this.acqResponse = fepResponse;
	}

	/**
	 * This method will update the cardMemberAppDTO using with the Fep Login
	 * page AcquisitionResponse
	 * 
	 * @param cardMemberAppDTO
	 */
	public void updateDTOForFepLoginPageResponse(
			CardMemberAppDTO cardMemberAppDTO) {
		
			FormData formData = acqResponse.getFormData();
			cardMemberAppDTO.setPathKey(formData.getCmaxKey());
			cardMemberAppDTO.setAppId(formData.getAppID());
			cardMemberAppDTO.setCategory(formData.getCategory());
	}

	/**
	 * This method will update the cardMemberAppDTO using with the Fep user
	 * Login AcquisitionResponse
	 * 
	 * @param cardMemberAppDTO
	 * @param session
	 */
	public void updateDTOForFepUserLogonInfo(
			 CardMemberAppDTO cardMemberAppDTO, HttpSession session) {
		
		LOGGER.entry(Group.OPEN, OPENConstants.BUSINESS_UNIT);
		String riskLevel = OPENConstants.HIGH_RISK;
		String ruleName = null;
		String isStable = null;
		cardMemberAppDTO.setMycaLoggedIn(OPENConstants.YES_Y);
		MycaRiskAnalyzeResponse mycaRiskAnalyzeResponse = acqResponse
				.getMycaRiskAnalyzeResponse();
		if (mycaRiskAnalyzeResponse != null) {
			// getting the Risk level form the mycaRisk
			ruleName = mycaRiskAnalyzeResponse.getRuleName();
			if (StringUtils.isEmpty(ruleName)) {
				LOGGER
						.error(
								Group.OPEN,
								OPENConstants.BUSINESS_UNIT,
								"CardMemberLoginAction-->RuleName is NULL for MYCARISK.APPLICTION IS SETTING RISK TO HIGH",
								null);
				riskLevel = OPENConstants.HIGH_RISK;
				session.setAttribute(OPENConstants.MYCA_RISK_ANALYZE_ERROR,
						OPENConstants.TRUE);
			} else {
				riskLevel = ruleName.substring(0, 1);
				LOGGER.error(Group.CCSG, OPENConstants.BUSINESS_UNIT,
						"CardMemberLoginAction-->RuleName is" + riskLevel,
						null, null);
				if (!StringUtil.isNullOrEmpty(mycaRiskAnalyzeResponse
						.getTransactionId())) {
					session.setAttribute(OPENConstants.TRACTION_ID,
							mycaRiskAnalyzeResponse.getTransactionId());
				}
				LOGGER.error(Group.CCSG, OPENConstants.BUSINESS_UNIT,
						"CardMemberLoginAction-->TransactionId is"
								+ mycaRiskAnalyzeResponse.getTransactionId(),
						null);
			}
		}
		
		SecurityData securityData = acqResponse.getSecurityData();
		if (securityData!=null) {
			SecurityToken securityToken = securityData.getSecurityToken();
			String publicGUID = securityData.getGuid();
			if (StringUtils.isNotEmpty(publicGUID) ) {
				cardMemberAppDTO.setPublicGuid(publicGUID);
				session.setAttribute(OPENURLConstants.PUBLIC_GUID, publicGUID);
			}
			if (securityToken != null) {
				cardMemberAppDTO.setSecurityToken(securityToken);

			}

		} 
		 EligibilityData eligibilityData=acqResponse.getEligibilityData();
		
		if ( eligibilityData != null ) {
			 session.setAttribute(Keys.STABLEID_INDICATORS,eligibilityData);
			isStable = eligibilityData
					.getCardMemberUserIDIsStable();
			LOGGER.error(Group.CCSG, OPENConstants.BUSINESS_UNIT,
					"User stability  information is (USER IS STABE or NOT)"
							+ isStable,
					null);
			if (StringUtils.isNotEmpty(isStable) 
					&& OPENConstants.TRUE.equalsIgnoreCase(isStable)
					&& OPENConstants.LOW_RISK.equalsIgnoreCase(riskLevel)) {
				cardMemberAppDTO.setStableId(OPENConstants.STABLE_YES);

			} else {
				cardMemberAppDTO.setStableId(OPENConstants.STABLE_NO);

			}
		}
		if (null != acqResponse.getCardData()) {
			prepareCIDPageMatrix(cardMemberAppDTO);
		}
		LOGGER.exit(Group.OPEN, OPENConstants.BUSINESS_UNIT);
	}

	/**
	 * update dto with card data response for cid page
	 * 
	 * @param cardMemberAppDTO
	 */
	public void prepareCIDPageMatrix(CardMemberAppDTO cardMemberAppDTO) {
		LOGGER.entry(Group.OPEN, OPENConstants.BUSINESS_UNIT);
		List<CardData> cardDataList = acqResponse.getCardData();
		
		if (cardDataList != null && !cardDataList.isEmpty()) {
			Map<String, List<Eligiblecard>> userTotalCards = null;
			List<Eligiblecard> smallBusinessCards = null;
			List<Eligiblecard> personalCards = null;
			List<CardData> primaryCardList = null;
			
			try {
				primaryCardList = SBSHelper.getPrimaryCards(cardDataList);
			} catch (Exception exp) {
				LOGGER.error(Group.OPEN, OPENConstants.BUSINESS_UNIT, exp
						.getMessage(), exp, null);
			}
			
			if (primaryCardList != null && !primaryCardList.isEmpty()) {
				userTotalCards = SBSHelper.getAllElibibleCardsForShortApp(primaryCardList);
				smallBusinessCards = userTotalCards.get(Keys.SBS_CARDS);
				personalCards = userTotalCards.get(Keys.CCSG_CARDS);
				cardMemberAppDTO.setCardDataList(primaryCardList);
				if (smallBusinessCards != null && !smallBusinessCards.isEmpty()) {
					if ((smallBusinessCards.size() == Constants.INT_ONE)
							&& (OPENConstants.STABLE_YES
									.equalsIgnoreCase(cardMemberAppDTO
											.getStableId()))) {
						LOGGER.error(Group.CCSG, OPENConstants.BUSINESS_UNIT,
								"CardMemberFepResponseMapper: User is having single smallBusinessCard card and also stable showing the app page",null);
						cardMemberAppDTO.setStableAndSingleCard(true);
						for (Eligiblecard cardData : smallBusinessCards) {
							cardMemberAppDTO.setAmexCardNumber(cardData
									.getAccountNumber());
						}
					}
					cardMemberAppDTO.setBusenessTypeIndReq(true);
				} else if (smallBusinessCards == null
						&& personalCards != null
						&& personalCards.size() == Constants.INT_ONE
						&& (OPENConstants.STABLE_YES
								.equalsIgnoreCase(cardMemberAppDTO
										.getStableId()))) {
					
					LOGGER.error(Group.CCSG, OPENConstants.BUSINESS_UNIT,
							"CardMemberFepResponseMapper: User is not having smallBusinessCards and having  single personalCards card and also he is stable",null);
					cardMemberAppDTO.setStableAndSingleCard(true);
					cardMemberAppDTO.setStableAndPersonalCards(true);
					for (Eligiblecard cardData : personalCards) {
						cardMemberAppDTO.setAmexCardNumber(cardData
								.getAccountNumber());
					}
				} else if (smallBusinessCards == null
						&& personalCards != null
						&& personalCards.size() > Constants.INT_ONE
						&& (OPENConstants.STABLE_YES
								.equalsIgnoreCase(cardMemberAppDTO
										.getStableId()))) {
					
					LOGGER.error(Group.CCSG, OPENConstants.BUSINESS_UNIT,
							"CardMemberFepResponseMapper: User is not having smallBusinessCards and having  more than one personalCards card and also he is stable",null);
					cardMemberAppDTO.setStableAndSingleCard(true);
					cardMemberAppDTO.setStableAndPersonalCards(true);
					// if user is stable and having only ccsg cards then we will
					// show the Application page with latest card details
					// need add take the latest applied Card Account number
					// details
					cardMemberAppDTO
							.setAmexCardNumber(getLatestCCSGCardDetails(personalCards));
				}
				if (primaryCardList != null && primaryCardList.size() > Constants.INT_ONE
						&& (OPENConstants.STABLE_YES
								.equalsIgnoreCase(cardMemberAppDTO
										.getStableId()))) {
					
					LOGGER.error(Group.CCSG, OPENConstants.BUSINESS_UNIT,
							"CardMemberFepResponseMapper: User is having more than one card and also stable",null);
					cardMemberAppDTO.setStableAndMultipleCards(true);
				}
				if(smallBusinessCards == null && personalCards == null){
					LOGGER.error(Group.CCC, "smallBusinessCards  personalCards List is empty or null --> ",null);
					cardMemberAppDTO.setSortedIndex(OPENConstants.MINUSONE_INDEX);
				}
					cardMemberAppDTO.setUserCards(userTotalCards);	
			}else {
			
				LOGGER.error(Group.CCC, "primaryCardList List is empty or null --> ",null);
				cardMemberAppDTO.setSortedIndex(OPENConstants.MINUSONE_INDEX);
			}
		}else {
			LOGGER.error(Group.CCC, "FEP card List is empty or null --> ",null);
			cardMemberAppDTO.setSortedIndex(OPENConstants.MINUSONE_INDEX);
		}
		LOGGER.exit(Group.OPEN, OPENConstants.BUSINESS_UNIT);
	}

	/**
	 * This method will returns the latest card details based on the
	 * AcctSetupDate
	 * 
	 * @param personalCards
	 * @return
	 */
	public String getLatestCCSGCardDetails(
			List<Eligiblecard> personalCards) {
		LOGGER.entry(Group.OPEN, OPENConstants.BUSINESS_UNIT);
		java.util.Date latestDate = null;
		String latestAcctNumber = null;
		java.util.Date currentDate = null;
		String currentAcctNumber = null;
		DateFormat dateFormat = new SimpleDateFormat(OPENConstants.DD_MM_YYYY);
		for (Eligiblecard cardData : personalCards) {
			String accountSetUpDate = cardData.getAcctSetupDate();
			try {
				currentDate = dateFormat.parse(accountSetUpDate);
			} catch (ParseException parseException) {
				LOGGER.error(Group.OPEN, OPENConstants.BUSINESS_UNIT,
						parseException.getMessage(), parseException, null);

			}
			 currentAcctNumber = cardData.getAccountNumber();
			if (latestDate == null && latestAcctNumber == null) {
				latestDate = currentDate;
				latestAcctNumber = currentAcctNumber;
			} else {
				if (latestDate.compareTo(currentDate) < 0) {
					latestDate = currentDate;
					latestAcctNumber = currentAcctNumber;
				}
			}
		}
		LOGGER.exit(Group.OPEN, OPENConstants.BUSINESS_UNIT);
		return latestAcctNumber;
	}
	/**
	 * This method will validate the acqresponse returns the status 
	 * 
	 * 
	 * @return String
	 */
	public String getAcqStatusText() {
		Status acquisitionStatus = acqResponse.getAcquisitionStatus();
		String statusCode = acquisitionStatus.getStatusCode();
		if (statusCode.equalsIgnoreCase(OPENConstants.STATUSCODE_DOUBLEZERO)
				|| statusCode
						.equalsIgnoreCase(OPENConstants.STATUSCODE_TWOZERO)
				|| statusCode
						.equalsIgnoreCase(OPENConstants.STATUSCODE_FOURZERO)) {
			return OPENConstants.OPEN_SUCCESS_STATUS;
		} else {
			return OPENConstants.OPEN_FAILED_STATUS;
		}
	}
	/**
	 * This method will validate the acqresponse returns the status 
	 * 
	 * 
	 * @return String
	 */
	public String getLoggedInPageAcqStatus() {
		if (acqResponse != null && null != acqResponse.getAcquisitionStatus()) {
			Status acquisitionStatus = acqResponse.getAcquisitionStatus();
			String statusCode = acquisitionStatus.getStatusCode();
			if ((statusCode
					.equalsIgnoreCase(OPENConstants.STATUSCODE_DOUBLEZERO)
					|| statusCode
							.equalsIgnoreCase(OPENConstants.STATUSCODE_TWOZERO) || statusCode
					.equalsIgnoreCase(OPENConstants.STATUSCODE_FOURZERO))) {
				return OPENConstants.OPEN_SUCCESS_STATUS;
			} else {
				return OPENConstants.OPEN_FAILED_STATUS;
			}
		} else {
			return OPENConstants.OPEN_FAILED_STATUS;
		}

	}

	/**
	 * check the error code and returns the success or failure
	 * 
	 * @return
	 */
	public String getDisplayLoginPagStatus(String flowType) {
		String flowStatus = null;
		if (acqResponse == null || acqResponse.getAcquisitionStatus()==null) {
			flowStatus = Pages.SYSTEM_ERROR;
		} else {
			Status acquisitionStatus = acqResponse.getAcquisitionStatus();
			String statusCode = acquisitionStatus.getStatusCode();
			List<Reason> reasonList = acqResponse.getAcquisitionStatus()
					.getErrorList();
			if ((statusCode
					.equalsIgnoreCase(OPENConstants.STATUSCODE_DOUBLEZERO)
					|| statusCode
							.equalsIgnoreCase(OPENConstants.STATUSCODE_TWOZERO) || statusCode
					.equalsIgnoreCase(OPENConstants.STATUSCODE_FOURZERO))
					&& null != acqResponse.getFormData() ) {
				flowStatus = OPENConstants.OPEN_SUCCESS_STATUS;
				 if (URLConstants.FLOW_TYPE_SHORT_NPA.equals(flowType) &&  acqResponse.isDefaultSourceCodeFlag()) {
						LOGGER
						.error(
								Group.OPEN,
								"getFEPLoginResponse method of  CardMemberHelper",
								"StatusCode  is 60 CMAXKEY IS NULL OR DEFAULT SOURCE CODE IS ENABLED "  ,null);
						flowStatus = OPENConstants.DEFALUT_SRC_CODE;
					}
			} else if (reasonList != null && !reasonList.isEmpty()) {
				for (Reason reason : reasonList) {
					int reasonCode = reason.getReasonCode();
					String reasonMessage = reason.getReasonMsg();
					if (reasonCode == 2028) {
						LOGGER.debug(Group.OPEN, OPENConstants.BUSINESS_UNIT,
								"POID Expired :" + reasonMessage);
						LOGGER
						.error(
								Group.OPEN,
								"getFEPLoginResponse method of  CardMemberHelper",
								"StatusCode  is 60 POID Expired : reason " + reason,null);
						flowStatus = OPENConstants.POID_OFFER_EXPIRED;
					}else if (URLConstants.FLOW_TYPE_SHORT_NPA.equals(flowType) && (reasonCode == 5451 || acqResponse.isDefaultSourceCodeFlag()) ) {
						LOGGER
						.error(
								Group.OPEN,
								"getFEPLoginResponse method of  CardMemberHelper",
								"StatusCode  is 60 CMAXKEY IS NULL OR DEFAULT SOURCE CODE IS ENABLED : reason " + reason,null);
						flowStatus = OPENConstants.DEFALUT_SRC_CODE;
					}else {
						LOGGER
								.error(
										Group.OPEN,
										"getFEPLoginResponse method of  CardMemberHelper",
										"StatusCode  is 60 reason " + reason,null);
						flowStatus = Pages.SYSTEM_ERROR;
					}
				}
			}else if(URLConstants.FLOW_TYPE_SHORT_NPA.equals(flowType) &&  acqResponse.isDefaultSourceCodeFlag() ){
				LOGGER
				.error(
						Group.OPEN,
						"getFEPLoginResponse method of  CardMemberHelper",
						"StatusCode  is 60 CMAXKEY IS NULL OR DEFAULT SOURCE CODE IS ENABLED  " ,null);
				flowStatus = OPENConstants.DEFALUT_SRC_CODE;
			}else {
				flowStatus = Pages.SYSTEM_ERROR;
			}
		}
		return flowStatus;
	}

}
