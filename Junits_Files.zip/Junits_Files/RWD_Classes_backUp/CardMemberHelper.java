/*
 * -------------------------------------------------------------------------
 *
 * (C) Copyright / American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.
 *
 * -------------------------------------------------------------------------
 */

package com.americanexpress.acquisitions.open.web.managers;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.americanexpress.acquisitions.commons.config.AcquisitionsConfigManager;
import com.americanexpress.acquisitions.commons.config.exceptions.AcquisitionsConfigException;
import com.americanexpress.acquisitions.commons.log.AcquisitionsLogger;
import com.americanexpress.acquisitions.commons.log.constants.Group;
import com.americanexpress.acquisitions.commons.log.event.AppReportEvent;
import com.americanexpress.acquisitions.commons.sfwk.shr.ServiceUtil;
import com.americanexpress.acquisitions.commons.sfwk.shr.StringUtil;
import com.americanexpress.acquisitions.commons.traversepath.TraversePath;
import com.americanexpress.acquisitions.commons.traversepath.TraversePathConstants;
import com.americanexpress.acquisitions.commons.traversepath.TraversePathUtil;
import com.americanexpress.acquisitions.commons.url.constants.URLConstants;
import com.americanexpress.acquisitions.open.commons.common.EOICookie;
import com.americanexpress.acquisitions.open.commons.common.SSOCookie;
import com.americanexpress.acquisitions.open.commons.common.constants.CMAXConstants;
import com.americanexpress.acquisitions.open.commons.common.constants.Constants;
import com.americanexpress.acquisitions.open.commons.common.constants.ErrorConstants;
import com.americanexpress.acquisitions.open.commons.common.constants.Keys;
import com.americanexpress.acquisitions.open.commons.common.constants.OPENConstants;
import com.americanexpress.acquisitions.open.commons.common.constants.Pages;
import com.americanexpress.acquisitions.open.commons.formbeans.RedesignOSBNForm;
import com.americanexpress.acquisitions.open.commons.mapper.FEPRequestMapper;
import com.americanexpress.acquisitions.open.commons.mapper.constants.OPENMapperConstants;
import com.americanexpress.acquisitions.open.commons.url.constants.OPENURLConstants;
import com.americanexpress.acquisitions.open.commons.url.helper.OPENURLParameterHelper;
import com.americanexpress.acquisitions.open.commons.util.RatesUtil;
import com.americanexpress.acquisitions.open.commons.util.SBSUtils;
import com.americanexpress.acquisitions.open.web.beans.CardMemberAppDTO;
import com.americanexpress.acquisitions.open.web.managers.CardMemberFepResponseMapper;
import com.americanexpress.acquisitions.services.ccc.domain.AcquisitionRequest;
import com.americanexpress.acquisitions.services.ccc.domain.AcquisitionResponse;
import com.americanexpress.acquisitions.services.ccc.domain.CardData;
import com.americanexpress.acquisitions.services.ccc.domain.PricingFeature;
import com.americanexpress.acquisitions.services.ccc.domain.Reason;
import com.americanexpress.wss.shr.authorization.token.SecurityToken;

import org.apache.commons.lang.StringUtils;
import org.apache.struts.action.ActionForm;


/**
 * CardMemberHelper is to display the single/dual login page for valid urls and  
 * for invalid urls will get the error pages
 * 
 * @author Stalin Ch
 * @version $Id: CardMemberHelper.java 30977 2013-12-09 05:33:34Z sgajula $
 */
public class CardMemberHelper {

	private HttpServletRequest request;
	private HttpServletResponse response;
	private HttpSession session;
	private OPENURLParameterHelper parameterHelper;
	private CardMemberAppDTO cardMemberAppDTO;
	private final String CLASS_NAME = this.getClass().getSimpleName();
	
	private static final AcquisitionsLogger LOGGER = new AcquisitionsLogger(
			CardMemberHelper.class);
	
	public CardMemberHelper(ActionForm form, HttpServletRequest request,
			 				HttpServletResponse response) 
	{
		this.request = request;
		assert request != null;
		session = request.getSession();
		this.response = response;
		assert response != null;
		
		cardMemberAppDTO = (CardMemberAppDTO)request.getAttribute(OPENConstants.CARDMEMBERAPP_DTO);

		if (cardMemberAppDTO == null)
			cardMemberAppDTO = new CardMemberAppDTO();
		
		parameterHelper = new OPENURLParameterHelper(request);
		session.setAttribute(OPENConstants.PARAM_HELPER,parameterHelper);
	}

	public HttpServletRequest getRequest() {
		return request;
	}

	public OPENURLParameterHelper getParameterHelper() {
		return parameterHelper;
	}

	public CardMemberAppDTO getCardMemberAppDTO() {
		return cardMemberAppDTO;
	}

	/**
	 * This method will update cardMemberAppDTO with the help of parameter helper
	 * 
	 * @param redesignAppForm
	 */
	public void updateCardMemberAppDTOAndForm(RedesignOSBNForm redesignAppForm) {
			cardMemberAppDTO.setFlowType((String) parameterHelper
					.getProperty(URLConstants.FLOW_TYPE));
			
			cardMemberAppDTO.setCardType((String) parameterHelper
					.getProperty(URLConstants.CARD_TYPE));
			
			redesignAppForm.setCardType(cardMemberAppDTO.getCardType());
			
			cardMemberAppDTO.setEntryPoint((String) parameterHelper
					.getProperty(URLConstants.ENTRY_POINT));
			cardMemberAppDTO.setAppType((String) parameterHelper
					.getProperty(URLConstants.APP_TYPE));
			cardMemberAppDTO.setBasicOrSupp((String) parameterHelper
					.getProperty(URLConstants.BASIC_OR_SUPP));
			cardMemberAppDTO.setPageId((String) parameterHelper
					.getProperty(URLConstants.PAGE_ID));
			cardMemberAppDTO.setCardName((String) parameterHelper
					.getProperty(URLConstants.CARD_NAME));
			cardMemberAppDTO.setOfferCode((String) parameterHelper
					.getProperty(URLConstants.OFFER_CODE));
	}
/**
 * using bellow method will hit the fep for request validation if success returns login page 
 * other wise it will returns the error page 
 * 
 * @param redesignAppForm
 * 
 * @return	String
 */
	public String getFEPLoginResponse(RedesignOSBNForm redesignAppForm) {
		LOGGER.entry(Group.OPEN, OPENConstants.BUSINESS_UNIT);
		
		final String METHOD_NAME = "getFEPLoginResponse";
		StringBuilder tPathCompBuilder=new StringBuilder();
	   	tPathCompBuilder.append(CLASS_NAME).append( URLConstants.COLON ).append(METHOD_NAME);
	   	String 	componentName=tPathCompBuilder.toString();
	   	
		String statusFlag = TraversePathConstants.TRAVERSE_PATH_FAILURE;
		String statusDesc =  OPENConstants.OPEN_FAILURE_STATUS;
		TraversePathUtil.setWebStartInfo(request);
		String tpathKey = TraversePath.startComponentCall(componentName);
		
		String flowType = cardMemberAppDTO.getFlowType();
		if(LOGGER.isInfoEnabled()){
		LOGGER.info(Group.OPEN, OPENConstants.BUSINESS_UNIT_ACTION,
				"flowType=" + flowType);
		}
		String loginPage = null;
		String mainFlow = null;
		String subFlow = null;
		
		try{
			
			AcquisitionRequest acquisitionRequest = new AcquisitionRequest();
				FEPRequestMapper fepRequestMapper = new FEPRequestMapper();
		
		if (URLConstants.FLOW_TYPE_SHORT_PA.equals(flowType)) {
			mainFlow = OPENConstants.OPEN_PASA_FLOW;
			subFlow = OPENConstants.OPEN_PASA_LOGIN;
			loginPage=OPENConstants.PA_LOGINPAGE;
			session.setAttribute(OPENConstants.SHORTAPP_FLOWTYPE, OPENConstants.SHORTAPP_PA);
		} else if (URLConstants.FLOW_TYPE_SHORT_NPA.equals(flowType)) {
			mainFlow = OPENConstants.OPEN_NPASA_FLOW;
			subFlow = OPENConstants.SUB_FLOW_APPLICATION;
			loginPage = OPENConstants.DUAL_LOGINPAGE;
			session.setAttribute(OPENConstants.SHORTAPP_FLOWTYPE, OPENConstants.SHORTAPP_NPA);
		}
		
		fepRequestMapper.buildFEPRequestBean(request, response,
				acquisitionRequest, redesignAppForm, Constants.OPEN_APP,
				mainFlow, subFlow);
		/*if (LOGGER.isDebugEnabled()) {
		LOGGER.debug(Group.OPEN, OPENConstants.BUSINESS_UNIT_ACTION, "CardMemberDisplayAction --- CardMemberHelper acquisitionRequest :" + acquisitionRequest );
		}*/
		AcquisitionResponse acquisitionResponse =  fepRequestMapper
				.fepResponseBuilder(acquisitionRequest);
		/*if (LOGGER.isDebugEnabled()) {
	 LOGGER.debug(Group.OPEN, OPENConstants.BUSINESS_UNIT_ACTION, "CardMemberDisplayAction --- CardMemberHelper acquisitionResponse :" + acquisitionResponse );
		}*/
		if (null == acquisitionResponse) {
            LOGGER.error(Group.OPEN, OPENConstants.BUSINESS_UNIT, tpathKey
                + "returning to error page when acquisitionResponse object is null", null);
            return Pages.SYSTEM_ERROR;
        }
		
		CardMemberFepResponseMapper cardMemberFepResponseMapper = new CardMemberFepResponseMapper(
				acquisitionResponse);
		String resultPage=cardMemberFepResponseMapper.getDisplayLoginPagStatus(flowType);
		
		if (OPENConstants.SUCCESS.equals(resultPage)) {
			 cardMemberFepResponseMapper
				.updateDTOForFepLoginPageResponse(cardMemberAppDTO);
			 PricingFeature pricingFeature= acquisitionResponse.getPricingFeature();
			session.setAttribute(OPENConstants.PRICING_FEATURE, pricingFeature);
			RatesUtil ratesCalculator = new RatesUtil();
			session.setAttribute(OPENConstants.RATES_HT, ratesCalculator.getRates(acquisitionResponse));
			
			if(URLConstants.FLOW_TYPE_SHORT_NPA.equals(flowType)){
				if(pricingFeature !=null && pricingFeature.getChargeIndicator() != null){
					session.setAttribute(OPENConstants.CHARGE_INDICATOR, pricingFeature.getChargeIndicator());
				} else {
						LOGGER.error(Group.OPEN, OPENMapperConstants.BUSINESS_UNIT, "shortnpa flow Got ChargeIndicator as null",null);
					return Pages.SYSTEM_ERROR;
				}
			}
			/*if (LOGGER.isInfoEnabled()) {
			LOGGER.info(Group.OPEN, "CardMemberDisplayAction --- CardMemberHelper", " cmaxKey " + cardMemberAppDTO.getPathKey());
			LOGGER.info(Group.OPEN, "CardMemberDisplayAction --- CardMemberHelper", " appId : "+cardMemberAppDTO.getAppId());
			}*/
			session.setAttribute(OPENConstants.CMAX_PATHKEY, cardMemberAppDTO.getPathKey());
			session.setAttribute(CMAXConstants.CMAX_KEY, cardMemberAppDTO
					.getPathKey());
			session.setAttribute(Keys.DB_APP_ID, cardMemberAppDTO.getAppId());
			session.setAttribute(OPENConstants.CARDMEMBERAPP_DTO, cardMemberAppDTO);
			//Start Default_Source_Code_OPEN
		}else if (OPENConstants.DEFALUT_SRC_CODE.equals(resultPage)){
			String redirectURL = prepareURLForDefaultSourceCode(request);
			if(StringUtils.isNotEmpty(redirectURL)){
				response.sendRedirect(response.encodeRedirectURL(redirectURL));
					}else{
						loginPage= Pages.SYSTEM_ERROR;
		        }
			//END: Default_Source_Code_OPEN
		}else if(OPENConstants.POID_OFFER_EXPIRED.equals(resultPage)){
		    // Added for SI Url Decommission phase2 change - artf360567
			String ajCardDetailURL = SBSUtils.buildAJCardDetailURL(cardMemberAppDTO.getCardType(), request);
        	if(!StringUtil.isEmpty(ajCardDetailURL)){
        		request.setAttribute(OPENConstants.LINK_URL, ajCardDetailURL);
        	}
			// End of SI Url Decommission phase2 change -artf360567
        	return resultPage;
		}else{
			return resultPage;
		}
		
		
			statusFlag = TraversePathConstants.TRAVERSE_PATH_SUCCESS;
			statusDesc = OPENConstants.OPEN_SUCCESS_STATUS;
		}catch(IOException ioexp){
			LOGGER.error(Group.OPEN, OPENConstants.BUSINESS_UNIT, statusDesc,
					ioexp, null);
		}
		finally{
       	 TraversePath.endComponentCall(tpathKey, componentName, OPENURLConstants.PARSER_TRV_VERSION, statusFlag, 0,
                    statusDesc);
       	 AppReportEvent appReport =   new AppReportEvent(request, getCardMemberAppDTO().getCardType(),
               		 statusDesc, statusFlag, Group.OPEN, null,getCardMemberAppDTO().getCardType(), null, null, 
                		OPENConstants.OPEN_SHORTAPP_LOGGIN, statusDesc, OPENConstants.OPEN_SHORTAPP_LOGGIN);
       	 
       	  TraversePathUtil.setWebEndInfo(Group.CCSG, METHOD_NAME, 0, null, appReport);
       	  
       	 LOGGER.exit(Group.OPEN, OPENConstants.BUSINESS_UNIT);
        
		}
		return loginPage;

	}
// START: Added for OPEN DefaultSourceCode 
    
    /**
     * prepareURLForDefaultSourceCode for redirecting the URL
     * 
     * @param HttpServletRequest
     * 
     * @return String	defaultSourceCodeUrl
     */
     public String prepareURLForDefaultSourceCode(HttpServletRequest request) {
    	LOGGER.entry(Group.OPEN, OPENConstants.BUSINESS_UNIT);
    	
    	String defaultEntryPoint = null;
    	String defaultPageId = null;
		String originalEntryPoint = null;
		String defaultSourceCodeURL=null;
		
		// Start : Retreving the default entry point
		try {
			
			defaultEntryPoint = AcquisitionsConfigManager
			.getPropertiesValue(
					OPENConstants.CONTENT_JCONFIG,
					OPENConstants.CARDNAME_PROPERTIES, OPENConstants.DEF_ENTRY_POINT);
			
			defaultPageId = AcquisitionsConfigManager.getPropertiesValue(
					OPENConstants.CONTENT_JCONFIG, OPENConstants.CARDNAME_PROPERTIES,
					OPENConstants.DEF_PAGE_ID);
			
		} catch (AcquisitionsConfigException acqException) {
			LOGGER
					.error(
							Group.OPEN,
							OPENURLConstants.BUSINESS_UNIT,
							acqException.getMessage()
									+ "Exception while reading the CardNames property from content config file :",
									acqException, null);
		}
		// End : Retreving the default entry point
		if (StringUtils.isNotEmpty(defaultEntryPoint)
				&& !parameterHelper.getProperty(
						URLConstants.ENTRY_POINT).equals(
						defaultEntryPoint)) {
			OPENURLParameterHelper parameterHelper = new OPENURLParameterHelper(
					request);
			originalEntryPoint = (String) parameterHelper
					.getProperty(URLConstants.ENTRY_POINT);
	         //preparing the new url with default source code
			StringBuilder urlBuilder  = new StringBuilder();
			urlBuilder.append(OPENConstants.MEMBER_CONTEXTPATH);
			urlBuilder.append(URLConstants.URL_SEPARATOR);
			urlBuilder.append(parameterHelper.getProperty(URLConstants.CARD_NAME));
			urlBuilder.append(URLConstants.URL_SEPARATOR);
			urlBuilder.append(OPENConstants.OPEN_LA_APPLY_NOW_REQUEST_TYPE);
			urlBuilder.append(URLConstants.URL_SEPARATOR);
			urlBuilder.append(defaultEntryPoint);
			urlBuilder.append(URLConstants.HYPHEN);
			urlBuilder.append(defaultPageId);
			urlBuilder.append(URLConstants.HYPHEN);
			urlBuilder.append(parameterHelper.getProperty(URLConstants.APP_TYPE));
			urlBuilder.append(URLConstants.URL_SEPARATOR);
			urlBuilder.append(URLConstants.QUESTION_MARK);
			urlBuilder.append(OPENConstants.PARAM_STRING);
			urlBuilder.append(URLConstants.AMPERSAND);
			urlBuilder.append(OPENConstants.PARAM_EEP + originalEntryPoint);
			if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(Group.OPEN, OPENMapperConstants.BUSINESS_UNIT,
					"urlBuffer value" + " in new method " + urlBuilder.toString());
			}
			defaultSourceCodeURL= urlBuilder.toString();
		}
		return defaultSourceCodeURL;
	}
 // END : Added for OPEN DefaultSourceCode 
    
	/**
	 * This method will hit fep for  logged in scenario response  if response is valid then returns the appropriate cid/application page
	 * other wise it will returns the appropriate login pages 
	 * 
	 * @param redesignAppForm 
	 * @return
	 
	 */
	public String getCookiedFEPLoginResponse(RedesignOSBNForm redesignAppForm){
		LOGGER.entry(Group.OPEN, OPENConstants.BUSINESS_UNIT);
		
		final String METHOD_NAME = "getCookiedFEPLoginResponse";
		StringBuilder tPathCompBuilder=new StringBuilder();
	   	tPathCompBuilder.append(CLASS_NAME).append( URLConstants.COLON ).append(METHOD_NAME);
	   	String 	componentName=tPathCompBuilder.toString();
		String statusFlag = TraversePathConstants.TRAVERSE_PATH_FAILURE;
		
		String statusDesc =  OPENConstants.OPEN_FAILURE_STATUS;
		TraversePathUtil.setWebStartInfo(request);
		String tpathKey = TraversePath.startComponentCall(componentName);
		
		String subFlow = null;
		String mainFlow = null;
        String returnPage=null;
        
		  try {
			  
        String publicGuid = SSOCookie.getBlueBoxPublicCookie(request);
        String securityTokenStr = EOICookie.getBlueBoxPublicCookie(request);
        
        if (LOGGER.isInfoEnabled()) {
        	LOGGER.info(Group.CCSG, OPENConstants.BUSINESS_UNIT_ACTION,
    				"publicGuid= : " + publicGuid);
        LOGGER.info(Group.CCSG, OPENConstants.BUSINESS_UNIT_ACTION,
				"securityTokenStr= : " + securityTokenStr);
        }
        
    	SecurityToken securityToken = getSecurityToken(securityTokenStr);
    	
    	redesignAppForm.setPublicGuid(publicGuid);
    	redesignAppForm.setSecurityToken(securityToken);
    	
        AcquisitionResponse acquisitionResponse = null;
        
    	 FEPRequestMapper fepRequestMapper = new FEPRequestMapper();
    	 new AcquisitionRequest();
    	 String flowType = cardMemberAppDTO.getFlowType();
    	 
             if (URLConstants.FLOW_TYPE_SHORT_PA.equals(flowType)) {
                 mainFlow =OPENConstants.FLOW_TYPE_SHORTAPPPA;
                 subFlow =  OPENConstants.SUB_FLOW_CARDSELECTORPAGE;
             } else if (URLConstants.FLOW_TYPE_SHORT_NPA.equals(flowType)) {
                 mainFlow = OPENConstants.FLOW_TYPE_SHORT_NPA;
                 subFlow = OPENConstants.SUB_FLOW_CARDSELECTORPAGE;
             }
             
             AcquisitionRequest  acquisitionRequest = null;/*fepRequestMapper.buildShortAppFepRequestBean(request, response,
				 redesignAppForm, Constants.OPEN_APP,
				mainFlow, subFlow);*/
             	if (LOGGER.isDebugEnabled()) {
             	LOGGER.debug(Group.OPEN, OPENConstants.BUSINESS_UNIT_ACTION, "CardMemberDisplayAction --- CardMemberHelper acquisitionRequest :" + acquisitionRequest );
             	}
        		acquisitionResponse = fepRequestMapper
        				.fepResponseBuilder(acquisitionRequest);
             	if (LOGGER.isDebugEnabled()) {
        	 LOGGER.debug(Group.OPEN, OPENConstants.BUSINESS_UNIT_ACTION, "CardMemberDisplayAction --- CardMemberHelper acquisitionResponse :" + acquisitionResponse );
             	}
             	
         	CardMemberFepResponseMapper cardMemberFepResponseMapper = new CardMemberFepResponseMapper(
     				acquisitionResponse);
         	String status =cardMemberFepResponseMapper.getLoggedInPageAcqStatus();
         	
			 if(StringUtils.isNotEmpty(status) && OPENConstants.OPEN_SUCCESS_STATUS.equalsIgnoreCase(status))
	            {
					cardMemberFepResponseMapper.updateDTOForFepUserLogonInfo(
							cardMemberAppDTO, session);
					if (isInValidUserResonse(acquisitionResponse)) {
						return Pages.SYSTEM_ERROR;
					}
					boolean stableAndSingleCard = cardMemberAppDTO
							.getIsStableAndSingleCard();
					PricingFeature pricingFeature = acquisitionResponse.getPricingFeature();
					RatesUtil ratesCalculator = new RatesUtil();
					session.setAttribute(OPENConstants.RATES_HT, ratesCalculator.getRates(acquisitionResponse));
					if (pricingFeature != null) {
						session.setAttribute(OPENConstants.PRICING_FEATURE, pricingFeature);
					}
					session.setAttribute(OPENConstants.CARDMEMBERAPP_DTO,
							cardMemberAppDTO);
					session.setAttribute(OPENConstants.USERTOTAL_CARDS_TABLE,
							cardMemberAppDTO.getUserCards());
					
					if (stableAndSingleCard) {
						if (LOGGER.isInfoEnabled()) {
						LOGGER.info(Group.OPEN, OPENConstants.BUSINESS_UNIT_ACTION,
								"stableAndSingleCard: " + stableAndSingleCard);
						}
						returnPage = OPENConstants.APPLICATION_PAGE;
					} else {
						returnPage = OPENConstants.CARD_SELECTOR_PAGE;
					}
					
				}else{
	            	List<Reason> reasonList = acquisitionResponse
					.getAcquisitionStatus().getErrorList();
				for (Reason reason : reasonList) {
						int reasonCode = reason.getReasonCode();
						if (reasonCode == ErrorConstants.ERROR_CODE_1013) {
							if (LOGGER.isDebugEnabled()) {
							LOGGER.debug(Group.OPEN, OPENConstants.BUSINESS_UNIT,
									"UserNotLoggedIn exception from CardServices ---->"
											+ "returning to  login page");
							}
							 if (URLConstants.FLOW_TYPE_SHORT_PA.equals(flowType)) {
								 returnPage= OPENConstants.PA_LOGINPAGE;
							 }else{
								 returnPage=OPENConstants.DUAL_LOGINPAGE;
							 }
						}else if (reasonCode == ErrorConstants.ERROR_CODE_2028) {
	                          //transfer to offer expire page need to update    
							return Pages.SYSTEM_ERROR;
						}
						else{
							return Pages.SYSTEM_ERROR;
						}
				}
	            	
	            }
		  }finally{
		       	 TraversePath.endComponentCall(tpathKey, componentName, OPENURLConstants.PARSER_TRV_VERSION, statusFlag, 0,
		                    statusDesc);
		       	 AppReportEvent appReport =   new AppReportEvent(request, getCardMemberAppDTO().getCardType(),
		               		 statusDesc, statusFlag, Group.OPEN, null,getCardMemberAppDTO().getCardType(), null, null, 
		                		"OPEN_SHORTAPP_CID", statusDesc, "OPEN_SHORTAPP_CID");
		       	  TraversePathUtil.setWebEndInfo(Group.CCSG, METHOD_NAME, 0, null, appReport);
		       	 LOGGER.exit(Group.OPEN, OPENConstants.BUSINESS_UNIT);
		  }
		return returnPage;
	}
	
	/**
	 * This method is to validate the user AcquisitionResponse if response is as expected then retunrs false
	 * other wise it will returns the sysdown page with appropriate error message 
	 * 
	 * @param acquisitionResponse
	 * @return boolean
	 */
	public boolean isInValidUserResonse(AcquisitionResponse acquisitionResponse){
		LOGGER.entry(Group.OPEN, OPENConstants.BUSINESS_UNIT);
		List<CardData> cardList = cardMemberAppDTO.getCardDataList();
		String publicGuid = cardMemberAppDTO.getPublicGuid();
		SecurityToken securityToken = cardMemberAppDTO.getSecurityToken();
		if (publicGuid == null || cardList == null || cardList.isEmpty()) {
			LOGGER.error(Group.OPEN, OPENMapperConstants.BUSINESS_UNIT, "acquisitionResponse is invalid",null);
			return true;
	    }else if (URLConstants.FLOW_TYPE_SHORT_PA.equals(cardMemberAppDTO.getFlowType())) {
			String ispreApproved = acquisitionResponse
					.getPreApprovedStatus();
			if (ispreApproved == null
					|| OPENConstants.FALSE
							.equalsIgnoreCase(ispreApproved)) {
				LOGGER.error(Group.OPEN, OPENMapperConstants.BUSINESS_UNIT, "acquisitionResponse is invalid --ispreApproved is falseot null",null);
				return true;
			}
		} 
		LOGGER.exit(Group.OPEN, OPENConstants.BUSINESS_UNIT);
		return false;
}

	/**
	 * isAlreadyLoggedin will return true when the user is logged in if not it
	 * will return false.
	 * 
	 * 
	 * @return boolean
	 */
	public boolean isAlreadyLoggedin() {
		LOGGER.entry(Group.OPEN, OPENConstants.BUSINESS_UNIT);
		boolean alreadyLoggedIn = false;
		String blueBoxValue = EOICookie.getInstance().getCookie(request);
		if (StringUtils.isNotBlank(blueBoxValue)) {
			alreadyLoggedIn = true;
		}
		LOGGER.exit(Group.OPEN, OPENConstants.BUSINESS_UNIT);
		return alreadyLoggedIn;
	}
   /**to get the security token by passing the String
 * @param securityTokenStr
 * @return SecurityToken
 */
public SecurityToken getSecurityToken(String securityTokenStr){
	LOGGER.entry(Group.OPEN, OPENConstants.BUSINESS_UNIT);
	SecurityToken securityToken=null;
	try{
		if(!StringUtil.isNullOrEmpty(securityTokenStr)){
			 securityToken = (SecurityToken) ServiceUtil.createSecurityToken(securityTokenStr);	 
		}
	
	}catch(Exception e){
		if (LOGGER.isDebugEnabled()) {
		LOGGER.debug(Group.CCSG, "",
				"SecurityToken From Card Service: " + securityToken);
		}
	}
	LOGGER.entry(Group.OPEN, OPENConstants.BUSINESS_UNIT);
	return securityToken;
}
}
