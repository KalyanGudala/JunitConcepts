/*
 * -------------------------------------------------------------------------
 *
 * (C) Copyright / American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.
 *
 * -------------------------------------------------------------------------
 */

package com.americanexpress.acquisitions.open.web.Test;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.americanexpress.acquisitions.commons.url.param.CommonParam;
import com.americanexpress.acquisitions.open.commons.common.EOICookie;
import com.americanexpress.acquisitions.open.commons.common.SSOCookie;
import com.americanexpress.acquisitions.open.commons.formbeans.RedesignOSBNForm;
import com.americanexpress.acquisitions.open.commons.mapper.FEPRequestMapper;
import com.americanexpress.acquisitions.open.commons.url.helper.OPENURLParameterHelper;
import com.americanexpress.acquisitions.open.web.beans.CardMemberAppDTO;
import com.americanexpress.acquisitions.open.web.managers.CardMemberFepResponseMapper;
import com.americanexpress.acquisitions.open.web.managers.CardMemberHelper;
import com.americanexpress.acquisitions.open.web.managers.CardMemberLoginHelper;

import com.americanexpress.acquisitions.services.ccc.domain.AcquisitionRequest;
import com.americanexpress.acquisitions.services.ccc.domain.AcquisitionResponse;
import com.americanexpress.acquisitions.services.ccc.domain.PricingFeature;
import com.americanexpress.acquisitions.services.ccc.domain.Reason;
import com.americanexpress.acquisitions.services.ccc.domain.Status;

import org.apache.struts.action.ActionForm;
import org.easymock.EasyMock;
import org.junit.Test;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.replay;
import static org.easymock.EasyMock.verify;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;



public class CardMemberHelperTest {
	
    public CardMemberHelper cardMemberHelper;
    public CardMemberLoginHelper cardMemberLoginHelper;
    public ActionForm form;
	public HttpServletRequest request;
	public HttpServletResponse response;   
    public HttpSession session; 
    public CardMemberAppDTO cardMemberAppDTO;
    public EOICookie eoicookie;
    public Cookie cookie;
    public AcquisitionResponse acquisitionResponse;
    public RedesignOSBNForm redesignAppForm;
    public OPENURLParameterHelper parameterHelper;
    public CommonParam commonParam;
    
    @Test
    public void testupdateCardMemberAppDTOAndForm(){    	
		request =EasyMock.createNiceMock(HttpServletRequest.class);		
		response =EasyMock.createNiceMock(HttpServletResponse.class);
		form=EasyMock.createNiceMock(ActionForm.class);				
		session = EasyMock.createNiceMock(HttpSession.class);		
		expect(request.getSession()).andReturn(session);
		replay(request);		
		cardMemberAppDTO=new CardMemberAppDTO();				
		cardMemberAppDTO.setFlowType("shortnpa");
		cardMemberAppDTO.setEntryPoint("37890");
		cardMemberAppDTO.setAppType("applicationType");
		cardMemberAppDTO.setBasicOrSupp("basic");
		cardMemberAppDTO.setPageId("78690");
		cardMemberAppDTO.setCardName("businessCard");
		cardMemberAppDTO.setOfferCode("3456");		
		redesignAppForm=new RedesignOSBNForm();		
		cardMemberHelper=new CardMemberHelper(form,request,response);			
		cardMemberHelper.updateCardMemberAppDTOAndForm(redesignAppForm);
		verify(request);
    }
      
		
	@Test
	public void testisAlreadyLoggedinFailure(){		
			request =EasyMock.createNiceMock(HttpServletRequest.class);		
			response =EasyMock.createNiceMock(HttpServletResponse.class);							
			session = EasyMock.createNiceMock(HttpSession.class);
			eoicookie = EasyMock.createNiceMock(EOICookie.class);
			expect(request.getSession()).andReturn(session);
			replay(request);
			cardMemberHelper=new CardMemberHelper(form, request, response);
			assertFalse(cardMemberHelper.isAlreadyLoggedin());
			verify(request);					
   }
	
	@Test
	public void testIsAlreadyLoggedinSuccess(){		
		request =EasyMock.createNiceMock(HttpServletRequest.class);		
		response =EasyMock.createNiceMock(HttpServletResponse.class);							
		session = EasyMock.createNiceMock(HttpSession.class);
		eoicookie = EasyMock.createNiceMock(EOICookie.class);
		expect(request.getSession()).andReturn(session);
		replay(request);		
		cardMemberHelper=new CardMemberHelper(form, request, response);		
		setBlueBoxCookies();		
		assertFalse(cardMemberHelper.isAlreadyLoggedin());		
   }
		
	private void setBlueBoxCookies() 
	{		
		String sessionid = "0DEFC54864E651F1A92E5A7B4B77107D";		
		String eoiCookieName="blueboxvalues";
		cookie=new Cookie(eoiCookieName, sessionid);
		cookie.setDomain(".aexp.com");
		cookie.setPath("/");
		cookie.setSecure(true);
		cookie.setMaxAge(300);
		response.addCookie(cookie);
		eoicookie.setCookie(sessionid, response);			
	}
	
	/*@Test
	public void testgetCookiedFEPLoginResponse(){
		redesignAppForm =new RedesignOSBNForm();
		request =EasyMock.createNiceMock(HttpServletRequest.class);
		response =EasyMock.createNiceMock(HttpServletResponse.class);
		form=EasyMock.createNiceMock(ActionForm.class);
		session = EasyMock.createNiceMock(HttpSession.class);
		expect(request.getSession()).andReturn(session);
		replay(request);
        cardMemberAppDTO=new CardMemberAppDTO();
        cardMemberAppDTO.setFlowType("shorpa");
        cardMemberAppDTO.setStableAndSingleCard(true);
        PricingFeature pricingFeature=new PricingFeature();
        pricingFeature.setBasicFeeCode("3");
        Status status=new Status();
        status.setStatusCode("00");
        Reason reason=new Reason();
        reason.setReasonCode(1013);
        reason.setReasonMsg("ReasonMessage");
        List<Reason> errorList = new ArrayList<Reason>();
        errorList.add(reason);
        status.setErrorList(errorList);
        acquisitionResponse =new AcquisitionResponse();
        acquisitionResponse.setAcquisitionStatus(status);
        acquisitionResponse.setPricingFeature(pricingFeature);               
        cardMemberHelper=new CardMemberHelper(form, request, response);	
        assertNull(cardMemberHelper.getCookiedFEPLoginResponse(redesignAppForm));
        verify(request);
	   }*/
	
	
	
	/*@Test
	public void testgetFEPLoginResponse(){
		cardMemberAppDTO= new CardMemberAppDTO();
		cardMemberAppDTO.setFlowType("shortpa");
		RedesignOSBNForm redesignAppForm=new RedesignOSBNForm();
		AcquisitionRequest acquisitionRequest = new AcquisitionRequest();
		FEPRequestMapper fepRequestMapper = new FEPRequestMapper();
		AcquisitionResponse acquisitionResponse =new AcquisitionResponse();
		PricingFeature pricingFeature=new PricingFeature();
		pricingFeature.setBasicFeeCode("3");
		pricingFeature.setChargeIndicator("12345");
		acquisitionResponse.setPricingFeature(pricingFeature);
		CardMemberFepResponseMapper cardMemberFepResponseMapper=new CardMemberFepResponseMapper(acquisitionResponse);												
		assertNotNull(cardMemberHelper.getFEPLoginResponse(redesignAppForm));		    
	}*/

}