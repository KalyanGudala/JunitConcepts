/*
 * -------------------------------------------------------------------------
 *
 * (C) Copyright / American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.
 *
 * -------------------------------------------------------------------------
 */

package com.americanexpress.acquisitions.open.web.managers;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.americanexpress.acquisitions.commons.log.AcquisitionsLogger;
import com.americanexpress.acquisitions.commons.log.constants.Group;
import com.americanexpress.acquisitions.commons.log.event.AppReportEvent;
import com.americanexpress.acquisitions.commons.traversepath.TraversePath;
import com.americanexpress.acquisitions.commons.traversepath.TraversePathConstants;
import com.americanexpress.acquisitions.commons.traversepath.TraversePathUtil;
import com.americanexpress.acquisitions.commons.url.constants.URLConstants;
import com.americanexpress.acquisitions.open.commons.common.EOICookie;
import com.americanexpress.acquisitions.open.commons.common.SSOCookie;
import com.americanexpress.acquisitions.open.commons.common.constants.Constants;
import com.americanexpress.acquisitions.open.commons.common.constants.ErrorConstants;
import com.americanexpress.acquisitions.open.commons.common.constants.OPENConstants;
import com.americanexpress.acquisitions.open.commons.formbeans.RedesignOSBNForm;
import com.americanexpress.acquisitions.open.commons.mapper.FEPRequestMapper;
import com.americanexpress.acquisitions.open.commons.url.constants.OPENURLConstants;
import com.americanexpress.acquisitions.open.constants.OPENRedesignConstants;
import com.americanexpress.acquisitions.open.web.beans.CardMemberAppDTO;
import com.americanexpress.acquisitions.services.ccc.domain.AcquisitionRequest;
import com.americanexpress.acquisitions.services.ccc.domain.AcquisitionResponse;
import com.americanexpress.acquisitions.services.ccc.domain.CardData;
import com.americanexpress.acquisitions.services.ccc.domain.PricingFeature;
import com.americanexpress.acquisitions.services.ccc.domain.Reason;
import com.americanexpress.acquisitions.services.ccc.domain.Status;
import com.americanexpress.wss.shr.authorization.token.SecurityToken;

import org.apache.commons.lang.StringUtils;
import org.apache.struts.action.ActionForm;

/**
 * CardMemberLoginHelper is for validate the user login, if success login will returns the cid/app page events 
 * for unsuccessful logins it will get error messages
 * 
 * @author Stalin Ch
 * @version $Id: CardMemberLoginHelper.java 31294 2013-12-11 13:06:23Z sgajula $
 */
public class CardMemberLoginHelper 
{
	private static final AcquisitionsLogger LOGGER = new AcquisitionsLogger(
												CardMemberLoginHelper.class);
	private static final String CLASS_NAME = "CardMemberLoginHelper";
	private HttpServletRequest request;
	private HttpServletResponse response;
	private CardMemberAppDTO cardMemberAppDTO;
	private HttpSession session ;

	public CardMemberLoginHelper(ActionForm form, HttpServletRequest request,
				 				 HttpServletResponse response) 
	{
		this.request = request;
		this.response = response;
		cardMemberAppDTO = null;
		session = null;
	}

	public HttpServletRequest getRequest() {
		return request;
	}

	
	/*public MutableAttributeMap getReqAttrMap() {
		return reqAttrMap;
	}*/

	public CardMemberAppDTO getCardMemberAppDTO() {
		return cardMemberAppDTO;
	}
	
	/**
	 * This method will validate the user name and password ,if success login will returns the cid/app page based on the 
     * no of cards and stability and risk score
     * if un-success full attempt it will show the appropriate error message
     * 
	 * @param loginForm
	 * @return String
	 */
	public String validateUserLoginInfo(RedesignOSBNForm redesignOSBNForm)
	{
		LOGGER.entry(Group.OPEN, OPENConstants.BUSINESS_UNIT);
		session = request.getSession(false);
		cardMemberAppDTO = (CardMemberAppDTO)session.getAttribute(OPENConstants.CARDMEMBERAPP_DTO);
		final String METHOD_NAME = "processLoginInfo";
		String statusDesc =OPENConstants.OPEN_FAILURE_STATUS;
		String statusFlag = TraversePathConstants.TRAVERSE_PATH_FAILURE;
		StringBuilder tPathCompBuilder=new StringBuilder();
	   	tPathCompBuilder.append(CLASS_NAME).append( URLConstants.COLON ).append(METHOD_NAME);
	   	String 	tPathCompName=tPathCompBuilder.toString();
		String traversePathKey = TraversePath.startComponentCall(tPathCompName);
		String mainFlow = null;
		String subFlow = null;
		String pageName = null;
		PricingFeature pricingFeature = null;
		Hashtable ratesHT = null;
		
		try 
		{
			FEPRequestMapper fepRequestMapper = new FEPRequestMapper();						
			//String flowType = cardMemberAppDTO.getFlowType();			
			session.setAttribute(OPENConstants.SHORTNPA_OPTION, OPENConstants.TRUE);
			mainFlow = OPENConstants.FLOW_TYPE_SHORT_NPA;
            subFlow = OPENConstants.SUB_FLOW_CARDSELECTORPAGE;
			
			AcquisitionRequest acquisitionRequest = fepRequestMapper.buildShortAppFepRequestBean(request, response,
													redesignOSBNForm, Constants.OPEN_APP, mainFlow, subFlow);
			acquisitionRequest.setApplicationExperienceKey(com.americanexpress.acquisitions.services.ccc.commons.Constants.RWD_CM_STR);
			/*if(LOGGER.isDebugEnabled()){
			LOGGER.debug(Group.OPEN, OPENConstants.BUSINESS_UNIT_ACTION,
					"CardMemberLoginAction --- CardMemberLoginHelper acquisitionRequest :"
							+ acquisitionRequest);
		}*/
		AcquisitionResponse acquisitionResponse = fepRequestMapper
										.fepResponseBuilder(acquisitionRequest);
			
		if (isInvalidAcquisitionResponse(acquisitionResponse))
			return OPENConstants.USER_ID_LOGIN_FAILURE;
			
		if (LOGGER.isDebugEnabled()) 
				LOGGER.debug(Group.OPEN, OPENConstants.BUSINESS_UNIT_ACTION,
					"CardMemberLoginAction --- CardMemberLoginHelper acquisitionResponse :"
							+ acquisitionResponse);

		CardMemberFepResponseMapper cardMemberFepResponseMapper = 
		new CardMemberFepResponseMapper(acquisitionResponse);
			
		String status = cardMemberFepResponseMapper.getAcqStatusText();
		if (StringUtils.isNotEmpty(status) && OPENConstants.SUCCESS
											.equalsIgnoreCase(status)) 
		{
				Map<String,String> intlCMDataObj = acquisitionResponse.getIntlCardMemberData();
				boolean isIntlCM = acquisitionResponse.isInvalidShortFlowUser();
				if(isIntlCM && intlCMDataObj != null && !intlCMDataObj.isEmpty()){
					redesignOSBNForm.setFirstName(intlCMDataObj.get(com.americanexpress.acquisitions.services.ccc.commons.Constants.FIRST_NAME));
					redesignOSBNForm.setLastName(intlCMDataObj.get(com.americanexpress.acquisitions.services.ccc.commons.Constants.LAST_NAME));					
					session.setAttribute(OPENConstants.INTL_CM_ACCNTNUM, intlCMDataObj.get(com.americanexpress.acquisitions.services.ccc.commons.Constants.ACCOUNT_NUMBER));
					pageName = OPENConstants.INTL_CM_PREFILL;
					session.setAttribute(OPENConstants.INTL_CARD_MEMBER, isIntlCM);
				}else{
			cardMemberFepResponseMapper.updateDTOForFepUserLogonInfo(
										cardMemberAppDTO, session);
				
			if (isInValidUserResponse(acquisitionResponse))
				return OPENConstants.USER_ID_LOGIN_FAILURE;
				
			setBlueBoxCookies();
			boolean stableAndSingleCard = cardMemberAppDTO
										  .getIsStableAndSingleCard();
			request.setAttribute(OPENConstants.ACQ_RESPONSE, acquisitionResponse);
			request.setAttribute(OPENConstants.CARDMEMBERAPP_DTO, cardMemberAppDTO);
			session.removeAttribute(OPENConstants.CARDMEMBERAPP_DTO);
			session.setAttribute(OPENConstants.CARDMEMBERAPP_DTO, cardMemberAppDTO);
			request.setAttribute(OPENConstants.USERTOTAL_CARDS_TABLE,
								 cardMemberAppDTO.getUserCards());
			
			/*if (LOGGER.isInfoEnabled())
					LOGGER.info(Group.OPEN, OPENConstants.BUSINESS_UNIT_ACTION,
						"stableAndSingleCard: " + stableAndSingleCard);*/
				
			if (stableAndSingleCard) 
					pageName = OPENConstants.APPLICATION_PAGE;
			else
				pageName = OPENConstants.CARD_SELECTOR_PAGE;
					}
				
			} else {
				LOGGER.error(Group.OPEN, OPENConstants.BUSINESS_UNIT_ACTION,
						"CardMemberLoginAction --- CardMemberLoginHelper acquisitionResponse is  invalid",null);
				HashMap<String, String> errorMap = new HashMap<String, String>();
				errorMap.put(OPENConstants.SYSDOWN_ERROR_CODE,OPENConstants.SYSDOWN_ERROR_DESC);
				request.setAttribute(OPENConstants.CREDENTIALS_ERRORS, errorMap);
				pageName = OPENConstants.USER_ID_LOGIN_FAILURE;
			}
			statusFlag = TraversePathConstants.TRAVERSE_PATH_SUCCESS;
			statusDesc = OPENConstants.OPEN_SUCCESS;
		}catch (Exception exe){
			LOGGER.error(Group.OPEN, OPENConstants.BUSINESS_UNIT_ACTION,
					"CardMemberLoginAction --- CardMemberLoginHelper acquisitionResponse parsing exception "+exe.getMessage(), null);
			exe.printStackTrace();
			
		}
			finally {
		
			TraversePath.endComponentCall(traversePathKey, tPathCompName,
					OPENURLConstants.PARSER_TRV_VERSION, statusFlag, 0,
					statusDesc);			
			AppReportEvent appReport = new AppReportEvent(getRequest(),
					cardMemberAppDTO!=null?cardMemberAppDTO.getCardType():null, statusDesc,
					statusFlag, Group.OPEN, null, cardMemberAppDTO!=null?cardMemberAppDTO.getCardType():null, null, null,
							OPENConstants.OPEN_SHORTAPP_CIDORAPPPAGE, statusDesc,
							OPENConstants.OPEN_SHORTAPP_CIDORAPPPAGE);
			TraversePathUtil.setWebEndInfo(Group.CCSG, METHOD_NAME, 0, null,
					appReport);
			
		}
		LOGGER.exit(Group.OPEN, OPENConstants.BUSINESS_UNIT);
		return pageName;
	}
	
	
/**
 * This method will validate the user fep response if valid then returns the false
 * other wise it will returns true and will kept the error message in conversion scope 
 * 
 * @param acquisitionResponse
 * @return boolean
 */
public boolean isInValidUserResponse(AcquisitionResponse acquisitionResponse)
{
	LOGGER.entry(Group.OPEN, OPENConstants.BUSINESS_UNIT);
	
	boolean isError = false;
	List<CardData> cardList = cardMemberAppDTO.getCardDataList();
	String publicGuid = cardMemberAppDTO.getPublicGuid();
	SecurityToken securityToken = cardMemberAppDTO.getSecurityToken();
	String sortedIndex =cardMemberAppDTO.getSortedIndex();
	Map<String, String> errorMap =null;
	if (publicGuid == null || securityToken ==null || cardList == null || cardList.isEmpty()) 
	{
		errorMap = new HashMap<String, String>();
		errorMap.put(OPENConstants.SYSDOWN_ERROR_CODE,OPENConstants.SYSDOWN_ERROR_DESC);
		LOGGER.error(Group.OPEN, OPENConstants.BUSINESS_UNIT_ACTION,
				"CardMemberLoginAction --- CardMemberLoginHelper NOT A VALID USER",null);	
    }
	else if(sortedIndex != null && sortedIndex.equals(OPENConstants.MINUSONE_INDEX) )
	{
		errorMap = new HashMap<String, String>();
		errorMap.put(OPENConstants.SYSDOWN_ERROR_CODE,OPENConstants.SYSDOWN_ERROR_DESC);
		LOGGER.error(Group.OPEN, OPENConstants.BUSINESS_UNIT_ACTION,
				"CardMemberLoginAction --- CardMemberLoginHelper USER CARDS ARE EMPTY",null);	
	}
	else if (URLConstants.FLOW_TYPE_SHORT_PA.equals(cardMemberAppDTO.getFlowType())) 
	{
		String ispreApproved = acquisitionResponse
				.getPreApprovedStatus();
		if (ispreApproved == null
				|| OPENConstants.FALSE
						.equalsIgnoreCase(ispreApproved)) {
			errorMap = new HashMap<String, String>();
			errorMap.put(OPENConstants.SYSDOWN_ERROR_CODE,OPENConstants.SYSDOWN_ERROR_DESC);
			LOGGER.error(Group.OPEN, OPENConstants.BUSINESS_UNIT_ACTION,
					"CardMemberLoginAction --- CardMemberLoginHelper OFFER IS NOT VALID FOR THE USER",null);		
			}
	}
	if (errorMap != null && !errorMap.isEmpty()) {
		request.setAttribute(OPENConstants.CREDENTIALS_ERRORS, errorMap);
		isError=true;
	}
	LOGGER.exit(Group.OPEN, OPENConstants.BUSINESS_UNIT);
	return isError;
}

	/**
     * This method will validate the user fep response if valid then returns the false
     * other wise it will returns true and will kept the error message in conversion scope 
     * 
	 * @param acquisitionResponse
	 * @return boolean
	 */
	public boolean isInvalidAcquisitionResponse(AcquisitionResponse acquisitionResponse) {
		boolean error = false;
		List<Reason> errorList = null;
		Map<String, String> errorMap = new HashMap<String, String>();
		
		if (acquisitionResponse!=null && acquisitionResponse.getAcquisitionStatus() != null) {
			Status acqStatus=acquisitionResponse.getAcquisitionStatus();
			
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug(Group.OPEN, OPENConstants.BUSINESS_UNIT, acqStatus
					.toString());
			}
			errorList = acqStatus.getErrorList();
			for (Reason reason : errorList) {
				/*if(LOGGER.isInfoEnabled()){
				LOGGER.info(Group.OPEN, "CardMemberLoginAction --- CardMemberLoginHelper", " reason : " + reason);
				}*/
				if ((reason.getReasonCode() == ErrorConstants.ERROR_CODE_2641
						|| reason.getReasonCode() == ErrorConstants.ERROR_CODE_15
						|| reason.getReasonCode() == ErrorConstants.ERROR_CODE_2642 || reason
						.getReasonCode() == ErrorConstants.ERROR_CODE_2643)) {
						errorMap
								.put(OPENRedesignConstants.CREDENTIALS_ERROR_CODE,
										OPENConstants.FIRSTATTEMPT_CREDENTIALS_DESC);
				} else if ((reason.getReasonCode() == ErrorConstants.ERROR_CODE_18)
						|| (reason.getReasonCode() == ErrorConstants.ERROR_CODE_15)) {
					errorMap
							.put(
									OPENRedesignConstants.CREDENTIALS_ERROR_CODE,
									OPENConstants.SECONDATTEMPT_INVALIDCREDENTIALS_DESC);
				} else if ((reason.getReasonCode() == ErrorConstants.ERROR_CODE_16)
						|| (reason.getReasonCode() == ErrorConstants.ERROR_CODE_19)) {
					errorMap
							.put(
									OPENRedesignConstants.THREE_STRIKE_ERROR_CODE,
									OPENConstants.THIRDATTEMPT_INVALIDCREDENTIALS_DESC);
				} else {
					errorMap
							.put(
									OPENRedesignConstants.CREDENTIALS_ERROR_CODE,
									OPENConstants.SYSDOWN_ERROR_DESC);
				}
			}
			
		}else{
			LOGGER.error(Group.OPEN, OPENConstants.BUSINESS_UNIT_ACTION,
					"CardMemberLoginAction --- CardMemberLoginHelper acquisitionResponse is null or invalid",null);
			errorMap.put(OPENConstants.SYSDOWN_ERROR_CODE,OPENConstants.SYSDOWN_ERROR_DESC);
		}
		
		if (!errorMap.isEmpty()) {
			request.setAttribute(OPENConstants.CREDENTIALS_ERRORS, errorMap);
			error = true;
		}
		
		LOGGER.exit(Group.OPEN, OPENConstants.BUSINESS_UNIT);
		return error;
	}
	/**
     * This method will set the SOI and EOI cookies to browser
     * 
	 * @param 
	 * @return 
	 */
	public void setBlueBoxCookies() 
	{
		SecurityToken securityToken = cardMemberAppDTO.getSecurityToken();
		String publicGuid = cardMemberAppDTO.getPublicGuid();
		String sessionid = securityToken.getSessionID().trim();		
		EOICookie.getInstance().setCookie(sessionid, response);
		SSOCookie.getInstance().setCookie(publicGuid, response);
	}
}
