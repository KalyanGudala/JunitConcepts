/*
 * -------------------------------------------------------------------------
 *
 * (C) Copyright / American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.
 *
 * -------------------------------------------------------------------------
 */

package com.americanexpress.acquisitions.open.web.managers;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.americanexpress.acquisitions.commons.log.AcquisitionsLogger;
import com.americanexpress.acquisitions.commons.log.constants.Group;
import com.americanexpress.acquisitions.commons.log.event.AppReportEvent;
import com.americanexpress.acquisitions.commons.traversepath.TraversePath;
import com.americanexpress.acquisitions.commons.traversepath.TraversePathConstants;
import com.americanexpress.acquisitions.commons.traversepath.TraversePathUtil;
import com.americanexpress.acquisitions.commons.url.constants.URLConstants;
import com.americanexpress.acquisitions.open.commons.common.constants.AppConstants;
import com.americanexpress.acquisitions.open.commons.common.constants.Constants;
import com.americanexpress.acquisitions.open.commons.common.constants.Keys;
import com.americanexpress.acquisitions.open.commons.common.constants.OPENConstants;
import com.americanexpress.acquisitions.open.commons.common.constants.Pages;
import com.americanexpress.acquisitions.open.commons.common.domain.Customer;
import com.americanexpress.acquisitions.open.commons.common.domain.Product;
import com.americanexpress.acquisitions.open.commons.formbeans.RedesignOSBNForm;
import com.americanexpress.acquisitions.open.commons.mapper.FEPRequestMapper;
import com.americanexpress.acquisitions.open.commons.mapper.constants.OPENMapperConstants;
import com.americanexpress.acquisitions.open.commons.shortapp.helper.SBSHelper;
import com.americanexpress.acquisitions.open.commons.url.constants.OPENURLConstants;
import com.americanexpress.acquisitions.open.commons.utilframework.ValidationInfo;
import com.americanexpress.acquisitions.open.commons.utilframework.validations.SSNValidation;
import com.americanexpress.acquisitions.open.constants.OPENRedesignConstants;
import com.americanexpress.acquisitions.open.web.beans.CardMemberAppDTO;
import com.americanexpress.acquisitions.services.ccc.commons.ErrorConstants;
import com.americanexpress.acquisitions.services.ccc.domain.AcquisitionRequest;
import com.americanexpress.acquisitions.services.ccc.domain.AcquisitionResponse;
import com.americanexpress.acquisitions.services.ccc.domain.CardData;
import com.americanexpress.acquisitions.services.ccc.domain.FormData;
import com.americanexpress.acquisitions.services.ccc.domain.Reason;
import com.americanexpress.acquisitions.services.ccc.domain.SecurityData;
import com.americanexpress.acquisitions.services.ccc.domain.Status;

import org.apache.commons.lang.StringUtils;
import org.apache.struts.action.ActionForm;

/**
 * CardMemberValidationHelper
 * CardMemberValidationHelper will validate the card account, ssn info and get the crps response
 * 
 * @author Stalin Ch
 * 
 * @version $Id: CardMemberValidationHelper.java 31295 2013-12-11 13:06:53Z sgajula $
 */
public class CardMemberValidationHelper 
{
	private final HttpServletRequest request;
	private final HttpServletResponse response;
	private final HttpSession session;
	private CardMemberAppDTO cardMemberAppDTO;
	private static final AcquisitionsLogger LOGGER = new AcquisitionsLogger(
			CardMemberValidationHelper.class);
	private final String CLASS_NAME = this.getClass().getSimpleName();

	public CardMemberValidationHelper(ActionForm form, HttpServletRequest request,
			 						  HttpServletResponse response) 
	{
		this.request = request;
		session = request.getSession(false);
		assert request != null;
		this.response = response;
		assert response != null;
		cardMemberAppDTO = (CardMemberAppDTO) session.getAttribute(OPENConstants.CARDMEMBERAPP_DTO);
		
	}

	public HttpServletRequest getRequest() {
		return request;
	}

	public CardMemberAppDTO getCardMemberAppDTO() 
	{
		return cardMemberAppDTO;
	}

	/**
	 * This method will execute if user will come from option-1 login and enters
	 * the cid , method will validate the card info and get CRPSData
	 * 
	 * @param redesignAppForm
	 * @return String
	 */
	public String validateUserCardInfo(final RedesignOSBNForm redesignOSBNForm) {
		LOGGER.entry(Group.OPEN, OPENConstants.BUSINESS_UNIT);
		
		String METHOD_NAME = "validateUserCardInfo";
		String statusFlag = TraversePathConstants.TRAVERSE_PATH_FAILURE;
		String statusDesc = OPENConstants.OPEN_FAILURE_STATUS;
		StringBuilder tPathCompBuilder=new StringBuilder();
	   	tPathCompBuilder.append(CLASS_NAME).append( URLConstants.COLON ).append(METHOD_NAME);
	   	String 	componentName=tPathCompBuilder.toString();
		TraversePathUtil.setWebStartInfo(request);
		String tpathKey = TraversePath.startComponentCall(componentName);
		
		String flow = null;
		String subFlow = null;
		String eventName = null;
		try {
			if(cardMemberAppDTO!=null){
			String flowType = cardMemberAppDTO.getFlowType();			
			if (URLConstants.FLOW_TYPE_SHORT_NPA.equals(flowType)) {
				flow = OPENConstants.FLOW_TYPE_SHORTNPAOPTION1;
				subFlow = OPENConstants.SUB_FLOWTYPE_APPLICATION;
			} else if (URLConstants.FLOW_TYPE_SHORT_PA.equals(flowType)) {
				flow = OPENConstants.FLOW_TYPE_SHORTAPPPA;
				subFlow = OPENConstants.SUB_FLOWTYPE_APPLICATION;
			}
			
			updateFormWithCardDataBySortedIndex(redesignOSBNForm);
			redesignOSBNForm.setSecurityToken(cardMemberAppDTO
					.getSecurityToken());
			redesignOSBNForm.setPublicGuid(cardMemberAppDTO.getPublicGuid());
			String isStableID = cardMemberAppDTO.getStableId();
			FEPRequestMapper fepRequestMapper = new FEPRequestMapper();
			AcquisitionRequest acquisitionRequest=	fepRequestMapper.buildShortAppFepRequestBean(request, response,
					redesignOSBNForm, Constants.OPEN_APP,
					flow, subFlow);
			if (isStableID != null
					&& OPENConstants.YES_Y.equalsIgnoreCase(isStableID)) {
				acquisitionRequest.getFormData().setStable(true);

			}
			
			if (LOGGER.isDebugEnabled()) {
			LOGGER
					.debug(
							Group.OPEN,
							OPENConstants.BUSINESS_UNIT_ACTION,
							"CardMemberValidationAction --- CardMemberValidationHelper acquisitionRequest :"
									+ acquisitionRequest);
			}
			AcquisitionResponse acquisitionResponse = fepRequestMapper
					.fepResponseBuilder(acquisitionRequest);
			if (LOGGER.isDebugEnabled()) {
			LOGGER
					.debug(
							Group.OPEN,
							OPENConstants.BUSINESS_UNIT_ACTION,
							"CardMemberValidationAction --- CardMemberValidationHelper acquisitionResponse :"
									+ acquisitionResponse);
			}
			CardMemberFepResponseMapper cardMemberFepResponseMapper = new CardMemberFepResponseMapper(
					acquisitionResponse);
			if (isInValidAcquisitionResponse(acquisitionResponse)) {
				return OPENConstants.USER_ID_LOGIN_FAILURE;
			}
			
			session.setAttribute(AppConstants.ACQUISITION_REQUEST,
					acquisitionRequest);
			session.setAttribute("AcquisitionResponse", acquisitionResponse);
			
			String status = cardMemberFepResponseMapper.getAcqStatusText();
			FormData formData = acquisitionResponse.getFormData();
			if (StringUtils.isNotEmpty(status)
					&& OPENConstants.OPEN_SUCCESS_STATUS
							.equalsIgnoreCase(status) && null != formData) {
				if (!isValidCRPSResponse(formData, redesignOSBNForm)) {
					return OPENConstants.USER_ID_LOGIN_FAILURE;
				}
				if (cardMemberAppDTO.getIsBusenessTypeIndReq()) {
					//redesignAppForm.setRoleInCompany(OPENConstants.ONE);
				}
				eventName = OPENConstants.SUCESS;
			} else {
				eventName = Pages.SYSTEM_ERROR;
			}
			statusFlag = TraversePathConstants.TRAVERSE_PATH_SUCCESS;
			statusDesc = OPENConstants.OPEN_SUCCESS_STATUS;
		}}finally {
			TraversePath.endComponentCall(tpathKey, componentName,
					OPENURLConstants.PARSER_TRV_VERSION, statusFlag, 0,
					statusDesc);
			AppReportEvent appReport = new AppReportEvent(request,
					cardMemberAppDTO!=null?cardMemberAppDTO.getCardType():null, statusDesc,
					statusFlag, Group.OPEN, null,cardMemberAppDTO!=null?cardMemberAppDTO.getCardType():null, null, null,
					OPENConstants.OPEN_SHORTAPP_APPLICATION, statusDesc,
					OPENConstants.OPEN_SHORTAPP_APPLICATION);
			TraversePathUtil.setWebEndInfo(Group.CCSG, METHOD_NAME, 0, null,
					appReport);
		}
		LOGGER.exit(Group.OPEN, OPENConstants.BUSINESS_UNIT);
		return eventName;
	}

	/**
	 * This method will execute if user will come from NPA option-2 login ,
	 * validate the card info and get CRPSData
	 * 
	 * @param redesignAppForm
	 * @return
	 */
	public String validateUserSSNInfo(final RedesignOSBNForm redesignOSBNForm) {
		LOGGER.entry(Group.OPEN, OPENConstants.BUSINESS_UNIT);
		String METHOD_NAME = "validateUserSSNInfo()";
		
		String statusFlag = TraversePathConstants.TRAVERSE_PATH_FAILURE;
		String statusDesc = OPENConstants.OPEN_FAILURE_STATUS;
		
		StringBuilder tPathCompBuilder=new StringBuilder();
   	    tPathCompBuilder.append(CLASS_NAME).append( URLConstants.COLON ).append(METHOD_NAME);
   	    String 	componentName=tPathCompBuilder.toString();
		TraversePathUtil.setWebStartInfo(request);
		String tpathKey = TraversePath.startComponentCall(componentName);
		
		AcquisitionResponse acquisitionResponse = null;
		try {
			
			AcquisitionRequest acquisitionRequest = new AcquisitionRequest();
			FEPRequestMapper fepRequestMapper = new FEPRequestMapper();
			
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug(Group.OPEN, OPENMapperConstants.BUSINESS_UNIT,
						"Calling FEP Request Builder: ");
			}
			String sCardType = cardMemberAppDTO.getCardType();
		
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug(Group.OPEN, OPENMapperConstants.BUSINESS_UNIT,
						"Calling FEP Service: ");
			}
			String keynoteParam = request
					.getParameter(OPENConstants.KEYNOTE_PARAM);
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug(Group.OPEN, OPENMapperConstants.BUSINESS_UNIT,
						"keynoteParam: " + keynoteParam);
			}
			if (OPENConstants.KEYNOTE_CT.equals(sCardType)
					&& StringUtils.isNotEmpty(keynoteParam)
					&& OPENConstants.TRUE.equals(keynoteParam)) {
				fepRequestMapper.buildFEPRequestBean(request, response,
						acquisitionRequest, redesignOSBNForm,
						Constants.OPEN_APP,
						OPENConstants.KEYNOTE_HEARTBEATFLOW,
						OPENConstants.KEYNOTE_HEARTBEATSUBFLOW);
				 acquisitionResponse = fepRequestMapper
				.fepResponseBuilder(acquisitionRequest);
				
				if ((acquisitionResponse == null)
						|| (acquisitionResponse.getAcquisitionStatus() == null)) {
					if (LOGGER.isDebugEnabled()) {
					LOGGER.debug(METHOD_NAME, cardMemberAppDTO.getAppId(),
							"Acquisition response is either null or invalid"
									+ session);
					}
					return Pages.SYSTEM_ERROR;
				}
				int gnaCount = acquisitionResponse.getFormData().getGnaCount();
				if (LOGGER.isDebugEnabled()) {
				LOGGER.debug(Group.OPEN, OPENMapperConstants.BUSINESS_UNIT,
						"Keynote gna Count : " + gnaCount);
				}
				if (gnaCount <= 3) {
					request.setAttribute(OPENConstants.KEYNOTE_HRTMSG,
							OPENConstants.GNA_OK);
				} else {
					request.setAttribute(OPENConstants.KEYNOTE_HRTMSG,
							OPENConstants.GNA_NOT_OK);
				}
				return OPENConstants.KEYNOTE_HRTBTPAGE;
			} else {
				
				fepRequestMapper.buildFEPRequestBean(request, response,
						acquisitionRequest, redesignOSBNForm,
						Constants.OPEN_APP, OPENConstants.OPEN_NPASA_FLOW,
						OPENConstants.MISSINGDETAILS);
				
			}
			
		    String	accountNumber = redesignOSBNForm.getAmexCardNumber();
		    SecurityData securityData = new SecurityData();
			securityData.setCid(redesignOSBNForm.getCidNum());
			securityData.setSsn(redesignOSBNForm.getSocialSecurity3());
			securityData.setCardAccountNumber(accountNumber);
			session.setAttribute(Keys.ACCOUNTNUMBER, accountNumber);
			acquisitionRequest.setSecurityData(securityData);

			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug(Group.OPEN, OPENMapperConstants.BUSINESS_UNIT,
						"acquisitionRequest: " + acquisitionRequest);
			}
			
			 acquisitionResponse = fepRequestMapper
			.fepResponseBuilder(acquisitionRequest);
			if (isInValidAcquisitionResponse(acquisitionResponse)) {
				return OPENConstants.USER_ID_LOGIN_FAILURE;
			}
			
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug(Group.OPEN, OPENMapperConstants.BUSINESS_UNIT,
						"acquisitionResponse: " + acquisitionResponse);
			}
			session.setAttribute(OPENConstants.ACQ_RESPONSE,
					acquisitionResponse);
			session.setAttribute(AppConstants.ACQUISITION_REQUEST,
					acquisitionRequest);
			CardMemberFepResponseMapper cardMemberFepResponseMapper = new CardMemberFepResponseMapper(
					acquisitionResponse);
			FormData formData = acquisitionResponse.getFormData();
			String status = cardMemberFepResponseMapper.getAcqStatusText();
			if (StringUtils.isNotEmpty(status)
					&& OPENConstants.OPEN_SUCCESS_STATUS
							.equalsIgnoreCase(status) && null != formData) {
				if (!isValidCRPSResponse(formData, redesignOSBNForm)) {
					return OPENConstants.USER_ID_LOGIN_FAILURE;
				}
				String customerType = formData.getCustomerType();
				if (customerType != null
						&& customerType
								.equalsIgnoreCase(OPENConstants.OSBN_CUSTOMER)) {
					cardMemberAppDTO.setBusenessTypeIndReq(true);
					redesignOSBNForm.setRoleInCompany(OPENConstants.ONE);
				}
			}
			statusFlag = TraversePathConstants.TRAVERSE_PATH_SUCCESS;
			statusDesc = OPENConstants.OPEN_SUCCESS_STATUS;
		} finally {
			TraversePath.endComponentCall(tpathKey, componentName,
					OPENURLConstants.PARSER_TRV_VERSION, statusFlag, 0,
					statusDesc);
			AppReportEvent appReport = new AppReportEvent(request,
					getCardMemberAppDTO().getCardType(), statusDesc,
					statusFlag, Group.OPEN, null, getCardMemberAppDTO()
							.getCardType(), null, null,
					OPENConstants.OPEN_SHORTAPP_APPLICATION, statusDesc,
					OPENConstants.OPEN_SHORTAPP_APPLICATION);
			TraversePathUtil.setWebEndInfo(Group.CCSG, METHOD_NAME, 0, null,
					appReport);
		}
		LOGGER.exit(Group.OPEN, OPENConstants.BUSINESS_UNIT);
		return OPENConstants.SUCESS;
	}

	/**
	 * This method will populates the crps data using with
	 * acquisitionResponse-FormData
	 * 
	 * @param acquisitionResponse
	 * @param redesignAppForm
	 * @return boolean
	 */
	private boolean isValidCRPSResponse(final FormData formData,
			 RedesignOSBNForm redesignOSBNForm) {
		LOGGER.entry(Group.OPEN, OPENConstants.BUSINESS_UNIT);
		Product product = null;
		String productType = null;
		String method = "populateCRPSdata";
		String sCardType = cardMemberAppDTO.getCardType();
		Customer customerFile = null;
		try {
			customerFile = new Customer();
			Product.initializeProducts();
			if (LOGGER.isDebugEnabled()) {
				LOGGER
						.debug(method, "", "after  contacting to CRPS"
								+ formData);
			}
			product = Product.getProduct(sCardType);
			productType = product.getType();

			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug(method, "", "before preparing customer file ");
			}
			customerFile = SBSHelper.prepareCustomerFile(formData, sCardType,
					productType);
			// Customer SSN from the Backend systems.
			String customerFileSSN = customerFile.getField(Customer.SSN);
			String backendlastname = customerFile.getField(Customer.LAST_NAME);
			String customerFileLast4SSN = OPENConstants.EMPTYSTRING;
			SSNValidation ssnv = new SSNValidation();
			if(StringUtils.isNotEmpty(customerFileSSN) && !customerFileSSN.equals(OPENConstants.HASH)){
				ValidationInfo validationInfo = ssnv.validate(customerFileSSN);
				boolean invalidssn = !(validationInfo.isValid());
				if (invalidssn) {
					LOGGER.error(method, "", "SSN coming from CRPS is invalid : "
							+ customerFileSSN, null);
					Map<String, String> errorMap = new HashMap<String, String>();
					errorMap
							.put(
									OPENConstants.SYSDOWN_ERROR_CODE,
									OPENConstants.SYSDOWN_ERROR_DESC);
					request.setAttribute(OPENConstants.CREDENTIALS_ERRORS, errorMap);
					return false;
				}	
				 customerFileLast4SSN = (customerFileSSN.length() == 9) ? customerFileSSN
						.substring(5)
						: OPENConstants.EMPTYSTRING;
			}
			LOGGER.error(method, "", "  Back end last name : "
					+ backendlastname, null);
			if (backendlastname == null
					|| (backendlastname.trim().length() < 1)
					/*|| (redesignOSBNForm.getSocialSecurityNumber() != null && !redesignOSBNForm
							.getSocialSecurityNumber().equalsIgnoreCase(
									customerFileLast4SSN.trim()))*/) {
				if (LOGGER.isDebugEnabled()) {
				LOGGER
						.debug(method, "",
								"Received wrong lastname and SSN data from CRPS or SSN mismatch");
				LOGGER.debug(method, "", "lastname :" + backendlastname
						+ " and SSN :" + customerFileSSN);
				}
				Map<String, String> errorMap = new HashMap<String, String>();
				errorMap
						.put(
								OPENConstants.SYSDOWN_ERROR_CODE,
								OPENConstants.SYSDOWN_ERROR_DESC);
				//reqScopeMap.put(OPENConstants.CREDENTIALS_ERRORS, errorMap);
				return false;
			}
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug(method, "", "after preparing customer file ");
			}
			LOGGER.error(method, "", " Before Preparing the RedesignAppForm from the CustomerFile  "
					, null);
			Hashtable customerFileValidationHash = customerFile.getFields();
			CustomerFileVSFormBean custFile = new CustomerFileVSFormBean();
			custFile.customerFileToRedesignAppForm(redesignOSBNForm,
					customerFileValidationHash, false, false);
			session.setAttribute(Keys.CUSTOMER_FILE, customerFile);
			// Start:creating a new RedesignAppForm for disable the fields which
			// we got from the crps service and also storing into the conversion
			// scope
			custFile.customerFileToRedesignAppForm(redesignOSBNForm,
					customerFileValidationHash, false, false);
			request.setAttribute(OPENConstants.CMCRPS_REDESIGNFORMFORREVIEW, redesignOSBNForm);
				//	cmCRPSRedesignAppForm);
			LOGGER.error(method, "", " After Preparing the RedesignAppForm from the CustomerFile  "
					, null);
			// End:creating a new RedesignAppForm for disable the fields which
			// we got from the crps service and also storing into the conversion
			// scope
		} catch (Exception unknownException) {
			LOGGER.error(Group.OPEN, "CardMemberValidationHelper",
					"An error occured while : " + " ,unknownException: "
							+ unknownException.getMessage(), null);
			return false;
		}
		// added for PA NPA email retrieval for AppCache
		/*AppCacheForm appCacheForm = (AppCacheForm) session
				.getAttribute("appCacheForm");
		if (appCacheForm != null) {
			AppCacheUtility appcacheUtility = new AppCacheUtility();
			redesignAppForm = appcacheUtility.populateRedesignAppForm(
					redesignAppForm, appCacheForm);
		}*/
		// end: PA NPA email retrieval for AppCache
		// populate appcache email into open SHORT PA/ NPA end//
		// Start:POBOX implementation
		String homeAddress = redesignOSBNForm.getHomeAddress();
		if (StringUtils.isNotEmpty(homeAddress)
				&& isPOBOXPresentInHomeAddress(homeAddress.toUpperCase())) {
			redesignOSBNForm.setPoBoxPresent(OPENConstants.TRUE);
			redesignOSBNForm.setHomeAddress(OPENConstants.EMPTYSTRING);
			redesignOSBNForm.setHomeAddressZip(OPENConstants.EMPTYSTRING);
			redesignOSBNForm.setHomeAddressState(OPENConstants.EMPTYSTRING);
			redesignOSBNForm.setHomeAddressCity(OPENConstants.EMPTYSTRING);
		}
		// End:POBOX implementation
		// Star:always zip code need to ask in the ap page
		redesignOSBNForm.setHomeAddressZip(OPENConstants.EMPTYSTRING);
		redesignOSBNForm.setBusinessZip(OPENConstants.EMPTYSTRING);
		// end:always zip code need to ask in the ap page'
		LOGGER.exit(Group.OPEN, OPENConstants.BUSINESS_UNIT);
		return true;
	}
	/**
	 * this method will returns true if the home address is contains POBOX related String
	 * @param redesignAppForm
	 * @return boolean
	 */
	private boolean isPOBOXPresentInHomeAddress(final String homeAddress) {
		boolean isPoBox = false;
		String[] poboxList = new String[] { "PBOX", "POBOX", "POB", "BOX",
				"P.O.BOX", "POSTOFFICEBOX" };
		for (String hAddress : poboxList) {
			if (homeAddress.indexOf(hAddress) > -1) {
				isPoBox = true;
				break;
			}
		}
		return isPoBox;
	}
	/**
	 * this method will update the Form with cardAccount num based on the sortedIndex
	 * @param redesignAppForm
	 * @return 
	 */
	private void updateFormWithCardDataBySortedIndex(
			final RedesignOSBNForm redesignOSBNForm) {
		String sortedIndex = redesignOSBNForm.getSortedIndex();
		int sortedIndexNum;
		List<CardData> cardList = cardMemberAppDTO.getCardDataList();
		if (StringUtils.isNotEmpty(sortedIndex)) {
			sortedIndexNum = Integer.parseInt(sortedIndex);
			for (CardData cardData : cardList) {
				if (cardData.getSortedIndex() == sortedIndexNum) {
					redesignOSBNForm.setAmexCardNumber(cardData.getAcctNumber());
					break;
				}
			}
		} else if (StringUtils.isNotEmpty(cardMemberAppDTO
				.getAmexCardNumber())) {
			redesignOSBNForm.setAmexCardNumber(cardMemberAppDTO.getAmexCardNumber());
		}
	}

	/**
	 * this methos will return the true if the acquisitionresponse having an
	 * error if not it will return flase
	 * 
	 * @param acqStatus
	 * @param context
	 * @return boolean
	 */

	private boolean isInValidAcquisitionResponse(
			final AcquisitionResponse acquisitionResponse) {
		LOGGER.entry(Group.OPEN, OPENConstants.BUSINESS_UNIT);
		boolean error = false;
		List<Reason> errorList = null;
		Map<String, String> errorMap = new HashMap<String, String>();
		if ( acquisitionResponse != null
				&& acquisitionResponse.getAcquisitionStatus() != null) {
			Status acqStatus = acquisitionResponse.getAcquisitionStatus();
			if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(Group.OPEN, OPENConstants.BUSINESS_UNIT, acqStatus
					.toString());
			}
			errorList = acqStatus.getErrorList();
			for (Reason reason : errorList) {
				if (LOGGER.isDebugEnabled()) {
				LOGGER.debug(Group.OPEN, OPENConstants.BUSINESS_UNIT, acqStatus
						.toString());
				}
				int reasonCode =reason.getReasonCode();
				String reasonMsg=reason.getReasonMsg();
				if ((reasonCode == ErrorConstants.CARD_VERIFICATION_SERVICE_CODE && (OPENConstants.CARDALREADYLOKED_MSG
						.equalsIgnoreCase(reasonMsg) || OPENConstants.VERIFICATION_LOCKOUT_MSG
						.equalsIgnoreCase(reasonMsg)))) {
					errorMap
							.put(
									OPENRedesignConstants.THREE_STRIKE_ERROR_CODE,
									OPENConstants.ERR_MESSAGE_ACCOUNT_NUM_LOCKED_OUT);
				} else if ((reasonCode == ErrorConstants.CARD_VERIFICATION_SERVICE_CODE || reason
						.getReasonCode() == ErrorConstants.CODE_3052)) {
					String check3StrikeForCid = cardMemberAppDTO
							.getThreeStrikeCntrForCid();
					if (check3StrikeForCid == null) {
						cardMemberAppDTO
								.setThreeStrikeCntrForCid(OPENConstants.ONE);
						errorMap
								.put(OPENRedesignConstants.CREDENTIALS_ERROR_CODE,
										OPENConstants.FIRSTATTEMPT_INVALID_ACCOUNTINFO);
					} else {
						int strikeout = 0;
						strikeout = Integer.parseInt(check3StrikeForCid);
						if (strikeout == 1) {
							cardMemberAppDTO
									.setThreeStrikeCntrForCid(OPENConstants.TWO);
							errorMap
									.put(
											OPENRedesignConstants.CREDENTIALS_ERROR_CODE,
											OPENConstants.SECONDATTEMPT_INVALID_ACCOUNTINFO);
						} else if (strikeout >= 2) {
							cardMemberAppDTO
									.setThreeStrikeCntrForCid(OPENConstants.THREE);
							errorMap
									.put(
											OPENRedesignConstants.THREE_STRIKE_ERROR_CODE,
											OPENConstants.ERR_MESSAGE_ACCOUNT_NUM_LOCKED_OUT);
						}
					}
				} else {
					errorMap
							.put(
									OPENRedesignConstants.CREDENTIALS_ERROR_CODE,
									OPENConstants.SYSDOWN_ERROR_DESC);
				}
			}
		} else {
			errorMap
					.put(
							OPENRedesignConstants.CREDENTIALS_ERROR_CODE,
							OPENConstants.SYSDOWN_ERROR_DESC);
		}
		if (!errorMap.isEmpty()) {
			request.setAttribute(OPENConstants.CREDENTIALS_ERRORS, errorMap);
			error = true;
		}
		LOGGER.exit(Group.OPEN, OPENConstants.BUSINESS_UNIT);
		return error;
	}

}
