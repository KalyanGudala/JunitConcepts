package com.americanexpress.acquisitions.open.web.managers;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.TreeMap;

import javax.servlet.http.HttpServletRequest;



import com.americanexpress.acquisitions.services.ccc.domain.AcquisitionRequest;
import com.americanexpress.acquisitions.services.ccc.domain.AcquisitionResponse;
import com.americanexpress.acquisitions.services.ccc.domain.ReviewBean;
import com.americanexpress.acquisitions.commons.config.AcquisitionsConfigManager;
import com.americanexpress.acquisitions.commons.config.exceptions.AcquisitionsConfigException;
import com.americanexpress.acquisitions.commons.log.AcquisitionsLogger;
import com.americanexpress.acquisitions.commons.log.constants.Group;
import com.americanexpress.acquisitions.commons.url.constants.URLConstants;
import com.americanexpress.acquisitions.open.commons.common.constants.AppConstants;
import com.americanexpress.acquisitions.open.commons.common.constants.OPENConstants;
import com.americanexpress.acquisitions.open.commons.url.helper.OPENURLParameterHelper;
import com.americanexpress.acquisitions.open.constants.OPENRedesignConstants;
import com.americanexpress.acquisitions.open.web.beans.OfferFeatureBean;
import com.americanexpress.acquisitions.open.web.beans.ProductFeatureBean;
import com.americanexpress.acquisitions.open.web.beans.RedesignDataBean;
import com.americanexpress.acquisitions.common.content.config.ContentConfig;
import com.americanexpress.acquisitions.open.commons.common.constants.Constants;
import com.americanexpress.acquisitions.services.productofferservice.beans.ContentCategoryGroup;
import com.americanexpress.acquisitions.services.productofferservice.beans.FeatureBean;
import com.americanexpress.acquisitions.services.productofferservice.beans.ProductOfferDataBean;
import com.americanexpress.acquisitions.services.ccc.open.multi.DataApiModelType;
import com.americanexpress.acquisitions.services.ccc.open.multi.ProductType;
import com.americanexpress.acquisitions.services.ccc.open.multi.ReviewStatisticsType;

public class CommonFunctionsManager {
	
	private static final AcquisitionsLogger LOGGER = new AcquisitionsLogger(CommonFunctionsManager.class);
	public static String serverName = null;
		
	
	 public static String getServerName(HttpServletRequest request) {
			StringBuilder domainName = new StringBuilder();
			try {
				domainName.append(request.getScheme()).append(":").append("//").append(request.getServerName());
				int port = request.getServerPort();
				if (port != 80 && port != 443) {
					domainName.append(URLConstants.COLON).append(port);
				}
			} catch (Exception e) {
				LOGGER.error(Group.OPEN, OPENConstants.BUSINESS_UNIT, e
						.getMessage(), e, null);
			}
			LOGGER.info(Group.OPEN, OPENConstants.BUSINESS_UNIT,
			"------------->domainName<------------"+domainName);
			serverName = domainName.toString();
			return domainName.toString();
		}
	 
	 /**
	  * 
	  * @param response
	  * @return
	  */
	 public static RedesignDataBean prepareProductOfferBean(
			AcquisitionResponse response, String entryPoint,
			String cardName, String pageid, String apptype,String cardType) {
		 RedesignDataBean redesignDataBean = new RedesignDataBean();
		 int totalReviewCount = 0;
		 Map<String, List<Object>> finalRRMap = null;
		 try {
			if (response != null) {
				DataApiModelType dataApiModelType	= response.getDataApiModelType();
				if(dataApiModelType!=null && dataApiModelType.getResults()!=null
						&& dataApiModelType.getResults().getProducts()!=null 
						&& dataApiModelType.getResults().getProducts().getProduct()!=null)
					{	
					finalRRMap = new HashMap<String, List<Object>>();
					List<ProductType> list = response.getDataApiModelType().getResults()
												.getProducts().getProduct();
					int prodTypeSize	= list.size();
		            for (int i = 0; i < prodTypeSize; i++) 
		            {
		            	readTotalReviewAvgRating(i, list,finalRRMap,redesignDataBean);
		            }
		            
		            
		        }
			}
			redesignDataBean.setBvUrl(prepareBVReviewUrl(
					redesignDataBean.getTotalReviewCount(),entryPoint,cardType));
			redesignDataBean.setCardArttitletext(ConfigManager
					.getPropertiesValue(
							OPENRedesignConstants.OPEN_REDESIGN_JCONFIG,
							OPENRedesignConstants.OPEN_REDESIGN_PROPS,
							cardType));
			redesignDataBean.setCardName(ConfigManager
					.getPropertiesValue(
							OPENConstants.OPEN_JCONFIG_NAME,
							OPENConstants.OPEN_CARDTYPE_NAME_MAPPING,
							cardType));
			buildProductOfferData(response,redesignDataBean);
			redesignDataBean.setTncUrl(prepareTnCLink(entryPoint,cardName,pageid,apptype));
		} catch (Exception e) {
			LOGGER.error(Group.OPEN, OPENConstants.BUSINESS_UNIT, "Exception while prepareProductOfferBean", e, null);
		}
		return redesignDataBean;
	 }
	 
	 
	 private static void readTotalReviewAvgRating(int i,List<ProductType> list,Map<String, List<Object>> rrMap,RedesignDataBean redesignDataBean )
		{
			List<Object> rrList = new ArrayList<Object>();
	    	ReviewStatisticsType reviewStatistics = list.get(i).getReviewStatistics();
	    	if(reviewStatistics != null)
	    	{
	    		LOGGER.info(Group.OPEN, OPENConstants.BUSINESS_UNIT,
						"BV reviewBean.getOverallRating() in commonFunctionsManager-------->>>>"
								+ reviewStatistics.getAverageOverallRating());
	    		redesignDataBean.setBvOverAllRating(reviewStatistics
					.getAverageOverallRating() != null ? Integer.valueOf(Math
					.round(reviewStatistics.getAverageOverallRating()) * 10)
					: 0);
	    		LOGGER.info(Group.OPEN, OPENConstants.BUSINESS_UNIT,
						"BV totalReviewCount in commonFunctionsManager-------->>>>"
								+ reviewStatistics.getTotalReviewCount());
	    		redesignDataBean.setTotalReviewCount(reviewStatistics.getTotalReviewCount());
	    		
	    							
	    	}
		}
	 
	 public static String prepareBVReviewUrl(int totalreviewCount,String eep,String cardType){
		 String bvUrl = null;
		 
		 try{
			 StringBuilder domainName = new StringBuilder(ContentConfig
					.getConfigAsString(Constants.OPENSITE_AKAMAI_PATH));
			 String cardName = ConfigManager.getPropertiesValue(
					OPENRedesignConstants.OPEN_REDESIGN_JCONFIG,
					OPENRedesignConstants.OPEN_REDESIGN_PROPS, cardType+"_reviews");
			 if(totalreviewCount>0){
			 bvUrl = domainName
					.append(OPENRedesignConstants.BVREVIEWSCONTEXT)
					.append(eep)
					.append(OPENRedesignConstants.CARDSPARAM)
					.append(cardName)
					.toString();
			 }else if(totalreviewCount==0){
				 bvUrl = domainName.append(OPENConstants.OPEN_LONG_APP_CONTEXT).append(OPENRedesignConstants.BVLOGIN).toString();
			 }
		 }catch (Exception bvExcp) {
			 LOGGER.error(Group.OPEN, OPENConstants.BUSINESS_UNIT, "Exception while preparing BV URl", bvExcp, null);
		}
		 LOGGER.info(Group.OPEN, OPENConstants.BUSINESS_UNIT, "BVUrl in commonFunctionsManager-------->>>>"+bvUrl);
		return bvUrl;
	 }
	 
	 public static void buildProductOfferData(AcquisitionResponse response,RedesignDataBean redesignDataBean){
		 List<ProductFeatureBean> productBeans = new ArrayList<ProductFeatureBean>();
		 ProductOfferDataBean productOfferDataBean = response.getProductOfferDataBean();
		 ProductFeatureBean productOfferBean = null;
		 OfferFeatureBean offerFeatureBean = null;
		 
		 if(productOfferDataBean!=null){
			 if(productOfferDataBean.getProductInfo()!=null && productOfferDataBean.getProductInfo().getProductExclusion()!=null){
			 redesignDataBean.setProductExclusionText(productOfferDataBean.getProductInfo().getProductExclusion());
			 }
			 List<ContentCategoryGroup> contentGroupList = productOfferDataBean.getContentGroupList();
			 //LOGGER.info(Group.OPEN, OPENConstants.BUSINESS_UNIT, "featureBean in contentGroupList-------->>>>"+contentGroupList);
			 if(contentGroupList!=null && contentGroupList.size()>0){
			 for(ContentCategoryGroup contentCategoryGroup : contentGroupList){
				// LOGGER.info(Group.OPEN, OPENConstants.BUSINESS_UNIT, "featureBean in ContentGroupName-------->>>>"+contentCategoryGroup.getContentGroupName());
				 if(contentCategoryGroup.getContentGroupName().equals("LeftNavFeatureGroup")){
				 List<FeatureBean> featureBeans = contentCategoryGroup.getFeatures();
				 //LOGGER.info(Group.OPEN, OPENConstants.BUSINESS_UNIT, "featureBean in buildProductOfferData-------->>>>"+featureBeans);
				 for(FeatureBean featureBean : featureBeans){
					 
					 LOGGER.info(Group.OPEN, OPENConstants.BUSINESS_UNIT, "featureBean.getFeatureType() ::::::::"+featureBean.getFeatureType());					 
					 int seqNo = Integer.valueOf(featureBean.getMetaData().get("sequenceOrderNumber"));
					 LOGGER.info(Group.OPEN, OPENConstants.BUSINESS_UNIT, "seqNo ::::::::"+seqNo);
					 //if("ProductFeature".equals(featureBean.getFeatureType())){
					 productOfferBean = new ProductFeatureBean();
					 productOfferBean.setFeatureType(featureBean.getFeatureType());
					 productOfferBean.setFeatureHeader(featureBean.getFeatureHeader());
					 productOfferBean.setFeatureText(featureBean.getFeatureText());
					 productOfferBean.setSeqNo(seqNo);
					 productBeans.add(productOfferBean);
					// }
					 /*if("OfferFeature".equals(featureBean.getFeatureType())){
					 offerFeatureBean = new OfferFeatureBean();
					 offerFeatureBean.setFeatureType(featureBean.getFeatureType());
					 offerFeatureBean.setFeatureHeader(featureBean.getFeatureHeader());
					 offerFeatureBean.setFeatureText(featureBean.getFeatureText());
					 offerFeatureBean.setSeqNo(seqNo);
					 productBeans.add(offerFeatureBean);
					 }*/
					 LOGGER.info(Group.OPEN, OPENConstants.BUSINESS_UNIT, "featureBean.getFeatureText() in buildProductOfferData-------->>>>"+featureBean.getFeatureText());
				 }
			 }
				 
			 }
			 Collections.sort(productBeans,new ProductFeatureBean());
			/* for(ProductFeatureBean productOfferBn :productBeans){
				 System.out.println("SeqNo **********************"+productOfferBn.getSeqNo());
			 }*/
			 redesignDataBean.setProductBeansSize(productBeans.size());
			 redesignDataBean.setProductBeans(productBeans);
			 }
			 
		 }
		 
		 
	 }
	 
	 public static String prepareTnCLink(String entryPoint, String cardName,
			String pageid, String apptype) {
		 StringBuilder tncUrl = new StringBuilder(serverName);
		 tncUrl.append(OPENConstants.OPEN_RWDLONG_APP_CONTEXT).append(cardName).append(OPENConstants.COOKIE_PATH).
		 append(OPENConstants.TERMSACTION).append(OPENConstants.COOKIE_PATH).append(entryPoint).
		 append(OPENConstants.HYPHEN).append(pageid).append(OPENConstants.HYPHEN).
		 append(apptype).append(OPENRedesignConstants.TNCPARAM);	
		 LOGGER.info(Group.OPEN, OPENConstants.BUSINESS_UNIT, "apptype ::::::::"
				+ apptype.toString() + ":::::::::::tncUrl:::::::::::" + tncUrl);		
		 return tncUrl.toString();
	 }
	 
	 
	 public static void setCardNameToRequest(AcquisitionRequest acqReq,
			HttpServletRequest req) {
		try {
			Properties cardnames = AcquisitionsConfigManager
					.getPropertiesObject(OPENConstants.CONTENT_JCONFIG,
							"CardNamesPropertiesForTags");
			String cardTp = acqReq.getAppInitiateData().getCardTypeID();
			String cardname = (String) cardnames.getProperty(cardTp
					+ AppConstants.REDESIGN_CARD_NAME);
			req.setAttribute(AppConstants.VAR_CARDNAME, cardname);
		} catch (AcquisitionsConfigException e) {
			LOGGER.error(Group.OPEN, OPENConstants.BUSINESS_UNIT,
					"setCardNameToRequest" + " cardnames is null ", null);
		}
	}
	 
	 public static String getCardName(HttpServletRequest request){
		 String cardname = null;
		 try {
			OPENURLParameterHelper parameterHelper=
			     new OPENURLParameterHelper(request);
			 String cardtype=
			     (String)parameterHelper.getProperty(URLConstants.CARD_TYPE);
			 Properties cardnames =
			        AcquisitionsConfigManager.getPropertiesObject(OPENConstants.CONTENT_JCONFIG,
			                            "CardNamesPropertiesForTags");
			 cardname = (String)cardnames.getProperty(cardtype+AppConstants.REDESIGN_CARD_NAME);
		} catch (AcquisitionsConfigException e) {
			LOGGER.error(Group.OPEN, OPENConstants.BUSINESS_UNIT,
					"getCardName" + " cardName is null ", null);
		}
		return cardname;
	 }
	 
}
