package com.americanexpress.acquisitions.open.web.managers;

import com.americanexpress.acquisitions.commons.config.AcquisitionsConfigManager;
import com.americanexpress.acquisitions.commons.config.exceptions.AcquisitionsConfigException;
import com.americanexpress.acquisitions.commons.log.AcquisitionsLogger;
import com.americanexpress.acquisitions.commons.log.constants.Group;
import com.americanexpress.acquisitions.open.commons.common.constants.OPENConstants;
import com.americanexpress.acquisitions.open.commons.url.constants.OPENURLConstants;

public class ConfigManager {
	
	private static final AcquisitionsLogger LOGGER = new AcquisitionsLogger(ConfigManager.class);
	
	public static String getPropertiesValue(String jconfigName, String propertyFileName, String key) {
		
		String val = null;
		try 
		{
			val = AcquisitionsConfigManager.getPropertiesValue
				  (jconfigName, propertyFileName, key);
			
		} 
		catch (AcquisitionsConfigException e) 
		{
			StringBuilder sb = new StringBuilder();
			sb.append(e.getMessage()).append(" : ");
			sb.append("Error while configuration : ");
			sb.append("jconfigName :- ").append(jconfigName).append(",");
			sb.append("propertyFileName :- ").append(propertyFileName).append(",");
			sb.append("Key :- ").append(key);
			LOGGER.error(Group.OPEN, OPENURLConstants.BUSINESS_UNIT, sb.toString(), e, null);
		}
		
		return val;
}
	
	
}
