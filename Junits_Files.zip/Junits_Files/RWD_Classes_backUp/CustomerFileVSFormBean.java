package com.americanexpress.acquisitions.open.web.managers;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Set;

import org.apache.commons.lang.StringUtils;

import com.americanexpress.acquisitions.commons.log.AcquisitionsLogger;
import com.americanexpress.acquisitions.commons.log.constants.Group;
import com.americanexpress.acquisitions.open.commons.common.constants.OPENConstants;
import com.americanexpress.acquisitions.open.commons.common.constants.XmlConstants;
import com.americanexpress.acquisitions.open.commons.formbeans.RedesignOSBNForm;
/**
 * CustomerFileVSFormBean
 * CustomerFileVSFormBean will Customer file xml to FormBean
 * 
 * @author Viswanatha.Sanapareddy@aexp.com
 * 
 * @version $Id: CustomerFileVSFormBean.java 30977 2013-12-09 05:33:34Z sgajula $
 */
public class CustomerFileVSFormBean 
{

	 private static final AcquisitionsLogger LOGGER = new AcquisitionsLogger(CustomerFileVSFormBean.class);
	
	public static final String PersonNameFirstOrGiven = "firstName";
    public static final String PersonNameMiddle = "middleName";
    public static final String PersonNameLastOrFamily = "lastName";
    public static final String PersonNameSuffix1 = "suffix";
    public static final String DateOfBirth = "date";
    public static final String PartyIdentifier = "socialShort";
    public static final String PersonalAnnualIncome = "personalAnnualIncome";
    public static final String PostalResidentialHomeAddressAddressLine1 = "homeAddress";
    public static final String PostalResidentialHomeAddressAddressLine2 = "homeAddressLine2";  //Added for QAS
    public static final String PostalResidentialHomeAddressAddressCity = "homeAddressCity";
    public static final String PostalResidentialHomeAddressAddressState = "homeAddressState";
    public static final String PostalResidentialHomeAddressAddressPostalCode = "homeAddressZip";
    public static final String PersonalStandardTelephoneNumberText = "phone";
    public static final String homeAndBusSameAddress = "homeAndBusSameAddress";
    public static final String PostalBusinessBusinessAddressAddressLine1 = "businessStreetAddress";
    public static final String PostalBusinessBusinessAddressAddressLine2 = "businessStreetAddressLine2";  //Added for QAS
    public static final String PostalBusinessBusinessAddressAddressCity = "businessCity";
    public static final String PostalBusinessBusinessAddressAddressState = "businessState";
    public static final String PostalBusinessBusinessAddressAddressPostalCode = "businessZip";
    public static final String BusinessStandardTelephoneNumberText = "businessPhone";
    public static final String BillingIndicator = "billingIndicator";
    public static final String NumberOfEmployees = "numberOfEmployees";
    public static final String AuthorizingOfficer = "authorizingOfficer";
    public static final String TypeOfBusiness = "typeofIndustry";
    public static final String YearsInBusiness = "yearsinOperation";
    public static final String MonthsInBusiness = "monthsInBusiness";
    public static final String LegalStructure = "legalStructure";
    public static final String federalTaxId = "federalShortTaxId";
    public static final String AnnualBusinessRevenue = "annualBusinessRevenue";
    public static final String EmbossedNameName = "nameOnCard";
    public static final String CompanyNameName = "businessNameOnCard";
    public static final String BusinessLongName = "businessName";
    public static final String BillingTime = "billingTime";
    public static final String personaleMailAddress = "emailAddress";
    public static final String RecipientOrganization = "receipientOrganization";
    public static final String PostalResidentialHomeAddressAddressLineApartmentNumber = "homeAddressApartment";
    public static final String AmexCardNumber = "amexCardNumber";
    public static final String DeltaSkyMilesNumber = "membershipNumber";
    public static final String cardArt = "cardArt";

    // Added for PreApproved

    public static final String personNameFirstOrGiven = "firstName";
    public static final String personNameMiddle = "middleName";
    public static final String personNameLastOrFamily = "lastName";
    public static final String personNameSuffix1 = "suffix";
    public static final String postalResidentialHomeAddressAddressLine1 = "homeAddress";
    public static final String postalResidentialHomeAddressAddressLine2 = "homeAddressLine2";  //Added for QAS
    public static final String postalResidentialHomeAddressAddressCity = "homeAddressCity";
    public static final String postalResidentialHomeAddressAddressState = "homeAddressState";
    public static final String postalResidentialHomeAddressAddressPostalCode = "homeAddressZip";
    public static final String personalStandardTelephoneNumberText = "phone";
    public static final String postalBusinessBusinessAddressAddressLine1 = "businessStreetAddress";
    public static final String postalBusinessBusinessAddressAddressLine2 = "businessStreetAddressLine2";  //Added for QAS
    public static final String postalBusinessBusinessAddressAddressCity = "businessCity";
    public static final String postalBusinessBusinessAddressAddressState = "businessState";
    public static final String postalBusinessBusinessAddressAddressPostalCode = "businessZip";
    public static final String businessStandardTelephoneNumberText = "businessPhone";
    public static final String billingIndicator = "billingIndicator";
    public static final String typeOfBusiness = "typeofIndustry";
    public static final String legalStructure = "legalStructure";
    public static final String embossedNameName = "nameOnCard";
    public static final String companyNameName = "businessNameOnCard";
	
 
	/**
	 * This method will maps the customer file to RedesignApp Form
	 * @param redesignAppForm,customerFileHash,isPreapproved, isValueBlank
	 * @return redesignAppForm
	 */
	public RedesignOSBNForm customerFileToRedesignAppForm(
			final RedesignOSBNForm redesignOSBNForm,final Hashtable customerFileHash,
			final boolean isPreapproved,final boolean isValueBlank) {
		String method = "CustomerFileToOsbnForm";
		LOGGER.entry(method, OPENConstants.BUSINESS_UNIT);
		if(customerFileHash != null){
			Set keys = customerFileHash.keySet();
			Enumeration enumKeys = java.util.Collections.enumeration(keys);
			while (enumKeys.hasMoreElements()) {
				String customerFileFieldName = (String) enumKeys.nextElement();
				String customerFileFieldValue = (String) customerFileHash
						.get(customerFileFieldName);
				String redesignFormFieldName = getFieldValue(customerFileFieldName);
				/*if (LOGGER.isDebugEnabled()) {
					LOGGER.debug(method, OPENConstants.EMPTYSTRING,"customerFileFieldName --> "+ customerFileFieldName + "value-->"+ customerFileFieldValue);
				}*/
				String value;
					if (customerFileFieldValue == null
							|| customerFileFieldValue.equals(OPENConstants.HASH)) {
						value = OPENConstants.EMPTYSTRING;
					} else {
						if (!isPreapproved) {
							value = customerFileFieldValue;
						} else if (isValueBlank) {
							value = OPENConstants.EMPTYSTRING;
						} else {
							value = OPENConstants.EMPTYSTRING;
						}
					}
					/*if (LOGGER.isDebugEnabled()) {
						LOGGER.debug(method, OPENConstants.EMPTYSTRING,"redesignFormFieldName --> "	+ redesignFormFieldName + "value :"	+ value);
					}*/
					if (OPENConstants.PHONE.equals(redesignFormFieldName)) {
						if (value != null && value.length() == OPENConstants.VAR_TEN ) {
							value= allowOnlyDigits(value);
							redesignOSBNForm.setPhone(value);
						} else {
							value = OPENConstants.EMPTYSTRING;
						}

					}
					if (XmlConstants.COMPANY_NAME
							.equalsIgnoreCase(customerFileFieldName)) {
						redesignOSBNForm.setBusinessName(customerFileFieldValue);
					}
					if (OPENConstants.SOCIAL_SHORT.equals(redesignFormFieldName)) {
						/*if (LOGGER.isInfoEnabled()) {
							LOGGER.info(Group.OPEN, method,	"redesignFormFieldName -->**** "+ redesignFormFieldName);
						}*/
						if (value != null && value.length() >= OPENConstants.VAR_NINE) {
							redesignOSBNForm.setSocial(value);
							redesignOSBNForm.setSocialShort(redesignOSBNForm
									.getSocial());
						}else{
							redesignOSBNForm
							.setSocial(OPENConstants.EMPTYSTRING);
						}
					}
					if (OPENConstants.BUSINESS_PHONE.equals(redesignFormFieldName)) {
						if (value != null && value.length() == 10  )
						{
							value= allowOnlyDigits(value);
							redesignOSBNForm.setBusinessPhone(value);
						} else {
							value = OPENConstants.EMPTYSTRING;
						}
					}
					if (OPENConstants.DATE.equals(redesignFormFieldName)) {
						if (value != null) {
							redesignOSBNForm.setDate(value);
						} else {
							value = OPENConstants.EMPTYSTRING;
						}
					}
					if(StringUtils.isNotEmpty(redesignFormFieldName)){
					setRedesignFormFields(redesignOSBNForm,
							redesignFormFieldName, value);
					}
			}
		}
			LOGGER.exit(method, OPENConstants.BUSINESS_UNIT);
		return redesignOSBNForm;

	}
	/**
     * This method will set field values
     * @param context
     * @return Event
     */
	public void setRedesignFormFields(final RedesignOSBNForm redesignOSBNForm,
			final String fieldName,final String fieldValue) {
		String method = "CustomerFileVSFormBean.setFormFields";
		LOGGER.entry(method, OPENConstants.BUSINESS_UNIT);
		Class redesignAppFormClass = redesignOSBNForm.getClass();
		Class tempClass;
		try {
			tempClass = Class.forName(OPENConstants.JAVA_STRING);
			Class[] temp1 = new Class[1];
			temp1[0] = tempClass;
			Object[] obj = new Object[1];
			obj[0] = fieldValue;
			String redesignFormFieldName = fieldName;
			String tempPre = redesignFormFieldName.substring(0, 1);
			String tempPost = redesignFormFieldName.substring(1);
			tempPre = tempPre.toUpperCase();
			String methodName = OPENConstants.SET + tempPre + tempPost;
			Method redesignMethods = redesignAppFormClass.getMethod(methodName, temp1);
			redesignMethods.invoke(redesignOSBNForm, obj);
		} catch (ClassNotFoundException classnotFoundException) {
			//LOGGER.error(Group.OPEN, OPENConstants.BUSINESS_UNIT,"ClassNotFoundException: ",classnotFoundException ,null);

		} catch (NoSuchMethodException NoSuchMethodException) {
			LOGGER.error(Group.OPEN, OPENConstants.BUSINESS_UNIT, "ClassNotFoundException: ",NoSuchMethodException,null);

		} catch (Exception exception) {
			//LOGGER.error(Group.OPEN, OPENConstants.BUSINESS_UNIT, "Exception occured: ",exception,null);

		}
		LOGGER.exit(method, OPENConstants.BUSINESS_UNIT);
	}

	public String getFieldValue(final String name) {
		String basicFieldvalue = null;
		String methodName = "FormBeanVsShortAppPage.getFieldValue";
		LOGGER.entry(methodName,  OPENConstants.BUSINESS_UNIT);
		try {
			Class cls = getClass();
			Field fld = cls.getField(name);
			basicFieldvalue = (String) fld.get(this);
		} catch (NoSuchFieldException nsfe) {
			LOGGER.info(Group.OPEN, OPENConstants.BUSINESS_UNIT,"NoSuchFieldException occured");
		} catch (SecurityException se) {
			//LOGGER.error(Group.OPEN, OPENConstants.BUSINESS_UNIT, "SecurityException occured: ",se,null);
		} catch (Exception exception) {
			//LOGGER.error(Group.OPEN, OPENConstants.BUSINESS_UNIT, "Exception occured: ",exception,null);
		}
		LOGGER.exit(methodName, OPENConstants.BUSINESS_UNIT);
		return basicFieldvalue;
	}
	/*
     * This method removes special characters  from string,add only  digits to the result string and if String result string 10 then only returns the value otherwise returns the null
     * 
     * @param name - String
     * 
     * @return String
     */
    public static String allowOnlyDigits(String phoneNumber) {
        StringBuffer sbrPhone = new StringBuffer();
        char cname[] = null;
        cname = phoneNumber.toCharArray();
        for (int i = 0; i < cname.length; i++) {
            if (Character.isDigit(cname[i])){
            	sbrPhone.append(cname[i]);
            }else{
            	return  OPENConstants.EMPTYSTRING;
            }
        }
        return  sbrPhone.toString();
    }
	
}
