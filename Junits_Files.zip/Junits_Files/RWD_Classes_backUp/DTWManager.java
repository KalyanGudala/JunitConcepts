/*
 * -------------------------------------------------------------------------
 *
 * (C) Copyright / American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.
 *
 * -------------------------------------------------------------------------
 */

package com.americanexpress.acquisitions.open.web.managers;


import java.util.Enumeration;
import java.util.Properties;
import java.util.StringTokenizer;
import com.americanexpress.acquisitions.commons.log.AcquisitionsLogger;
import com.americanexpress.acquisitions.commons.log.constants.Group;
import com.americanexpress.acquisitions.open.commons.common.constants.DTWConstants;
import com.americanexpress.acquisitions.open.commons.common.domain.BasicPage;



/**
 * DTWManager
 * 
 * @version $Id: DTWManager.java 31897 2013-12-22 12:58:16Z sgajula $
 */
public class DTWManager 
{

	private static final AcquisitionsLogger logger = new AcquisitionsLogger(
													 DTWManager.class);
	private static boolean isInfoEnabled = logger.isInfoEnabled();
	private static final String CLASS_DTWManager = "DTWManager";	
	
	/**
	 * @param String
	 *            date
	 * @return String
	 */

	public String getDate(String date) 
	{
		logger.entry(Group.OPEN, "DTWManager.getDate()");
		int intYear;
		int intMonth;
		int intDay;
		String newdate;
		StringTokenizer objTokenizer = new StringTokenizer(date, "-");
		intYear = Integer.parseInt(objTokenizer.nextToken());
		intMonth = Integer.parseInt(objTokenizer.nextToken());
		intDay = Integer.parseInt(objTokenizer.nextToken());
		newdate = intMonth + "/" + intDay + "/" + intYear;
		logger.exit(Group.OPEN, "DTWManager.getDate()");
		return newdate;
	}

	/**
	 * @param retProps
	 *            Properties
	 * @return BasicPage
	 */

	public BasicPage setValuesintoBasicPage(Properties retProps) {
		logger.entry(Group.OPEN, "setValuesintoBasicPage()");
		logger.debug(Group.OPEN, "DTWManager", "the properties object value"
				+ retProps);
		BasicPage basicPage = new BasicPage();
		for (Enumeration retPropsEnum = retProps.keys(); retPropsEnum
				.hasMoreElements();) {
			String name = (String) retPropsEnum.nextElement();
			if (!name.equalsIgnoreCase("cmrsvp")) {

				String value = retProps.getProperty(name);
				basicPage.setField(name, value);
			}
		}
		logger.exit(Group.OPEN, "setValuesintoBasicPage()");
		return basicPage;
	}

	/**
	 * Checks if the Address field starts with PO BOX related characters. If so
	 * sets the field as not valid.
	 * 
	 * 
	 * @param String
	 *            s string that takes the field value to validate
	 * @return boolean
	 */
	public boolean checkFirstPOBox(String str) {

		logger.entry(Group.OPEN, "DTWManager.checkFirstPOBox()");
		boolean valid = true;
		try {
			String s = "";
			StringTokenizer st = new StringTokenizer(str, " ");
			while (st.hasMoreTokens()) {
				s = s + st.nextToken();// NOPMD
			}
			int len = s.length();
			//

			if ((len >= DTWConstants.INT_FOUR)
					&& (s.substring(0, DTWConstants.INT_FOUR)
							.equalsIgnoreCase("PBox"))) {
				valid = false;
			}

			if ((valid)
					&& (len >= DTWConstants.INT_FIVE)
					&& (s.substring(0, DTWConstants.INT_FIVE)
							.equalsIgnoreCase("POBox"))) {
				valid = false;	
			}

			if ((valid)
					&& (len >= DTWConstants.INT_SEVEN)
					&& (s.substring(0, DTWConstants.INT_SEVEN)
							.equalsIgnoreCase("P.O.BOX"))) {
				valid = false;
			}

			if ((valid)
					&& (len >= DTWConstants.INT_THREE)
					&& ((s.substring(0, DTWConstants.INT_THREE)
							.equalsIgnoreCase("POB")) || (s.substring(0,
							DTWConstants.INT_THREE).equalsIgnoreCase("BOX")))) {
				valid = false;
			}

			if ((valid)
					&& (len >= DTWConstants.INT_THIRTEEN)
					&& (s.substring(0, DTWConstants.INT_THIRTEEN)
							.equalsIgnoreCase("POSTOFFICEBOX"))) {
				valid = false;
			}

		} catch (StringIndexOutOfBoundsException e) {
			valid = false;
		}
		logger.exit(Group.OPEN, "DTWManager.checkFirstPOBox()");
		return valid;
	}
}
