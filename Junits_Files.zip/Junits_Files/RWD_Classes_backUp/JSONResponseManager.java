/*
 * -------------------------------------------------------------------------
 *
 * (C) Copyright / American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.
 *
 * -------------------------------------------------------------------------
 */

package com.americanexpress.acquisitions.open.web.managers;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;

import javax.servlet.http.HttpSession;

import com.americanexpress.acquisitions.common.content.config.ContentConfig;
import com.americanexpress.acquisitions.commons.log.AcquisitionsLogger;
import com.americanexpress.acquisitions.commons.log.constants.Group;
import com.americanexpress.acquisitions.open.commons.common.constants.Keys;
import com.americanexpress.acquisitions.open.commons.common.constants.OPENConstants;
import com.americanexpress.acquisitions.open.commons.common.domain.SuppCardCollection;
import com.americanexpress.acquisitions.open.commons.formbeans.RedesignOSBNForm;
import com.americanexpress.acquisitions.open.commons.shortapp.cardservice.Eligiblecard;
import com.americanexpress.acquisitions.open.commons.url.constants.OPENURLConstants;
import com.americanexpress.acquisitions.open.constants.OPENRedesignConstants;
import com.americanexpress.acquisitions.open.web.beans.CardMemberAppDTO;
import com.americanexpress.acquisitions.services.ccc.domain.AcquisitionResponse;

import org.apache.commons.lang.StringUtils;
import org.json.JSONObject;

/**
 * JSONResponseManager
 *
 * @author 387142
 * @version $Id: JSONResponseManager.java 32210 2013-12-26 11:31:42Z stell1 $
 */
public class JSONResponseManager 
{	
	private static final AcquisitionsLogger LOGGER = 
							new AcquisitionsLogger(JSONResponseManager.class);
	
	/**
	 * This method is used to prefill the Long application 
	 *  and to create a JsonResponse Object.
	 * 
	 * @param osbnform,session
	 * @return String
	 */
	public String  getLongAppJSONResponse(RedesignOSBNForm  osbnform,HttpSession session) 
	{
		LOGGER.entry(Group.OPEN, OPENConstants.BUSINESS_UNIT);
		Class redesignOSBNForm = null;
		ArrayList<String> fieldsToBeHidden = new ArrayList<String>();
		try
		{
			String json_resp_keys[] = ConfigManager.getPropertiesValue
									  (OPENRedesignConstants.OPEN_REDESIGN_JCONFIG, 
									   OPENRedesignConstants.OPEN_REDESIGN_PROPS, 
									   OPENRedesignConstants.OPEN_REDESIGN_LAPP_KEYS).
									   split(OPENRedesignConstants.COMMA);
			fieldsToBeHidden = (ArrayList<String>)session.getAttribute(OPENRedesignConstants.FIELDS_TO_BE_HIDDEN);
			JSONObject info = new JSONObject();
			redesignOSBNForm = osbnform.getClass();
			for(String json_resp_key : json_resp_keys)
			{
				JSONObject jsonKey = new JSONObject();
				jsonKey.put(OPENRedesignConstants.JSON_RESP_VISIBLE_ID, 
							json_resp_key);
				
				String fieldDetails [] = ConfigManager.getPropertiesValue
				  						(OPENRedesignConstants.OPEN_REDESIGN_JCONFIG, 
				  						 OPENRedesignConstants.OPEN_REDESIGN_PROPS, 
				  						 json_resp_key).
			  						 	 split(OPENRedesignConstants.COMMA);
				LOGGER.info(Group.OPEN, OPENURLConstants.BUSINESS_UNIT, "fieldDetails in jsonrespmanager:" + fieldDetails);
				String value = null;
				try
				{
					Method m = redesignOSBNForm.getMethod(fieldDetails[1]);
					value = (String)m.invoke(osbnform, null);
					value = (value == null) ? "" : value;
				}
				catch(Exception e)
				{
					LOGGER.info(Group.OPEN, OPENURLConstants.BUSINESS_UNIT, "exception in jsonrespmanager:" + e.getMessage());
					LOGGER.error(Group.OPEN,
							 OPENURLConstants.BUSINESS_UNIT,
							 e.getMessage()+ 
							 " Exception while invoking method on RedesignOSBNForm-LongApp JSON Resp creation" +
							 e, null);
					LOGGER.info(Group.OPEN, OPENURLConstants.BUSINESS_UNIT, "exception after jsonrespmanager:" + e.getMessage());
					
				}
				jsonKey.put(OPENRedesignConstants.JSON_RESP_EDIT_ID, 
						fieldDetails[0]);
				jsonKey.put(OPENRedesignConstants.JSON_RESP_VALUE, value);
				if(fieldsToBeHidden == null)
					jsonKey.put("hidden", OPENRedesignConstants.STR_FALSE);
				else if(fieldsToBeHidden.contains(fieldDetails[1]))
					jsonKey.put("hidden", OPENRedesignConstants.TRUE);
				else
					jsonKey.put("hidden", OPENRedesignConstants.STR_FALSE);
				
                info.accumulate("Info", jsonKey);
                jsonKey = null;
			}
			LOGGER.info(Group.OPEN, OPENURLConstants.BUSINESS_UNIT, 
					    "completed constructing JSON resp for OPEN LApp" + info.toString());
            return info.toString();
		}		
		catch(Exception e)
		{		
			LOGGER.error(Group.OPEN,
						 OPENURLConstants.BUSINESS_UNIT,
						 e.getMessage()+ 
						 " Exception while creating JSON Response for Open LApp" +
						 e, null);
			return null;
		}
		finally
		{
			LOGGER.exit(Group.OPEN, OPENConstants.BUSINESS_UNIT);
		}
	}
	
	public String getDTWJSONResponse(RedesignOSBNForm  osbnform, 
			 AcquisitionResponse acquisitionResponse, boolean isNPA) 
	{
		LOGGER.entry(Group.OPEN, OPENConstants.BUSINESS_UNIT);
		try
		{
			StringBuilder DTWJSON = new StringBuilder("{");
			
			String dtw = "\"" + "dtw" + "\"";
			String name = "\"" + "Name" + "\"";
			String value = "\"" + "Value" + "\"";
			String editable = "\"" + "Editable" + "\"";
			String nonPreApproved = "\"" + "nonPreApproved" + "\"";
			String preApproved = "\"" + "preApproved" + "\"";
			String editTrue="\"" + "true" + "\"";
			String editFalse="\"" + "false" + "\"";
			String businessname="\"" + "businessName" + "\"";
			String businessStreetAddr="\"" + "businessStreetAddress" + "\"";
			String businessZip="\"" + "businessZip" + "\"";
			String businessState="\"" + "businessState" + "\"";
			String businessCity="\"" + "businessCity" + "\"";
			String homeAddress="\"" + "homeAddress" + "\"";
			String homeAddressZip="\"" + "homeAddressZip" + "\"";
			String homeAddressCity="\"" + "homeAddressCity" + "\"";
			String homeAddressState="\"" + "homeAddressState" + "\"";
			String fieldValue = null;
			
			DTWJSON.append(dtw);
			DTWJSON.append(":");
			DTWJSON.append("{");	
			
			if(isNPA)
			{
			DTWJSON.append(nonPreApproved);
			
			DTWJSON.append(":");
			DTWJSON.append("[");
			DTWJSON.append("{");
			
			DTWJSON.append(name +":"+businessname+",");
			fieldValue = osbnform.getBusinessName();
			fieldValue = StringUtils.isEmpty(fieldValue) ? "" : fieldValue;
			DTWJSON.append(value+":"+"\""+fieldValue+"\""+",");
			DTWJSON.append(editable+":"+editTrue);
			DTWJSON.append("}"+",");
			DTWJSON.append("{");
			DTWJSON.append(name +":"+businessStreetAddr+",");
			fieldValue = osbnform.getBusinessStreetAddress();
			fieldValue = StringUtils.isEmpty(fieldValue) ? "" : fieldValue;
			DTWJSON.append(value+":"+"\""+fieldValue+"\""+",");
			DTWJSON.append(editable+":"+editTrue);
			DTWJSON.append("}"+",");
			DTWJSON.append("{");
			DTWJSON.append(name +":"+businessZip+",");
			fieldValue = osbnform.getBusinessZip();
			fieldValue = StringUtils.isEmpty(fieldValue) ? "" : fieldValue;
			DTWJSON.append(value+":"+"\""+fieldValue+ "\""+",");
			DTWJSON.append(editable+":"+editTrue);
			DTWJSON.append("}"+",");
			DTWJSON.append("{");
			DTWJSON.append(name +":"+businessState+",");
			fieldValue = osbnform.getBusinessState();
			fieldValue = StringUtils.isEmpty(fieldValue) ? "" : fieldValue;
			DTWJSON.append(value+":"+"\""+fieldValue+"\""+",");
			DTWJSON.append(editable+":"+editTrue);
			DTWJSON.append("}"+",");
			DTWJSON.append("{");
			DTWJSON.append(name +":"+businessCity+",");
			fieldValue = osbnform.getBusinessCity();
			fieldValue = StringUtils.isEmpty(fieldValue) ? "" : fieldValue;
			DTWJSON.append(value+":"+"\""+fieldValue+"\""+",");
			DTWJSON.append(editable+":"+editTrue);
			DTWJSON.append("}"+",");
			DTWJSON.append("{");
			DTWJSON.append(name +":"+homeAddress+",");
			fieldValue = osbnform.getHomeAddress();
			fieldValue = StringUtils.isEmpty(fieldValue) ? "" : fieldValue;
			DTWJSON.append(value+":"+"\""+fieldValue+"\""+",");
			DTWJSON.append(editable+":"+editTrue);
			DTWJSON.append("}");
			DTWJSON.append("]");
			DTWJSON.append("}");
			DTWJSON.append("}");
			}
			else
			{
			DTWJSON.append(preApproved+":"+"[");
			DTWJSON.append("{");
			DTWJSON.append(name+":"+homeAddress+",");
			fieldValue = osbnform.getHomeAddress();
			fieldValue = StringUtils.isEmpty(fieldValue) ? "" : fieldValue;
			DTWJSON.append(value+":"+"\""+fieldValue+"\""+",");
			DTWJSON.append(editable+":"+editTrue);
			DTWJSON.append("}"+",");
			DTWJSON.append("{");
			DTWJSON.append(name +":"+homeAddressZip+",");
			fieldValue = osbnform.getHomeAddressZip();
			fieldValue = StringUtils.isEmpty(fieldValue) ? "" : fieldValue;
			DTWJSON.append(value+":"+"\""+fieldValue+"\""+",");
			DTWJSON.append(editable+":"+editTrue);
			DTWJSON.append("}"+",");
			DTWJSON.append("{");
			DTWJSON.append(name +":"+homeAddressCity+",");
			fieldValue = osbnform.getHomeAddressCity();
			fieldValue = StringUtils.isEmpty(fieldValue) ? "" : fieldValue;
			DTWJSON.append(value+":"+"\""+fieldValue+"\""+",");
			DTWJSON.append(editable+":"+editTrue);
			DTWJSON.append("}"+",");
			DTWJSON.append("{");
			DTWJSON.append(name +":"+homeAddressState+",");
			fieldValue = osbnform.getHomeAddressState();
			fieldValue = StringUtils.isEmpty(fieldValue) ? "" : fieldValue;
			DTWJSON.append(value+":"+"\""+fieldValue+"\""+",");
			DTWJSON.append(editable+":"+editTrue);
			DTWJSON.append("}");
			DTWJSON.append("]");
			DTWJSON.append("}");
			DTWJSON.append("}");
			}
			
			return DTWJSON.toString();
    }
    catch(Exception e)
    {
    	LOGGER.error(Group.OPEN,
				 OPENURLConstants.BUSINESS_UNIT,
				 e.getMessage()+ 
				 " Exception while creating JSON Response for Open ShortApp" +
				 e, null);
	return null;
    	
    }
    finally
    {
    	LOGGER.exit(Group.OPEN, OPENConstants.BUSINESS_UNIT);
    }
  }
	
	
	public String  getShortAppJSONResponse(HashMap<String, List<Eligiblecard>> cards, boolean isCidRequired) 
	{
		LOGGER.entry(Group.OPEN, OPENConstants.BUSINESS_UNIT);
		try
		{
			String accnum=null;
			String akamaiPath = ContentConfig.getConfigAsString(OPENConstants.AKAMAI_PATH);
		    
			ArrayList<Eligiblecard> smallBusinessCards = (ArrayList<Eligiblecard>)cards.get(Keys.SBS_CARDS);
			ArrayList<Eligiblecard> personalCards = (ArrayList<Eligiblecard>)cards.get(Keys.CCSG_CARDS);
		    StringBuilder shortAppJSON = new StringBuilder();
		    shortAppJSON.append(OPENRedesignConstants.CURLY_OPEN_BRACE + OPENRedesignConstants.SHORT_APP + OPENRedesignConstants.COLON);
		    shortAppJSON.append(OPENRedesignConstants.CURLY_OPEN_BRACE + OPENRedesignConstants.RESULT + OPENRedesignConstants.COLON);
		    shortAppJSON.append(OPENRedesignConstants.SQUARE_OPEN_BRACE + OPENRedesignConstants.CURLY_OPEN_BRACE);
		    shortAppJSON.append(OPENRedesignConstants.SUCCESS_KEY + OPENRedesignConstants.COLON + OPENRedesignConstants.KEY_TRUE);
		    shortAppJSON.append(OPENRedesignConstants.COMMA + OPENRedesignConstants.OBS_JSON_RESP_ERROR_CODE + OPENRedesignConstants.COLON);
		    shortAppJSON.append(OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES + "101" + OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES);
		    shortAppJSON.append(OPENRedesignConstants.COMMA + OPENRedesignConstants.KEY_ERROR_MSG + OPENRedesignConstants.COLON + 
		    		OPENRedesignConstants.SUCCESS_KEY);
		    shortAppJSON.append(OPENRedesignConstants.CURLY_CLOSE_BRACE + OPENRedesignConstants.SQUARE_CLOSE_BRACE);
		    if((smallBusinessCards == null || smallBusinessCards.size() == 0) && (personalCards == null || personalCards.size() == 0)) 
		    {
		    	shortAppJSON.append(OPENRedesignConstants.CURLY_CLOSE_BRACE + OPENRedesignConstants.CURLY_CLOSE_BRACE);
		    	return shortAppJSON.toString();
		    }
		    else
		    {
		    	shortAppJSON.append(OPENRedesignConstants.COMMA + OPENRedesignConstants.KEY_CARD_DETAILS + 
		    						OPENRedesignConstants.COLON + OPENRedesignConstants.SQUARE_OPEN_BRACE);
		    	if(smallBusinessCards !=null)
		    	{
		    		for(Eligiblecard card: smallBusinessCards)
			    	{
		    			accnum = card.getAccountNumber();
		    			if(StringUtils.isNotBlank(accnum) && accnum.length()>5){
		    				accnum = accnum.substring(accnum.length()-5);
		    			}
			    		shortAppJSON.append(OPENRedesignConstants.CURLY_OPEN_BRACE + OPENRedesignConstants.KEY_PMC);
			    		shortAppJSON.append(OPENRedesignConstants.COLON + OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES).append(
			    				akamaiPath +OPENConstants.CS_PAGE_IMAGE_PATH+card.getCidSelectorImg() + 
			    							OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES);
			    		shortAppJSON.append(OPENRedesignConstants.COMMA);
			    		shortAppJSON.append(OPENRedesignConstants.KEY_COMPANY_NAME + OPENRedesignConstants.COLON);
			    		shortAppJSON.append(OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES + card.getBusinessName() + 
			    							OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES + OPENRedesignConstants.COMMA);
			    		shortAppJSON.append(OPENRedesignConstants.KEY_CARD_NUMBER + OPENRedesignConstants.COLON);
			    		shortAppJSON.append(OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES + accnum + 
			    							OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES + OPENRedesignConstants.COMMA +
			    							OPENRedesignConstants.KEY_CARD_INDEX + OPENRedesignConstants.COLON
			    							 + OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES +card.getSortedIndex() + OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES  +OPENRedesignConstants.CURLY_CLOSE_BRACE);
			    		shortAppJSON.append(OPENRedesignConstants.COMMA);
			    		
			    	}
		    	}
		    	if(personalCards != null)
		    	{
			    	for(Eligiblecard card: personalCards)
			    	{
			    		accnum = card.getAccountNumber();
		    			if(StringUtils.isNotBlank(accnum) && accnum.length()>5){
		    				accnum = accnum.substring(accnum.length()-5);
		    			}
			    		shortAppJSON.append(OPENRedesignConstants.CURLY_OPEN_BRACE + OPENRedesignConstants.KEY_PMC);
			    		shortAppJSON.append(OPENRedesignConstants.COLON + OPENRedesignConstants.KEY_PMC_HYPHEN + card.getProductCD() + 
			    							OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES);
			    		shortAppJSON.append(OPENRedesignConstants.COMMA);
			    		shortAppJSON.append(OPENRedesignConstants.KEY_COMPANY_NAME + OPENRedesignConstants.COLON);
			    		shortAppJSON.append(OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES + card.getBusinessName() + 
			    							OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES + OPENRedesignConstants.COMMA);
			    		shortAppJSON.append(OPENRedesignConstants.KEY_CARD_NUMBER + OPENRedesignConstants.COLON);
			    		shortAppJSON.append(OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES + accnum + 
			    							OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES + OPENRedesignConstants.COMMA + OPENRedesignConstants.KEY_CARD_INDEX + OPENRedesignConstants.COLON
			    							 + OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES +card.getSortedIndex() + OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES + OPENRedesignConstants.CURLY_CLOSE_BRACE);
			    		shortAppJSON.append(OPENRedesignConstants.COMMA);
			    	}
		    	}
		    	shortAppJSON = shortAppJSON.deleteCharAt(shortAppJSON.length()-1);
		    	shortAppJSON.append(OPENRedesignConstants.SQUARE_CLOSE_BRACE).append(OPENRedesignConstants.COMMA).
		    				 append(OPENRedesignConstants.KEY_IS_CID_REQUIRED).append(OPENRedesignConstants.COLON).
		    				 append(OPENRedesignConstants.SQUARE_OPEN_BRACE).append(OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES).
		    				 append(isCidRequired).append(OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES).
		    				 append(OPENRedesignConstants.SQUARE_CLOSE_BRACE).append(OPENRedesignConstants.CURLY_CLOSE_BRACE).
		    				 append(OPENRedesignConstants.CURLY_CLOSE_BRACE);
		    }
				
			return shortAppJSON.toString();
		}
		catch(Exception e)
		{
			LOGGER.error(Group.OPEN,
					 OPENURLConstants.BUSINESS_UNIT,
					 e.getMessage()+ 
					 " Exception while creating JSON Response for Open ShortApp" +
					 e, null);
		return null;
		}
		finally
		{
			LOGGER.exit(Group.OPEN, OPENConstants.BUSINESS_UNIT);
			
		}
     }
	
	/**
	 * This method is used to create json response
	 *  to populate supp cards review page
	 * 
	 * @param osbnform,acquisitionResponse,SuppCardCollection
	 * @return String
	 */
	public String  getSuppAppJSONResponse(RedesignOSBNForm  osbnform, 
			 AcquisitionResponse acquisitionResponse, SuppCardCollection collection) 
	{
		StringBuilder suppJSONResponse = new StringBuilder(OPENRedesignConstants.CURLY_OPEN_BRACE + 
										 OPENRedesignConstants.SUPP_CARDS_KEY + 
										 OPENRedesignConstants.COLON + OPENRedesignConstants.SQUARE_OPEN_BRACE);
		int counter = 1;
		Class redesignOSBNForm = osbnform.getClass();
		try
		{
			while(counter <= collection.size())
			{
				suppJSONResponse.append(OPENRedesignConstants.SQUARE_OPEN_BRACE);
				String supp_card_keys[] = ConfigManager.getPropertiesValue
				  (OPENRedesignConstants.OPEN_REDESIGN_JCONFIG, 
						   OPENRedesignConstants.OPEN_REDESIGN_PROPS, 
						   OPENRedesignConstants.SUPP_CARD_DETAILS +"."+ counter).
						   split(OPENRedesignConstants.COMMA);
				int fieldCounter = 0;
				while(fieldCounter < supp_card_keys.length)
				{
					suppJSONResponse.append(OPENRedesignConstants.CURLY_OPEN_BRACE);
					suppJSONResponse.append(OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES + 
											OPENRedesignConstants.JSON_RESP_VISIBLE_ID + 
											OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES);
					suppJSONResponse.append(OPENRedesignConstants.COLON);
					suppJSONResponse.append(OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES + 
											supp_card_keys[fieldCounter] + 
											OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES);
					suppJSONResponse.append(OPENRedesignConstants.COMMA);
					
					suppJSONResponse.append(OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES + 
											OPENRedesignConstants.JSON_RESP_EDIT_ID + 
											OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES);
					suppJSONResponse.append(OPENRedesignConstants.COLON);
					suppJSONResponse.append(OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES + 
											supp_card_keys[fieldCounter+1] + 
											OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES);
					suppJSONResponse.append(OPENRedesignConstants.COMMA);
					
					String value = "";
					suppJSONResponse.append(OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES + 
											OPENRedesignConstants.JSON_RESP_VALUE + 
											OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES);
					suppJSONResponse.append(OPENRedesignConstants.COLON);
					
					try
					{
						Method m = redesignOSBNForm.getMethod(supp_card_keys[fieldCounter + 2]);
						value = (String)m.invoke(osbnform, null);
						suppJSONResponse.append(OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES + 
												value + 
												OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES);
					}
					catch(Exception e)
					{
						LOGGER.error(Group.OPEN,
								 OPENURLConstants.BUSINESS_UNIT,
								 e.getMessage()+ 
								 " Exception while invoking method on RedesignOSBNForm-LongApp JSON Resp creation" +
								 e, null);
						suppJSONResponse.append(OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES + 
								value + 
								OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES);
						suppJSONResponse.append(OPENRedesignConstants.COMMA);
	
					}
					suppJSONResponse.append(OPENRedesignConstants.CURLY_CLOSE_BRACE);
					suppJSONResponse.append(OPENRedesignConstants.COMMA);
					fieldCounter = fieldCounter+3;
				}
				counter++;
				suppJSONResponse = suppJSONResponse.deleteCharAt(suppJSONResponse.length()-1);
				suppJSONResponse.append(OPENRedesignConstants.SQUARE_CLOSE_BRACE);
				suppJSONResponse.append(OPENRedesignConstants.COMMA);
			}
			suppJSONResponse = suppJSONResponse.deleteCharAt(suppJSONResponse.length()-1);
			suppJSONResponse.append(OPENRedesignConstants.SQUARE_CLOSE_BRACE);
			suppJSONResponse.append(OPENRedesignConstants.CURLY_CLOSE_BRACE);
			return suppJSONResponse.toString();
		}
		catch(Exception e)
		{
			LOGGER.error(Group.OPEN,
					 OPENURLConstants.BUSINESS_UNIT,
					 e.getMessage()+ 
					 " Exception while creating JSON Response for Supp Cards" +
					 e, null);
		return null;
		}
		finally
		{
			LOGGER.exit(Group.OPEN, OPENConstants.BUSINESS_UNIT);
		}
    }
	
	/**
	 *  This method is used to create json response for obscenity check 
	 * 
	 * @param HashMap
	 * @return String
	 */
	public String getObscenityJSONResponse(HashMap obsErrors)
	{
		LOGGER.entry(Group.OPEN, OPENConstants.BUSINESS_UNIT);

		try
		{
			if(obsErrors == null || obsErrors.size() ==0)
			{
				StringBuilder obsSuccessResp = new StringBuilder(OPENRedesignConstants.CURLY_OPEN_BRACE + 
									OPENRedesignConstants.OBS_JSON_RESP_RESULT
								  + OPENRedesignConstants.COLON + OPENRedesignConstants.CURLY_OPEN_BRACE 
								  + OPENRedesignConstants.OBS_JSON_RESP_STATUS
								   + OPENRedesignConstants.COLON + OPENRedesignConstants.SUCCESS_KEY + 
								   OPENRedesignConstants.CURLY_CLOSE_BRACE + 
								   OPENRedesignConstants.CURLY_CLOSE_BRACE);
				return obsSuccessResp.toString();
			}
			StringBuilder jsonResponse = new StringBuilder(OPENRedesignConstants.CURLY_OPEN_BRACE 
													+ OPENRedesignConstants.OBS_JSON_RESP_RESULT
													+ OPENRedesignConstants.COLON
													+ OPENRedesignConstants.CURLY_OPEN_BRACE);
			jsonResponse.append(OPENRedesignConstants.OBS_JSON_RESP_ERROR);
			jsonResponse.append(OPENRedesignConstants.COLON + 
											OPENRedesignConstants.CURLY_OPEN_BRACE);
			String obsErrorCodeMessage [] = ConfigManager.getPropertiesValue
			  								(OPENRedesignConstants.OPEN_REDESIGN_JCONFIG, 
			  								 OPENRedesignConstants.OPEN_REDESIGN_PROPS, 
			  								 OPENRedesignConstants.REDESIGN_OSC_ERROR_CODE).
			  								 split(OPENRedesignConstants.COMMA);
			jsonResponse.append(OPENRedesignConstants.OBS_JSON_RESP_ERROR_CODE).
						 append(OPENRedesignConstants.COLON).
						 append(obsErrorCodeMessage[0]).
						 append(OPENRedesignConstants.COMMA).
						 append(OPENRedesignConstants.OBS_JSON_RESP_ERROR_MSG).
						 append(OPENRedesignConstants.COLON).
						 append(OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES).
						 append(obsErrorCodeMessage[1]).
						 append(OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES).
						 append(OPENRedesignConstants.CURLY_CLOSE_BRACE).
						 append(OPENRedesignConstants.COMMA).
						 append(OPENRedesignConstants.OBS_JSON_RESP_VAL_ERRORS).
						 append(OPENRedesignConstants.COLON).
						 append(OPENRedesignConstants.CURLY_OPEN_BRACE);
			
			Iterator obsErrorsKeys = obsErrors.entrySet().iterator();
			while(obsErrorsKeys.hasNext())
			{
				Entry error = (Entry)obsErrorsKeys.next();
				jsonResponse.append(OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES).
							 append(error.getKey()).
							 append(OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES).
							 append(OPENRedesignConstants.COLON).
							 append(OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES).
							 append(ConfigManager.getPropertiesValue
										(OPENRedesignConstants.OPEN_REDESIGN_JCONFIG, 
										 OPENRedesignConstants.OPEN_REDESIGN_PROPS, 
									    (String)error.getValue())).
							 append(OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES).
							 append(OPENRedesignConstants.COMMA);
			}
			jsonResponse = jsonResponse.deleteCharAt(jsonResponse.length()-1);
			jsonResponse.append(OPENRedesignConstants.CURLY_CLOSE_BRACE).
					 append(OPENRedesignConstants.COMMA).
					 append(OPENRedesignConstants.OBS_JSON_RESP_STATUS).
					 append(OPENRedesignConstants.COLON).
					 append(OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES);
		
			
			jsonResponse.append(ConfigManager.getPropertiesValue
				  		   (OPENRedesignConstants.OPEN_REDESIGN_JCONFIG, 
						   OPENRedesignConstants.OPEN_REDESIGN_PROPS, 
						   OPENRedesignConstants.REDESIGN_OBS_FAILURE));
			jsonResponse.append(OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES).
					 append(OPENRedesignConstants.CURLY_CLOSE_BRACE).
					 append(OPENRedesignConstants.CURLY_CLOSE_BRACE);
			return jsonResponse.toString();
		}
		catch(Exception e)
		{		
			LOGGER.error(Group.OPEN,
						 OPENURLConstants.BUSINESS_UNIT,
						 e.getMessage()+ 
						 " Exception while creating JSON Response for OBS Check" +
						 e, null);
			return "";
		}
		finally
		{
			LOGGER.exit(Group.OPEN, OPENConstants.BUSINESS_UNIT);
		}
	}
	
	/**
	 * This method creates json response required to prefill the Appln 
	 * page when logged in using the second option of toaster
	 * 
	 * @param osbnform
	 * @return String
	 */
	public String getLongPrefillJSON(RedesignOSBNForm osbnform, boolean isIntlUser, boolean isSsnFtdOptional, HttpSession session)
    {
          LOGGER.entry(Group.OPEN, OPENConstants.BUSINESS_UNIT);
          CardMemberAppDTO cardMemberDTO = (CardMemberAppDTO)session.getAttribute(OPENConstants.CARDMEMBERAPP_DTO);
          if(OPENConstants.YES_Y.equalsIgnoreCase(cardMemberDTO.getMycaLoggedIn()))
          {
        	  session.setAttribute(OPENConstants.SHORTNPA_OPTION1, OPENConstants.TRUE);
        	  session.removeAttribute(OPENRedesignConstants.SHORT_NPA_OPTION2_FLAG);
          }
          else if(!isIntlUser)
          {
        	  session.removeAttribute(OPENConstants.SHORTNPA_OPTION1);
        	  session.setAttribute(OPENRedesignConstants.SHORT_NPA_OPTION2_FLAG, OPENConstants.TRUE);
          }
          Class redesignOSBNForm = null;
          ArrayList<String> fieldsToBeHidden = new ArrayList<String>();
          String jsonKey = isIntlUser ? OPENRedesignConstants.OPEN_REDESIGN_INTL_LAPP_PREFILL_KEYS : 
        	  							(("forNewBusiness".equals(osbnform.getBusinesssType())) ? 
			  							OPENRedesignConstants.OPEN_REDESIGN_LAPP_NEW_BUSINESS : 
			  								OPENRedesignConstants.OPEN_REDESIGN_LAPP_PREFILL_KEYS);
          String errorCode = isIntlUser ? OPENRedesignConstants.RESPONSE_CODE_112 : OPENRedesignConstants.OBS_JSON_RESP_ERROR_CODE_101;
          String tagname = isIntlUser ? OPENRedesignConstants.SHORT_APP : OPENRedesignConstants.CARDMEMBER_KEY;
          StringBuilder jsonResponse = new StringBuilder(OPENRedesignConstants.CURLY_OPEN_BRACE).append(tagname).
                                                          append(OPENRedesignConstants.COLON).append(OPENRedesignConstants.CURLY_OPEN_BRACE);
          jsonResponse.append(OPENRedesignConstants.RESULT).append(OPENRedesignConstants.COLON).append(OPENRedesignConstants.SQUARE_OPEN_BRACE)
          			  .append(OPENRedesignConstants.CURLY_OPEN_BRACE).append(OPENRedesignConstants.SUCCESS_KEY).append(OPENRedesignConstants.COLON)
          			  .append(OPENRedesignConstants.KEY_TRUE).append(OPENRedesignConstants.COMMA).append(OPENRedesignConstants.OBS_JSON_RESP_ERROR_CODE).
          			  append(OPENRedesignConstants.COLON).append(OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES)
          			  .append(errorCode).append(OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES)
          			  .append(OPENRedesignConstants.COMMA).append(OPENRedesignConstants.KEY_ERROR_MSG)
          			  .append(OPENRedesignConstants.COLON).append(OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES).
          			  append(OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES).append(OPENRedesignConstants.CURLY_CLOSE_BRACE)
          			  .append(OPENRedesignConstants.SQUARE_CLOSE_BRACE).append(OPENRedesignConstants.COMMA);
          try
          {
                String json_resp_keys[] = ConfigManager.getPropertiesValue
                                                      (OPENRedesignConstants.OPEN_REDESIGN_JCONFIG, 
                                                       OPENRedesignConstants.OPEN_REDESIGN_PROPS, 
                                                       jsonKey).
                                                       split(OPENRedesignConstants.COMMA);

                redesignOSBNForm = osbnform.getClass();
                int fieldCount = 0;
                jsonResponse.append(OPENRedesignConstants.KEY_VALUES).append(OPENRedesignConstants.COLON)
                			.append(OPENRedesignConstants.SQUARE_OPEN_BRACE);
                while(fieldCount < json_resp_keys.length)
                {
                      jsonResponse.append(OPENRedesignConstants.CURLY_OPEN_BRACE + 
                      OPENRedesignConstants.KEY_NAME + OPENRedesignConstants.COLON + OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES + json_resp_keys[fieldCount]
                      + OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES + OPENRedesignConstants.COMMA);
                      
                      LOGGER.info(Group.OPEN, OPENURLConstants.BUSINESS_UNIT, "fieldvalues in jsonrespmanager:" + "nameoncard:" + osbnform.getNameOnCard()
                                        + ", BusinessNameOnCard:" + osbnform.getBusinessNameOnCard() + ", BusinessCity:" + osbnform.getBusinessCity()+ ", BusinessZip" + osbnform.getBusinessZip());
                      String value = null;
                      try
                      {
                            Method m = redesignOSBNForm.getMethod(json_resp_keys[fieldCount+1]);
                            value = (String)m.invoke(osbnform, null);
                            value = (StringUtils.isEmpty(value) || OPENRedesignConstants.NO_DATA_STRING.equals(value)) ? 
                            		 OPENConstants.EMPTY_STRING : value;
                      }
                      catch(Exception e)
                      {
                            LOGGER.info(Group.OPEN, OPENURLConstants.BUSINESS_UNIT, "exception in jsonrespmanager:" + e.getMessage());
                            LOGGER.error(Group.OPEN,
                                        OPENURLConstants.BUSINESS_UNIT,
                                        e.getMessage()+ 
                                         " Exception while invoking method on RedesignOSBNForm-LongApp JSON Resp creation" +
                                        e, null);
                            LOGGER.info(Group.OPEN, OPENURLConstants.BUSINESS_UNIT, "exception after jsonrespmanager:" + e.getMessage());
                            value = OPENConstants.EMPTY_STRING;
                      }
                      jsonResponse.append(OPENRedesignConstants.JSON_VALUE).append(OPENRedesignConstants.COLON).append(OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES + value + 
                                         OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES + OPENRedesignConstants.COMMA);
                      jsonResponse.append(OPENRedesignConstants.KEY_HIDDEN+ OPENRedesignConstants.COLON + OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES);
                      String flag = json_resp_keys[fieldCount + 2];
                     
                	  flag = StringUtils.isEmpty(value) ? "false" : flag;
                	  
                	  if(OPENRedesignConstants.OSBNFORM_FIELD_CELL_PHN_NUMBER.equals(json_resp_keys[fieldCount]) || 
        			     OPENRedesignConstants.OSBNFORM_FIELD_NO_OF_EMPLOYEES.equals(json_resp_keys[fieldCount]) ||
        			     OPENRedesignConstants.OSBNFORM_FIELD_EMS.equals(json_resp_keys[fieldCount]) ||
        			     OPENRedesignConstants.OSBNFORM_FIELD_ROLE_IN_CMP.equals(json_resp_keys[fieldCount]) ||
        			     OPENRedesignConstants.OSBNFORM_FIELD_BUS_NAME_ON_CARD.equals(json_resp_keys[fieldCount]))
                	  {
                		  flag = "true";
                	  }
                	  else if(OPENRedesignConstants.OSBNFORM_FIELD_LEGALSTRUCTURE.equals(json_resp_keys[fieldCount]))
                      {
                    	  flag = StringUtils.isEmpty(osbnform.getTaxId()) ? "false" : "true";
                      }
                      else if(OPENRedesignConstants.OSBNFORM_FIELD_FED_TAX_ID.equals(json_resp_keys[fieldCount]))
                      {
                    	  String legalStructure = osbnform.getLegalStructure(); 
                    	  if(StringUtils.isEmpty(legalStructure)){
                    		  flag=OPENRedesignConstants.STR_FALSE;
                    	  }else{
	                    	  flag = (((OPENRedesignConstants.OSBNFORM_FIELD_LEGALSTRUCTURE_PARTNERSHIP.equals(legalStructure) ||
	            					 (OPENRedesignConstants.OSBNFORM_FIELD_LEGALSTRUCTURE_CORPORATION.equals(legalStructure))))) ? "false" : "true";
                    	  }
                    	  
                      }
                      jsonResponse.append(flag + OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES + OPENRedesignConstants.CURLY_CLOSE_BRACE + OPENRedesignConstants.COMMA);
                      if(OPENRedesignConstants.TRUE.equals(flag))
                    	  fieldsToBeHidden.add(json_resp_keys[fieldCount + 1]);
                      fieldCount = fieldCount + 3;
                }
                
                jsonResponse = jsonResponse.deleteCharAt(jsonResponse.length()-1);
                
                if(isIntlUser)
                {
                	jsonResponse.append(OPENRedesignConstants.SQUARE_CLOSE_BRACE);
                	jsonResponse = jsonResponse.append(OPENRedesignConstants.COMMA).append(OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES).append("OptionalSSNTaxid").
                	append(OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES).append(OPENRedesignConstants.COLON).append(OPENRedesignConstants.SQUARE_OPEN_BRACE)
                	.append(OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES).append(isSsnFtdOptional).append(OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES);
                }
                jsonResponse.append(OPENRedesignConstants.SQUARE_CLOSE_BRACE).append(OPENRedesignConstants.CURLY_CLOSE_BRACE)
                			.append(OPENRedesignConstants.CURLY_CLOSE_BRACE);
                LOGGER.info(Group.OPEN, OPENURLConstants.BUSINESS_UNIT, 
                                "completed constructing JSON resp for OPEN LApp" + jsonResponse);
          return jsonResponse.toString();
          }     
          catch(Exception e)
          {           
                LOGGER.error(Group.OPEN,
                                  OPENURLConstants.BUSINESS_UNIT,
                                  e.getMessage()+ 
                                   " Exception while creating JSON Response for Open LApp" +
                                  e, null);
                return null;
          }
          finally
          {
                LOGGER.exit(Group.OPEN, OPENConstants.BUSINESS_UNIT);
                session.setAttribute(OPENRedesignConstants.FIELDS_TO_BE_HIDDEN, fieldsToBeHidden);
          }
    }

	
	/**
	 * This method creates json response required to prefill the Appln 
	 * page when logged in using the second option of toaster
	 * 
	 * @param HashMap
	 * @return String
	 */
	public String getErrorJSONResponse(HashMap<String, String> errorMap) {
        StringBuilder ErrorRespJSON = new StringBuilder();
        if(errorMap != null && !errorMap.isEmpty())
        {          
        	ErrorRespJSON.append(OPENRedesignConstants.CURLY_OPEN_BRACE + OPENRedesignConstants.SHORT_APP + OPENRedesignConstants.COLON);
        	ErrorRespJSON.append(OPENRedesignConstants.CURLY_OPEN_BRACE + OPENRedesignConstants.RESULT + OPENRedesignConstants.COLON);
        	ErrorRespJSON.append(OPENRedesignConstants.SQUARE_OPEN_BRACE);                
               
        	for(String key : errorMap.keySet() )
        	{
        		ErrorRespJSON.append(OPENRedesignConstants.CURLY_OPEN_BRACE);           
        		ErrorRespJSON.append(OPENRedesignConstants.SUCCESS_KEY + OPENRedesignConstants.COLON + OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES+OPENRedesignConstants.STR_FALSE);
        		ErrorRespJSON.append(OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES);
        		ErrorRespJSON.append(OPENRedesignConstants.COMMA + OPENRedesignConstants.OBS_JSON_RESP_ERROR_CODE + OPENRedesignConstants.COLON);
        		ErrorRespJSON.append(OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES + key + OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES);
        		ErrorRespJSON.append(OPENRedesignConstants.COMMA + OPENRedesignConstants.KEY_ERROR_MSG);
        		ErrorRespJSON.append( OPENRedesignConstants.COLON + OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES+ 
                           errorMap.get(key));
        		ErrorRespJSON.append(OPENRedesignConstants.ESCAPE_DOUBLE_QUOTES+OPENRedesignConstants.CURLY_CLOSE_BRACE);                        
        	}
        	ErrorRespJSON.append(OPENRedesignConstants.SQUARE_CLOSE_BRACE);
        	ErrorRespJSON.append(OPENRedesignConstants.CURLY_CLOSE_BRACE);
        	ErrorRespJSON.append(OPENRedesignConstants.CURLY_CLOSE_BRACE);
        }     
        return ErrorRespJSON.toString();    
  }
	/**
	 * This method creates json response when the user is stable and holds 
	 * single card
	 * 
	 * @return String
	 */
	public String getStableUserJSONResponse()
	{
		StringBuilder jsonResponse = new StringBuilder(OPENRedesignConstants.CURLY_OPEN_BRACE);
		jsonResponse.append(OPENRedesignConstants.SHORT_APP).append(OPENRedesignConstants.COLON).
		append(OPENRedesignConstants.CURLY_OPEN_BRACE).append(OPENRedesignConstants.RESULT).append(OPENRedesignConstants.COLON).
		append(OPENRedesignConstants.SQUARE_OPEN_BRACE).append(OPENRedesignConstants.CURLY_OPEN_BRACE).
		append(OPENRedesignConstants.SUCCESS_KEY).append(OPENRedesignConstants.COLON).append(OPENRedesignConstants.KEY_TRUE).
		append(OPENRedesignConstants.COMMA).append(OPENRedesignConstants.OBS_JSON_RESP_ERROR_CODE).
		append(OPENRedesignConstants.COLON).append(OPENRedesignConstants.RESPONSE_CODE_111).append(OPENRedesignConstants.COMMA).
		append(OPENRedesignConstants.KEY_ERROR_MSG).append(OPENRedesignConstants.COLON).
		append(OPENRedesignConstants.KEY_STABLE_USER).append(OPENRedesignConstants.CURLY_CLOSE_BRACE).
		append(OPENRedesignConstants.SQUARE_CLOSE_BRACE).append(OPENRedesignConstants.CURLY_CLOSE_BRACE).
		append(OPENRedesignConstants.CURLY_CLOSE_BRACE);
		
		return jsonResponse.toString();
	}
}