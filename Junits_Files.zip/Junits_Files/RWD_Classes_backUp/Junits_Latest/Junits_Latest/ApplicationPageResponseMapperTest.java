/*
 * -------------------------------------------------------------------------
 *
 * (C) Copyright / American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.
 *
 * -------------------------------------------------------------------------
 */

package com.americanexpress.acquisitions.open.web.Test;


/**
 * ApplicationPageResponseMapperTest
 *
 * @author 387142
 * @version $Id$
 */



import javax.servlet.http.HttpServletRequest;
import com.americanexpress.acquisitions.open.commons.formbeans.OSBNForm;
import com.americanexpress.acquisitions.open.commons.util.data.DataBasket;
import com.americanexpress.acquisitions.open.web.managers.ApplicationPageResponseMapper;
import com.americanexpress.acquisitions.services.ccc.domain.AcquisitionResponse;
import com.americanexpress.acquisitions.services.ccc.domain.FormData;
import com.americanexpress.acquisitions.services.ccc.domain.PricingFeature;
import com.americanexpress.acquisitions.services.ccc.domain.ProductRate;
import com.americanexpress.acquisitions.services.ccc.domain.Status;
import static org.junit.Assert.*;
import static org.easymock.EasyMock.createNiceMock;
import org.junit.Test;
/**
 * ApplicationPageResponseMapperTest
 *
 * @author 387142
 * @version $Id$
 */
public class ApplicationPageResponseMapperTest {
	
	
	
	private static final OSBNForm OSBNform = null;
	private String statuscode;



	@SuppressWarnings("null")
	@Test
	public void testAppResponce(){
		AcquisitionResponse fepResponse = new AcquisitionResponse();
		Status status = new Status();
		status.setStatusCode("99");
		fepResponse.setAcquisitionStatus(status);
		PricingFeature pricingFeature = new PricingFeature();
		pricingFeature.setBasicFeeCode("3");
		fepResponse.setPricingFeature(pricingFeature);
		ProductRate productRate = new ProductRate();
		productRate.setAccurateThroughDate("aaaa");
		fepResponse.setProductRate(productRate);
		FormData formData = new FormData();
		formData.setFlowType("lng");
		fepResponse.setFormData(formData);
		ApplicationPageResponseMapper applicationPageResponseMapper = new ApplicationPageResponseMapper(fepResponse );
		DataBasket dataBasket = new DataBasket();
	    applicationPageResponseMapper.updateDataBasket(dataBasket);
	}
			
	@SuppressWarnings("null")
	@Test(expected = NullPointerException.class)
	public void testUpdateFormData(){
		AcquisitionResponse fepResponse = new AcquisitionResponse();
		Status status = new Status();
		status.setStatusCode("99");
		fepResponse.setAcquisitionStatus(status);
		PricingFeature pricingFeature = new PricingFeature();
		pricingFeature.setBasicFeeCode("3");
		fepResponse.setPricingFeature(pricingFeature);
		ProductRate productRate = new ProductRate();
		productRate.setAccurateThroughDate("aaaa");
		fepResponse.setProductRate(productRate);
		FormData formData = new FormData();
		formData.setFlowType("lng");
		fepResponse.setFormData(formData);
		HttpServletRequest httpServletRequest = createNiceMock(HttpServletRequest.class);
		//HttpServletRequest httpServletRequest = null ;
		Object appId;
		String arg = null;
		//httpServletRequest.getSession().putValue("appid", appId));
		httpServletRequest.setAttribute(arg, "123123");		
		ApplicationPageResponseMapper applicationPageResponseMapper = new ApplicationPageResponseMapper(fepResponse , httpServletRequest);
	    applicationPageResponseMapper.updateFormData(OSBNform);
	}
	
	@SuppressWarnings("null")
	@Test
	public void testgetacquisitionStatus(){
		HttpServletRequest httpServletRequest = createNiceMock(HttpServletRequest.class);
		AcquisitionResponse fepResponse = new AcquisitionResponse();
		Status status = new Status();
		status.setStatusCode("60");
		fepResponse.setAcquisitionStatus(status);
		FormData formData = new FormData();
		formData.setFlowType("lng");
		fepResponse.setFormData(formData);
		ApplicationPageResponseMapper applicationPageResponseMapper = new ApplicationPageResponseMapper(fepResponse );
		statuscode =applicationPageResponseMapper.getacquisitionStatus(httpServletRequest);
		assertEquals("FAILED", statuscode);
	}
	
	
	@SuppressWarnings("null")
	@Test
	public void testgetacquisitionStatusSucess(){
		HttpServletRequest httpServletRequest = createNiceMock(HttpServletRequest.class);		
		AcquisitionResponse fepResponse = new AcquisitionResponse();
		Status status = new Status();
		status.setStatusCode("59");
		fepResponse.setAcquisitionStatus(status);
		FormData formData = new FormData();
		formData.setFlowType("lng");
		fepResponse.setFormData(formData);		
		ApplicationPageResponseMapper applicationPageResponseMapper = new ApplicationPageResponseMapper(fepResponse );
		statuscode =applicationPageResponseMapper.getacquisitionStatus(httpServletRequest);
		assertEquals("SUCCESS", statuscode);
	}
	
	

	@SuppressWarnings("null")
	@Test
	public void testgetacquisitionStatusFailed2(){
		HttpServletRequest httpServletRequest = createNiceMock(HttpServletRequest.class);
		AcquisitionResponse fepResponse=null;
		ApplicationPageResponseMapper applicationPageResponseMapper = new ApplicationPageResponseMapper(fepResponse );
		statuscode =applicationPageResponseMapper.getacquisitionStatus(httpServletRequest);
		assertEquals("FAILED", statuscode);
	}
}
