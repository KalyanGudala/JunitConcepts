/*
 * -------------------------------------------------------------------------
 *
 * (C) Copyright / American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.
 *
 * -------------------------------------------------------------------------
 */

package com.americanexpress.acquisitions.open.web.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.americanexpress.acquisitions.open.commons.shortapp.cardservice.Eligiblecard;
import com.americanexpress.acquisitions.open.commons.shortapp.cardservice.ShortAppProduct;
import com.americanexpress.acquisitions.open.commons.shortapp.helper.SBSHelper;
import com.americanexpress.acquisitions.open.web.beans.CardMemberAppDTO;
import com.americanexpress.acquisitions.open.web.managers.CardMemberFepResponseMapper;
import com.americanexpress.acquisitions.services.ccc.domain.AcquisitionResponse;
import com.americanexpress.acquisitions.services.ccc.domain.CardData;
import com.americanexpress.acquisitions.services.ccc.domain.EligibilityData;
import com.americanexpress.acquisitions.services.ccc.domain.FormData;
import com.americanexpress.acquisitions.services.ccc.domain.Reason;
import com.americanexpress.acquisitions.services.ccc.domain.SecurityData;
import com.americanexpress.acquisitions.services.ccc.domain.Status;
import com.americanexpress.acquisitions.services.mycariskengineservice.data.MycaRiskAnalyzeResponse;
import com.americanexpress.wss.shr.authorization.token.SecurityToken;
import org.easymock.EasyMock;
import org.junit.Test;
import static org.junit.Assert.assertNotNull;


/**
 * CardMemberFepResponseMapperTest
 *
 * @author 387142
 * @version $Id$
 */
public class CardMemberFepResponseMapperTest {
	CardMemberAppDTO cardMemberAppDTO;
	AcquisitionResponse acqResponse;
	CardMemberFepResponseMapper cardMemberFepResponseMapper;
	Status acquisitionStatus;
	FormData formdata;
	List<Reason> reasonList=new ArrayList<Reason>();
	List<Reason> errorList = new ArrayList<Reason>();
	List<CardData> cardDataList =new ArrayList<CardData>();
	Reason reason;
	HttpSession session;
	MycaRiskAnalyzeResponse mycaRiskAnalyzeResponse;
	SecurityData securityData;
	SecurityToken securityToken;
	EligibilityData eligibilityData;
	List<CardData> cardData=new ArrayList<CardData>();
	List<CardData> primaryCardList = new ArrayList<CardData>();
	List<Eligiblecard> personalCards=new ArrayList<Eligiblecard>();
	List<Eligiblecard> smallBusinessCards=new ArrayList<Eligiblecard>();
	ShortAppProduct shortappproduct;
	List<String> digitalAssetIdList=new ArrayList<String>();
	HashMap<String, ShortAppProduct> cardProducts = null;
	Eligiblecard eligiblecard;
	SBSHelper sbshelper;
	CardData carddata;
	@Test
	public void testupdateDTOForFepLoginPageResponse(){		
		acqResponse =new AcquisitionResponse();
		formdata=new FormData();
		acqResponse.setFormData(formdata);
		formdata.setCmaxKey("1234");
		formdata.setAppID("1234");
		formdata.setCategory("gold");
		cardMemberAppDTO=new CardMemberAppDTO();
		cardMemberFepResponseMapper=new CardMemberFepResponseMapper(acqResponse);
		cardMemberFepResponseMapper.updateDTOForFepLoginPageResponse(cardMemberAppDTO);				
	}
	
	@Test
	public void testupdateDTOForFepUserLogonInfo(){		
		acqResponse =new AcquisitionResponse();
		session = EasyMock.createNiceMock(HttpSession.class);
		cardMemberAppDTO=new CardMemberAppDTO();
		cardMemberFepResponseMapper=new CardMemberFepResponseMapper(acqResponse);
		cardMemberFepResponseMapper.updateDTOForFepUserLogonInfo(cardMemberAppDTO,session);				
	}
	
	@Test
	public void testupdateDTOForFepUserLogonInfo1(){		
		acqResponse =new AcquisitionResponse();
		mycaRiskAnalyzeResponse=new MycaRiskAnalyzeResponse();
		acqResponse.setMycaRiskAnalyzeResponse(mycaRiskAnalyzeResponse);
		session = EasyMock.createNiceMock(HttpSession.class);
		cardMemberAppDTO=new CardMemberAppDTO();
		cardMemberFepResponseMapper=new CardMemberFepResponseMapper(acqResponse);
		cardMemberFepResponseMapper.updateDTOForFepUserLogonInfo(cardMemberAppDTO,session);				
	}
	
	@Test
	public void testupdateDTOForFepUserLogonInfo2(){		
		acqResponse =new AcquisitionResponse();
		mycaRiskAnalyzeResponse=new MycaRiskAnalyzeResponse();
		acqResponse.setMycaRiskAnalyzeResponse(mycaRiskAnalyzeResponse);
		mycaRiskAnalyzeResponse.setRuleName("mycarule");
		mycaRiskAnalyzeResponse.setTransactionId("23456");
		session = EasyMock.createNiceMock(HttpSession.class);
		cardMemberAppDTO=new CardMemberAppDTO();
		cardMemberFepResponseMapper=new CardMemberFepResponseMapper(acqResponse);
		cardMemberFepResponseMapper.updateDTOForFepUserLogonInfo(cardMemberAppDTO,session);				
	}
	
	@Test
	public void testupdateDTOForFepUserLogonInfo3(){		
		acqResponse =new AcquisitionResponse();
		securityData=new SecurityData();		
		securityData.setSecurityToken(securityToken);
		securityData.setGuid("12345");
		acqResponse.setSecurityData(securityData);
		session = EasyMock.createNiceMock(HttpSession.class);
		cardMemberAppDTO=new CardMemberAppDTO();
		cardMemberFepResponseMapper=new CardMemberFepResponseMapper(acqResponse);
		cardMemberFepResponseMapper.updateDTOForFepUserLogonInfo(cardMemberAppDTO,session);				
	}
	
	@Test
	public void testupdateDTOForFepUserLogonInfo4(){		
		acqResponse =new AcquisitionResponse();
		mycaRiskAnalyzeResponse=new MycaRiskAnalyzeResponse();
		acqResponse.setMycaRiskAnalyzeResponse(mycaRiskAnalyzeResponse);
		mycaRiskAnalyzeResponse.setRuleName("L");
		eligibilityData=new EligibilityData();		
		eligibilityData.setCardMemberUserIDIsStable("TRUE");
		acqResponse.setEligibilityData(eligibilityData);		
		session = EasyMock.createNiceMock(HttpSession.class);
		cardMemberAppDTO=new CardMemberAppDTO();
		cardMemberFepResponseMapper=new CardMemberFepResponseMapper(acqResponse);
		cardMemberFepResponseMapper.updateDTOForFepUserLogonInfo(cardMemberAppDTO,session);				
	}
	
	@Test
	public void testupdateDTOForFepUserLogonInfo5(){		
		acqResponse =new AcquisitionResponse();
		mycaRiskAnalyzeResponse=new MycaRiskAnalyzeResponse();
		acqResponse.setMycaRiskAnalyzeResponse(mycaRiskAnalyzeResponse);
		mycaRiskAnalyzeResponse.setRuleName("H");
		eligibilityData=new EligibilityData();		
		eligibilityData.setCardMemberUserIDIsStable("FALSE");
		acqResponse.setEligibilityData(eligibilityData);		
		session = EasyMock.createNiceMock(HttpSession.class);
		cardMemberAppDTO=new CardMemberAppDTO();
		cardMemberFepResponseMapper=new CardMemberFepResponseMapper(acqResponse);
		cardMemberFepResponseMapper.updateDTOForFepUserLogonInfo(cardMemberAppDTO,session);				
	}
	
	@Test
	public void testupdateDTOForFepUserLogonInfo6(){		
		acqResponse =new AcquisitionResponse();
		acqResponse.setCardData(cardData);		
		session = EasyMock.createNiceMock(HttpSession.class);
		cardMemberAppDTO=new CardMemberAppDTO();
		cardMemberFepResponseMapper=new CardMemberFepResponseMapper(acqResponse);
		cardMemberFepResponseMapper.updateDTOForFepUserLogonInfo(cardMemberAppDTO,session);				
	}
	
	/*@Test
	public void testprepareCIDPageMatrix(){
		acqResponse =new AcquisitionResponse();
		acqResponse.setCardData(cardDataList);
		cardMemberAppDTO=new CardMemberAppDTO();
		sbshelper=new SBSHelper();
		carddata=new CardData();
		carddata.setCardType("TYPE_COMPANY");
		//carddata.setCardType("Type_Consumer");
		carddata.setAcctStatus("ACTIVE");
		//carddata.setAcctStatus("Type_Consumer");
		cardDataList.add(carddata);		
		primaryCardList.add(carddata);	
		cardMemberFepResponseMapper=new CardMemberFepResponseMapper(acqResponse);
		cardMemberFepResponseMapper.prepareCIDPageMatrix(cardMemberAppDTO);
	}*/
	
	@Test
	public void testprepareCIDPageMatrix1(){
		acqResponse =new AcquisitionResponse();		
		cardMemberAppDTO=new CardMemberAppDTO();
		sbshelper=new SBSHelper();
		carddata=new CardData();
		carddata.setCardType("Type_Company");		
		carddata.setAcctStatus("ACTIVE");
		carddata.setBasic(true);
		carddata.setDigitalAssetId("NUS000000026");
		cardDataList.add(carddata);
		//cardData.add(carddata);				
		acqResponse.setCardData(cardDataList);		
		cardMemberFepResponseMapper=new CardMemberFepResponseMapper(acqResponse);
		cardMemberFepResponseMapper.prepareCIDPageMatrix(cardMemberAppDTO);
	}
	
	@Test
	public void testprepareCIDPageMatrix2(){
		acqResponse =new AcquisitionResponse();		
		cardMemberAppDTO=new CardMemberAppDTO();
		sbshelper=new SBSHelper();
		carddata=new CardData();		
		carddata.setCardType("Type_Consumer");				
		carddata.setAcctStatus("Reinstated");
		carddata.setBasic(true);
		cardDataList.add(carddata);		
		acqResponse.setCardData(cardDataList);		
		cardMemberFepResponseMapper=new CardMemberFepResponseMapper(acqResponse);
		cardMemberFepResponseMapper.prepareCIDPageMatrix(cardMemberAppDTO);
	}
	
	
	@Test
	public void testgetLatestCCSGCardDetails(){
		acqResponse =new AcquisitionResponse();
		cardMemberFepResponseMapper=new CardMemberFepResponseMapper(acqResponse);
		eligiblecard=new Eligiblecard();
		eligiblecard.setAcctSetupDate("12/12/2013");
		eligiblecard.setAccountNumber("123456");
		personalCards.add(eligiblecard);
		assertNotNull(cardMemberFepResponseMapper.getLatestCCSGCardDetails(personalCards));		
	}
	
	
	@Test
	public void testgetDisplayLoginPagStatus(){				
		acqResponse=new AcquisitionResponse();
		cardMemberFepResponseMapper=new CardMemberFepResponseMapper(acqResponse);
		String flowType="shortnpa";
		assertNotNull(cardMemberFepResponseMapper.getDisplayLoginPagStatus(flowType));				
	}
	
	@Test
	public void testgetDisplayLoginPagStatus1(){				
		acqResponse=new AcquisitionResponse();
		cardMemberFepResponseMapper=new CardMemberFepResponseMapper(acqResponse);
		String flowType="shortnpa";		
		acqResponse.setDefaultSourceCodeFlag(true);		
		String statusCode ="00";
		Reason reason=new Reason();
		reason.setReasonCode(5451);
		reason.setReasonMsg("ReasonMessage");
		assertNotNull(cardMemberFepResponseMapper.getDisplayLoginPagStatus(flowType));				
	}
	
	@Test
	public void testgetDisplayLoginPagStatus2(){
		acquisitionStatus=new Status() ;
		acqResponse =new AcquisitionResponse();
		formdata=new FormData();
		acqResponse.setFormData(formdata);
		acqResponse.setDefaultSourceCodeFlag(true);
		acquisitionStatus.setStatusCode("00");		
		acqResponse.setAcquisitionStatus(acquisitionStatus);
		cardMemberFepResponseMapper=new CardMemberFepResponseMapper(acqResponse);
		String flowType="shortnpa";		
		assertNotNull(cardMemberFepResponseMapper.getDisplayLoginPagStatus(flowType));		
		
	}
	
	@Test
	public void testgetDisplayLoginPagStatus3(){
		acquisitionStatus=new Status() ;
		acqResponse =new AcquisitionResponse();
		formdata=new FormData();
		acqResponse.setFormData(formdata);
		acqResponse.setDefaultSourceCodeFlag(true);
		acquisitionStatus.setStatusCode("20");		
		acqResponse.setAcquisitionStatus(acquisitionStatus);
		cardMemberFepResponseMapper=new CardMemberFepResponseMapper(acqResponse);
		String flowType="shortnpa";		
		assertNotNull(cardMemberFepResponseMapper.getDisplayLoginPagStatus(flowType));		
		
	}
	
	@Test
	public void testgetDisplayLoginPagStatus4(){
		acquisitionStatus=new Status() ;
		acqResponse =new AcquisitionResponse();
		formdata=new FormData();
		acqResponse.setFormData(formdata);
		acqResponse.setDefaultSourceCodeFlag(true);
		acquisitionStatus.setStatusCode("40");		
		acqResponse.setAcquisitionStatus(acquisitionStatus);
		cardMemberFepResponseMapper=new CardMemberFepResponseMapper(acqResponse);
		String flowType="shortnpa";		
		assertNotNull(cardMemberFepResponseMapper.getDisplayLoginPagStatus(flowType));				
	}
	
	@Test
	public void testgetDisplayLoginPagStatus5(){
		acquisitionStatus=new Status() ;
		acqResponse =new AcquisitionResponse();
		formdata=new FormData();
		acqResponse.setFormData(formdata);
		acqResponse.setDefaultSourceCodeFlag(false);
		acquisitionStatus.setStatusCode("00");		
		acqResponse.setAcquisitionStatus(acquisitionStatus);
		cardMemberFepResponseMapper=new CardMemberFepResponseMapper(acqResponse);
		String flowType="shortnpa";		
		assertNotNull(cardMemberFepResponseMapper.getDisplayLoginPagStatus(flowType));				
	}
	
	@Test
	public void testgetDisplayLoginPagStatus6(){
		acquisitionStatus=new Status() ;
		acqResponse =new AcquisitionResponse();
		formdata=new FormData();
		acqResponse.setFormData(formdata);
		acqResponse.setDefaultSourceCodeFlag(true);
		acquisitionStatus.setStatusCode("60");		
		acqResponse.setAcquisitionStatus(acquisitionStatus);		
		cardMemberFepResponseMapper=new CardMemberFepResponseMapper(acqResponse);
		String flowType="shortnpa";		
		assertNotNull(cardMemberFepResponseMapper.getDisplayLoginPagStatus(flowType));				
	}
	
	@Test
	public void testgetDisplayLoginPagStatus7(){		
		acquisitionStatus=new Status() ;
		acqResponse =new AcquisitionResponse();
		formdata=new FormData();
		reason =new Reason();
		reason.setReasonCode(2028);
		reason.setReasonMsg("reason message is");				
		reasonList.add(reason);
		acqResponse.setFormData(formdata);
		acqResponse.setDefaultSourceCodeFlag(true);
		acquisitionStatus.setStatusCode("60");		
		acqResponse.setAcquisitionStatus(acquisitionStatus);		
		cardMemberFepResponseMapper=new CardMemberFepResponseMapper(acqResponse);
		String flowType="shortpa";		
		assertNotNull(cardMemberFepResponseMapper.getDisplayLoginPagStatus(flowType));				
	}
	
	@Test
	public void testgetDisplayLoginPagStatus8(){		
		acquisitionStatus=new Status() ;
		acqResponse =new AcquisitionResponse();		
		formdata=new FormData();
		reason =new Reason();
		reason.setReasonCode(2028);
		reason.setReasonMsg("2028");		
		reasonList.add(reason);
		errorList.add(reason);
		acqResponse.setFormData(formdata);
		acqResponse.setDefaultSourceCodeFlag(true);
		acquisitionStatus.setStatusCode("60");
		acquisitionStatus.setErrorList(errorList);
		acqResponse.setAcquisitionStatus(acquisitionStatus);
		cardMemberFepResponseMapper=new CardMemberFepResponseMapper(acqResponse);
		String flowType="shortpa";		
		assertNotNull(cardMemberFepResponseMapper.getDisplayLoginPagStatus(flowType));				
	}
	
	@Test
	public void testgetDisplayLoginPagStatus9(){		
		acquisitionStatus=new Status() ;
		acqResponse =new AcquisitionResponse();		
		formdata=new FormData();
		reason =new Reason();
		reason.setReasonCode(5451);
		reason.setReasonMsg("5451");		
		reasonList.add(reason);
		errorList.add(reason);
		acqResponse.setFormData(formdata);
		acqResponse.setDefaultSourceCodeFlag(true);
		acquisitionStatus.setStatusCode("60");
		acquisitionStatus.setErrorList(errorList);
		acqResponse.setAcquisitionStatus(acquisitionStatus);
		cardMemberFepResponseMapper=new CardMemberFepResponseMapper(acqResponse);
		String flowType="shortnpa";		
		assertNotNull(cardMemberFepResponseMapper.getDisplayLoginPagStatus(flowType));				
	}
	
	@Test
	public void testgetDisplayLoginPagStatus10(){		
		acquisitionStatus=new Status() ;
		acqResponse =new AcquisitionResponse();		
		formdata=new FormData();
		reason =new Reason();
		reason.setReasonCode(5491);
		reason.setReasonMsg("5491");		
		reasonList.add(reason);
		errorList.add(reason);
		acqResponse.setFormData(formdata);
		acqResponse.setDefaultSourceCodeFlag(true);
		acquisitionStatus.setStatusCode("60");
		acquisitionStatus.setErrorList(errorList);
		acqResponse.setAcquisitionStatus(acquisitionStatus);
		cardMemberFepResponseMapper=new CardMemberFepResponseMapper(acqResponse);
		String flowType="shortnpa";		
		assertNotNull(cardMemberFepResponseMapper.getDisplayLoginPagStatus(flowType));				
	}	
	
	@Test
	public void testgetLoggedInPageAcqStatus(){
		acquisitionStatus=new Status() ;
		acqResponse =new AcquisitionResponse();		
		acqResponse.setAcquisitionStatus(acquisitionStatus);
		acquisitionStatus.setStatusCode("00");
		cardMemberFepResponseMapper=new CardMemberFepResponseMapper(acqResponse);				
		assertNotNull(cardMemberFepResponseMapper.getLoggedInPageAcqStatus());				
	}
	
	@Test
	public void testgetLoggedInPageAcqStatus1(){
		acquisitionStatus=new Status() ;
		acqResponse =new AcquisitionResponse();		
		acqResponse.setAcquisitionStatus(acquisitionStatus);
		acquisitionStatus.setStatusCode("20");
		cardMemberFepResponseMapper=new CardMemberFepResponseMapper(acqResponse);				
		assertNotNull(cardMemberFepResponseMapper.getLoggedInPageAcqStatus());				
	}
	
	@Test
	public void testgetLoggedInPageAcqStatus2(){
		acquisitionStatus=new Status() ;
		acqResponse =new AcquisitionResponse();		
		acqResponse.setAcquisitionStatus(acquisitionStatus);
		acquisitionStatus.setStatusCode("40");
		cardMemberFepResponseMapper=new CardMemberFepResponseMapper(acqResponse);				
		assertNotNull(cardMemberFepResponseMapper.getLoggedInPageAcqStatus());				
	}
	@Test
	public void testgetLoggedInPageAcqStatus3(){
		acquisitionStatus=new Status() ;
		acqResponse =new AcquisitionResponse();		
		acqResponse.setAcquisitionStatus(acquisitionStatus);
		acquisitionStatus.setStatusCode("60");
		cardMemberFepResponseMapper=new CardMemberFepResponseMapper(acqResponse);				
		assertNotNull(cardMemberFepResponseMapper.getLoggedInPageAcqStatus());				
	}
	@Test
	public void testgetLoggedInPageAcqStatus4(){		
		acqResponse =new AcquisitionResponse();				
		cardMemberFepResponseMapper=new CardMemberFepResponseMapper(acqResponse);				
		assertNotNull(cardMemberFepResponseMapper.getLoggedInPageAcqStatus());				
	}
	
	@Test
	public void testgetAcqStatusText(){
		acquisitionStatus=new Status() ;
		acqResponse =new AcquisitionResponse();		
		acqResponse.setAcquisitionStatus(acquisitionStatus);
		acquisitionStatus.setStatusCode("00");
		cardMemberFepResponseMapper=new CardMemberFepResponseMapper(acqResponse);				
		assertNotNull(cardMemberFepResponseMapper.getAcqStatusText());				
	}
	@Test
	public void testgetAcqStatusText1(){
		acquisitionStatus=new Status() ;
		acqResponse =new AcquisitionResponse();		
		acqResponse.setAcquisitionStatus(acquisitionStatus);
		acquisitionStatus.setStatusCode("20");
		cardMemberFepResponseMapper=new CardMemberFepResponseMapper(acqResponse);				
		assertNotNull(cardMemberFepResponseMapper.getAcqStatusText());				
	}
	@Test
	public void testgetAcqStatusText2(){
		acquisitionStatus=new Status() ;
		acqResponse =new AcquisitionResponse();		
		acqResponse.setAcquisitionStatus(acquisitionStatus);
		acquisitionStatus.setStatusCode("40");
		cardMemberFepResponseMapper=new CardMemberFepResponseMapper(acqResponse);				
		assertNotNull(cardMemberFepResponseMapper.getAcqStatusText());				
	}
	@Test
	public void testgetAcqStatusText3(){
		acquisitionStatus=new Status() ;
		acqResponse =new AcquisitionResponse();		
		acqResponse.setAcquisitionStatus(acquisitionStatus);
		acquisitionStatus.setStatusCode("60");
		cardMemberFepResponseMapper=new CardMemberFepResponseMapper(acqResponse);				
		assertNotNull(cardMemberFepResponseMapper.getAcqStatusText());				
	}
	
}
