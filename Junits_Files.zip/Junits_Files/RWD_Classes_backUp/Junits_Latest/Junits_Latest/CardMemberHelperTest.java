/*
 * -------------------------------------------------------------------------
 *
 * (C) Copyright / American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.
 *
 * -------------------------------------------------------------------------
 */

package com.americanexpress.acquisitions.open.web.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.americanexpress.acquisitions.commons.url.param.CommonParam;
import com.americanexpress.acquisitions.open.commons.common.EOICookie;
import com.americanexpress.acquisitions.open.commons.common.SSOCookie;
import com.americanexpress.acquisitions.open.commons.common.constants.OPENConstants;
import com.americanexpress.acquisitions.open.commons.formbeans.RedesignOSBNForm;
import com.americanexpress.acquisitions.open.commons.mapper.FEPRequestMapper;
import com.americanexpress.acquisitions.open.commons.url.helper.OPENURLParameterHelper;
import com.americanexpress.acquisitions.open.commons.url.param.OPENCommonParam;
import com.americanexpress.acquisitions.open.web.beans.CardMemberAppDTO;
import com.americanexpress.acquisitions.open.web.managers.CardMemberFepResponseMapper;
import com.americanexpress.acquisitions.open.web.managers.CardMemberHelper;
import com.americanexpress.acquisitions.open.web.managers.CardMemberLoginHelper;

import com.americanexpress.acquisitions.services.ccc.domain.AcquisitionRequest;
import com.americanexpress.acquisitions.services.ccc.domain.AcquisitionResponse;
import com.americanexpress.acquisitions.services.ccc.domain.CardData;
import com.americanexpress.acquisitions.services.ccc.domain.PricingFeature;
import com.americanexpress.acquisitions.services.ccc.domain.Reason;
import com.americanexpress.acquisitions.services.ccc.domain.SecurityData;
import com.americanexpress.acquisitions.services.ccc.domain.Status;
import com.americanexpress.security.shr.client.claim.Claim;
import com.americanexpress.wss.shr.authorization.token.SecurityToken;

import org.apache.struts.action.ActionForm;
import org.easymock.EasyMock;
import org.junit.Test;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.replay;
import static org.easymock.EasyMock.verify;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
/**
 * CardMemberHelperTest
 *
 * @author 387142
 * @version $Id$
 */

public class CardMemberHelperTest {
	
    public CardMemberHelper cardMemberHelper;
    public CardMemberLoginHelper cardMemberLoginHelper;
    public ActionForm form;
	public HttpServletRequest request;
	public HttpServletResponse response;   
    public HttpSession session; 
    public CardMemberAppDTO cardMemberAppDTO;
    public EOICookie eoicookie;
    public Cookie cookie;
    public AcquisitionResponse acquisitionResponse;
    public RedesignOSBNForm redesignAppForm;
    public OPENURLParameterHelper parameterHelper;
    public CommonParam commonParam;
    FEPRequestMapper fepRequestMapper;
    
    @Test
    public void testupdateCardMemberAppDTOAndForm(){    	
		request =EasyMock.createNiceMock(HttpServletRequest.class);		
		response =EasyMock.createNiceMock(HttpServletResponse.class);
		form=EasyMock.createNiceMock(ActionForm.class);				
		session = EasyMock.createNiceMock(HttpSession.class);		
		expect(request.getSession()).andReturn(session);
		replay(request);		
		cardMemberAppDTO=new CardMemberAppDTO();				
		cardMemberAppDTO.setFlowType("shortnpa");
		cardMemberAppDTO.setEntryPoint("37890");
		cardMemberAppDTO.setAppType("applicationType");
		cardMemberAppDTO.setBasicOrSupp("basic");
		cardMemberAppDTO.setPageId("78690");
		cardMemberAppDTO.setCardName("businessCard");
		cardMemberAppDTO.setOfferCode("3456");		
		redesignAppForm=new RedesignOSBNForm();		
		cardMemberHelper=new CardMemberHelper(form,request,response);			
		cardMemberHelper.updateCardMemberAppDTOAndForm(redesignAppForm);
		verify(request);
    }
    
    @Test(expected=NullPointerException.class)
    public void testGetFEPLoginResponse(){
    	/*Map<String, Object> urlParams = null;
    	urlParams.put("", commonParam)
		commonParam.setUrlParams(urlParams);*/
    	cardMemberAppDTO = new CardMemberAppDTO();
    	cardMemberAppDTO.setFlowType("shortpa");
    	request =EasyMock.createNiceMock(HttpServletRequest.class);
    	response =EasyMock.createNiceMock(HttpServletResponse.class);
    	session = EasyMock.createNiceMock(HttpSession.class);
    	fepRequestMapper = EasyMock.createNiceMock(FEPRequestMapper.class);
    	expect(request.getSession()).andReturn(session);
    	expect((CardMemberAppDTO)request.getAttribute(OPENConstants.CARDMEMBERAPP_DTO)).andReturn(cardMemberAppDTO);
    	expect(new FEPRequestMapper()).andReturn(fepRequestMapper);
    	OPENCommonParam openCommonParam = new OPENCommonParam();
		expect(request.getAttribute(OPENConstants.OPEN_COMMON_PARAM_OBJECT)).andReturn(openCommonParam );
		replay(request);
		replay(fepRequestMapper);
    	cardMemberHelper=new CardMemberHelper(form,request,response);
    	cardMemberHelper.getFEPLoginResponse(redesignAppForm);
    }
    
    
    
    @Test(expected=NullPointerException.class)
    public void testGetFEPLoginResponse1(){
    	/*Map<String, Object> urlParams = null;
    	urlParams.put("", commonParam)
		commonParam.setUrlParams(urlParams);*/
    	cardMemberAppDTO = new CardMemberAppDTO();
    	cardMemberAppDTO.setFlowType("shortnpa");
    	request =EasyMock.createNiceMock(HttpServletRequest.class);
    	response =EasyMock.createNiceMock(HttpServletResponse.class);
    	session = EasyMock.createNiceMock(HttpSession.class);
    	fepRequestMapper = EasyMock.createNiceMock(FEPRequestMapper.class);
    	expect(request.getSession()).andReturn(session);
    	expect((CardMemberAppDTO)request.getAttribute(OPENConstants.CARDMEMBERAPP_DTO)).andReturn(cardMemberAppDTO);
    	expect(new FEPRequestMapper()).andReturn(fepRequestMapper);
    	OPENCommonParam openCommonParam = new OPENCommonParam();
		expect(request.getAttribute(OPENConstants.OPEN_COMMON_PARAM_OBJECT)).andReturn(openCommonParam );
		replay(request);
		replay(fepRequestMapper);
    	cardMemberHelper=new CardMemberHelper(form,request,response);
    	cardMemberHelper.getFEPLoginResponse(redesignAppForm);
    }
    
    
    @Test
    public void testPrepareURLForDefaultSourceCode(){
    	cardMemberAppDTO = new CardMemberAppDTO();
    	cardMemberAppDTO.setFlowType("shortpa");
    	request =EasyMock.createNiceMock(HttpServletRequest.class);
    	response =EasyMock.createNiceMock(HttpServletResponse.class);
    	session = EasyMock.createNiceMock(HttpSession.class);
    	fepRequestMapper = EasyMock.createNiceMock(FEPRequestMapper.class);
    	expect(request.getSession()).andReturn(session);
    	expect((CardMemberAppDTO)request.getAttribute(OPENConstants.CARDMEMBERAPP_DTO)).andReturn(cardMemberAppDTO);
    	expect(new FEPRequestMapper()).andReturn(fepRequestMapper);
    	OPENCommonParam openCommonParam = new OPENCommonParam();
		expect(request.getAttribute(OPENConstants.OPEN_COMMON_PARAM_OBJECT)).andReturn(openCommonParam );
		replay(request);
		replay(fepRequestMapper);
    	cardMemberHelper=new CardMemberHelper(form,request,response);
    	cardMemberHelper.prepareURLForDefaultSourceCode(request);
    	
    }
      
    @Test
    public void testIsInValidUserResonse(){
    	cardMemberAppDTO = new CardMemberAppDTO();
    	cardMemberAppDTO.setFlowType("shortpa");
    	cardMemberAppDTO.setPublicGuid("1234567894");
    	List<CardData> cardDataList = new ArrayList<CardData>();
    	CardData cardData = new CardData();
    	cardData.setAcctNumber("123456");
		cardDataList.add(cardData );
		cardMemberAppDTO.setCardDataList(cardDataList);
	//	Claim list = (Claim) new ArrayList();
		SecurityToken securityToken = null;//new SecurityToken("111","111","111","111","","111");
		
    	request =EasyMock.createNiceMock(HttpServletRequest.class);
    	response =EasyMock.createNiceMock(HttpServletResponse.class);
    	session = EasyMock.createNiceMock(HttpSession.class);
    	//securityToken =EasyMock.createNiceMock(SecurityToken.class);
    	fepRequestMapper = EasyMock.createNiceMock(FEPRequestMapper.class);
    	expect(request.getSession()).andReturn(session);
    	cardMemberAppDTO.setSecurityToken(securityToken);
    	expect((CardMemberAppDTO)request.getAttribute(OPENConstants.CARDMEMBERAPP_DTO)).andReturn(cardMemberAppDTO);
    	expect(new FEPRequestMapper()).andReturn(fepRequestMapper);
    	OPENCommonParam openCommonParam = new OPENCommonParam();
		expect(request.getAttribute(OPENConstants.OPEN_COMMON_PARAM_OBJECT)).andReturn(openCommonParam );
		replay(request);
		replay(fepRequestMapper);
    	cardMemberHelper=new CardMemberHelper(form,request,response);
    	AcquisitionResponse acqResponce = new AcquisitionResponse();
    	acqResponce.setPreApprovedStatus("true");
		cardMemberHelper.isInValidUserResonse(acqResponce);
    	
    }
    @Test
    public void testIsInValidUserResonse1(){
    	cardMemberAppDTO = new CardMemberAppDTO();
    	cardMemberAppDTO.setFlowType("shortpa");
    	cardMemberAppDTO.setPublicGuid(null);
    	List<CardData> cardDataList = new ArrayList<CardData>();
    	CardData cardData = new CardData();
    	cardData.setAcctNumber("123456");
		cardDataList.add(cardData );
		cardMemberAppDTO.setCardDataList(cardDataList);
	//	Claim list = (Claim) new ArrayList();
		SecurityToken securityToken = null;//new SecurityToken("111","111","111","111","","111");
		
    	request =EasyMock.createNiceMock(HttpServletRequest.class);
    	response =EasyMock.createNiceMock(HttpServletResponse.class);
    	session = EasyMock.createNiceMock(HttpSession.class);
    	//securityToken =EasyMock.createNiceMock(SecurityToken.class);
    	fepRequestMapper = EasyMock.createNiceMock(FEPRequestMapper.class);
    	expect(request.getSession()).andReturn(session);
    	cardMemberAppDTO.setSecurityToken(securityToken);
    	expect((CardMemberAppDTO)request.getAttribute(OPENConstants.CARDMEMBERAPP_DTO)).andReturn(cardMemberAppDTO);
    	expect(new FEPRequestMapper()).andReturn(fepRequestMapper);
    	OPENCommonParam openCommonParam = new OPENCommonParam();
		expect(request.getAttribute(OPENConstants.OPEN_COMMON_PARAM_OBJECT)).andReturn(openCommonParam );
		replay(request);
		replay(fepRequestMapper);
    	cardMemberHelper=new CardMemberHelper(form,request,response);
    	AcquisitionResponse acqResponce = new AcquisitionResponse();
    	acqResponce.setPreApprovedStatus("true");
		cardMemberHelper.isInValidUserResonse(acqResponce);
    	
    }
    
    @Test
    public void testIsInValidUserResonse3(){
    	cardMemberAppDTO = new CardMemberAppDTO();
    	cardMemberAppDTO.setFlowType("shortpa");
    	cardMemberAppDTO.setPublicGuid("1234567894");
    	List<CardData> cardDataList = new ArrayList<CardData>();
    	CardData cardData = new CardData();
    	cardData.setAcctNumber("123456");
		cardDataList.add(cardData );
		cardMemberAppDTO.setCardDataList(null);
	//	Claim list = (Claim) new ArrayList();
		SecurityToken securityToken = null;//new SecurityToken("111","111","111","111","","111");
		
    	request =EasyMock.createNiceMock(HttpServletRequest.class);
    	response =EasyMock.createNiceMock(HttpServletResponse.class);
    	session = EasyMock.createNiceMock(HttpSession.class);
    	//securityToken =EasyMock.createNiceMock(SecurityToken.class);
    	fepRequestMapper = EasyMock.createNiceMock(FEPRequestMapper.class);
    	expect(request.getSession()).andReturn(session);
    	cardMemberAppDTO.setSecurityToken(securityToken);
    	expect((CardMemberAppDTO)request.getAttribute(OPENConstants.CARDMEMBERAPP_DTO)).andReturn(cardMemberAppDTO);
    	expect(new FEPRequestMapper()).andReturn(fepRequestMapper);
    	OPENCommonParam openCommonParam = new OPENCommonParam();
		expect(request.getAttribute(OPENConstants.OPEN_COMMON_PARAM_OBJECT)).andReturn(openCommonParam );
		replay(request);
		replay(fepRequestMapper);
    	cardMemberHelper=new CardMemberHelper(form,request,response);
    	AcquisitionResponse acqResponce = new AcquisitionResponse();
    	acqResponce.setPreApprovedStatus("true");
		cardMemberHelper.isInValidUserResonse(acqResponce);
    	
    }
    
    @Test
    public void testIsInValidUserResonse4(){
    	cardMemberAppDTO = new CardMemberAppDTO();
    	cardMemberAppDTO.setFlowType("shortpa1i");
    	cardMemberAppDTO.setPublicGuid("1234567894");
    	List<CardData> cardDataList = new ArrayList<CardData>();
    	CardData cardData = new CardData();
    	cardData.setAcctNumber("123456");
		cardDataList.add(cardData );
		cardMemberAppDTO.setCardDataList(cardDataList);
	//	Claim list = (Claim) new ArrayList();
		SecurityToken securityToken = null;//new SecurityToken("111","111","111","111","","111");
		
    	request =EasyMock.createNiceMock(HttpServletRequest.class);
    	response =EasyMock.createNiceMock(HttpServletResponse.class);
    	session = EasyMock.createNiceMock(HttpSession.class);
    	//securityToken =EasyMock.createNiceMock(SecurityToken.class);
    	fepRequestMapper = EasyMock.createNiceMock(FEPRequestMapper.class);
    	expect(request.getSession()).andReturn(session);
    	cardMemberAppDTO.setSecurityToken(securityToken);
    	expect((CardMemberAppDTO)request.getAttribute(OPENConstants.CARDMEMBERAPP_DTO)).andReturn(cardMemberAppDTO);
    	expect(new FEPRequestMapper()).andReturn(fepRequestMapper);
    	OPENCommonParam openCommonParam = new OPENCommonParam();
		expect(request.getAttribute(OPENConstants.OPEN_COMMON_PARAM_OBJECT)).andReturn(openCommonParam );
		replay(request);
		replay(fepRequestMapper);
    	cardMemberHelper=new CardMemberHelper(form,request,response);
    	AcquisitionResponse acqResponce = new AcquisitionResponse();
    	acqResponce.setPreApprovedStatus("true");
		cardMemberHelper.isInValidUserResonse(acqResponce);
    	
    }
    
    @Test
    public void testIsInValidUserResonse5(){
    	cardMemberAppDTO = new CardMemberAppDTO();
    	cardMemberAppDTO.setFlowType("shortpa");
    	cardMemberAppDTO.setPublicGuid("1234567894");
    	List<CardData> cardDataList = new ArrayList<CardData>();
    	CardData cardData = new CardData();
    	cardData.setAcctNumber("123456");
		cardDataList.add(cardData );
		cardMemberAppDTO.setCardDataList(cardDataList);
	//	Claim list = (Claim) new ArrayList();
		SecurityToken securityToken = null;//new SecurityToken("111","111","111","111","","111");
		
    	request =EasyMock.createNiceMock(HttpServletRequest.class);
    	response =EasyMock.createNiceMock(HttpServletResponse.class);
    	session = EasyMock.createNiceMock(HttpSession.class);
    	//securityToken =EasyMock.createNiceMock(SecurityToken.class);
    	fepRequestMapper = EasyMock.createNiceMock(FEPRequestMapper.class);
    	expect(request.getSession()).andReturn(session);
    	cardMemberAppDTO.setSecurityToken(securityToken);
    	expect((CardMemberAppDTO)request.getAttribute(OPENConstants.CARDMEMBERAPP_DTO)).andReturn(cardMemberAppDTO);
    	expect(new FEPRequestMapper()).andReturn(fepRequestMapper);
    	OPENCommonParam openCommonParam = new OPENCommonParam();
		expect(request.getAttribute(OPENConstants.OPEN_COMMON_PARAM_OBJECT)).andReturn(openCommonParam );
		replay(request);
		replay(fepRequestMapper);
    	cardMemberHelper=new CardMemberHelper(form,request,response);
    	AcquisitionResponse acqResponce = new AcquisitionResponse();
    	acqResponce.setPreApprovedStatus("false");
		cardMemberHelper.isInValidUserResonse(acqResponce);
    	
    }
    
    @Test
    public void testIsInValidUserResonse6(){
    	cardMemberAppDTO = new CardMemberAppDTO();
    	cardMemberAppDTO.setFlowType("shortpa");
    	cardMemberAppDTO.setPublicGuid("1234567894");
    	List<CardData> cardDataList = new ArrayList<CardData>();
    	CardData cardData = new CardData();
    	cardData.setAcctNumber("123456");
		cardDataList.add(cardData );
		cardMemberAppDTO.setCardDataList(cardDataList);
	//	Claim list = (Claim) new ArrayList();
		SecurityToken securityToken = null;//new SecurityToken("111","111","111","111","","111");
		
    	request =EasyMock.createNiceMock(HttpServletRequest.class);
    	response =EasyMock.createNiceMock(HttpServletResponse.class);
    	session = EasyMock.createNiceMock(HttpSession.class);
    	//securityToken =EasyMock.createNiceMock(SecurityToken.class);
    	fepRequestMapper = EasyMock.createNiceMock(FEPRequestMapper.class);
    	expect(request.getSession()).andReturn(session);
    	cardMemberAppDTO.setSecurityToken(securityToken);
    	expect((CardMemberAppDTO)request.getAttribute(OPENConstants.CARDMEMBERAPP_DTO)).andReturn(cardMemberAppDTO);
    	expect(new FEPRequestMapper()).andReturn(fepRequestMapper);
    	OPENCommonParam openCommonParam = new OPENCommonParam();
		expect(request.getAttribute(OPENConstants.OPEN_COMMON_PARAM_OBJECT)).andReturn(openCommonParam );
		replay(request);
		replay(fepRequestMapper);
    	cardMemberHelper=new CardMemberHelper(form,request,response);
    	AcquisitionResponse acqResponce = new AcquisitionResponse();
    	acqResponce.setPreApprovedStatus("null");
		cardMemberHelper.isInValidUserResonse(acqResponce);
    	
    }
    
    @Test(expected=NullPointerException.class)
    public void testIsAlreadyLoggedin(){
    	Map<String, Object> urlParams = null;
    	urlParams.put("", commonParam);
		commonParam.setUrlParams(urlParams);
    	cardMemberAppDTO = new CardMemberAppDTO();
    	cardMemberAppDTO.setFlowType("shortpa");
    	request =EasyMock.createNiceMock(HttpServletRequest.class);
    	response =EasyMock.createNiceMock(HttpServletResponse.class);
    	session = EasyMock.createNiceMock(HttpSession.class);
    	fepRequestMapper = EasyMock.createNiceMock(FEPRequestMapper.class);
    	expect(request.getSession()).andReturn(session);
    	expect((CardMemberAppDTO)request.getAttribute(OPENConstants.CARDMEMBERAPP_DTO)).andReturn(cardMemberAppDTO);
    	expect(request.getHeader("cookie")).andReturn(null);
    	OPENCommonParam openCommonParam = new OPENCommonParam();
		expect(request.getAttribute(OPENConstants.OPEN_COMMON_PARAM_OBJECT)).andReturn(openCommonParam );
		replay(request);
		replay(fepRequestMapper);
    	cardMemberHelper=new CardMemberHelper(form,request,response);
    	cardMemberHelper.isAlreadyLoggedin();
    }
    

    @Test
    public void testGetSecurityToken(){
    	/*Map<String, Object> urlParams = null;
    	urlParams.put("", commonParam)
		commonParam.setUrlParams(urlParams);*/
    	cardMemberAppDTO = new CardMemberAppDTO();
    	cardMemberAppDTO.setFlowType("shortpa");
    	request =EasyMock.createNiceMock(HttpServletRequest.class);
    	response =EasyMock.createNiceMock(HttpServletResponse.class);
    	session = EasyMock.createNiceMock(HttpSession.class);
    	fepRequestMapper = EasyMock.createNiceMock(FEPRequestMapper.class);
    	expect(request.getSession()).andReturn(session);
    	expect((CardMemberAppDTO)request.getAttribute(OPENConstants.CARDMEMBERAPP_DTO)).andReturn(cardMemberAppDTO);
    	expect(request.getHeader("cookie")).andReturn(null);
    	OPENCommonParam openCommonParam = new OPENCommonParam();
		expect(request.getAttribute(OPENConstants.OPEN_COMMON_PARAM_OBJECT)).andReturn(openCommonParam );
		replay(request);
		replay(fepRequestMapper);
    	cardMemberHelper=new CardMemberHelper(form,request,response);
    	cardMemberHelper.getSecurityToken("");
    }
    @Test
    public void testGetSecurityToken1(){
    	/*Map<String, Object> urlParams = null;
    	urlParams.put("", commonParam)
		commonParam.setUrlParams(urlParams);*/
    	cardMemberAppDTO = new CardMemberAppDTO();
    	cardMemberAppDTO.setFlowType("shortpa");
    	request =EasyMock.createNiceMock(HttpServletRequest.class);
    	response =EasyMock.createNiceMock(HttpServletResponse.class);
    	session = EasyMock.createNiceMock(HttpSession.class);
    	fepRequestMapper = EasyMock.createNiceMock(FEPRequestMapper.class);
    	expect(request.getSession()).andReturn(session);
    	expect((CardMemberAppDTO)request.getAttribute(OPENConstants.CARDMEMBERAPP_DTO)).andReturn(cardMemberAppDTO);
    	expect(request.getHeader("cookie")).andReturn(null);
    	OPENCommonParam openCommonParam = new OPENCommonParam();
		expect(request.getAttribute(OPENConstants.OPEN_COMMON_PARAM_OBJECT)).andReturn(openCommonParam );
		replay(request);
		replay(fepRequestMapper);
    	cardMemberHelper=new CardMemberHelper(form,request,response);
    	cardMemberHelper.getSecurityToken("1234567891");
    }
	/*	
	@Test
	public void testisAlreadyLoggedinFailure(){		
			request =EasyMock.createNiceMock(HttpServletRequest.class);		
			response =EasyMock.createNiceMock(HttpServletResponse.class);							
			session = EasyMock.createNiceMock(HttpSession.class);
			eoicookie = EasyMock.createNiceMock(EOICookie.class);
			expect(request.getSession()).andReturn(session);
			replay(request);
			cardMemberHelper=new CardMemberHelper(form, request, response);
			assertFalse(cardMemberHelper.isAlreadyLoggedin());
			verify(request);					
   }
	
	@Test
	public void testIsAlreadyLoggedinSuccess(){		
		request =EasyMock.createNiceMock(HttpServletRequest.class);		
		response =EasyMock.createNiceMock(HttpServletResponse.class);							
		session = EasyMock.createNiceMock(HttpSession.class);
		eoicookie = EasyMock.createNiceMock(EOICookie.class);
		expect(request.getSession()).andReturn(session);
		replay(request);		
		cardMemberHelper=new CardMemberHelper(form, request, response);		
		setBlueBoxCookies();		
		assertFalse(cardMemberHelper.isAlreadyLoggedin());		
   }
		
	private void setBlueBoxCookies() 
	{		
		String sessionid = "0DEFC54864E651F1A92E5A7B4B77107D";		
		String eoiCookieName="blueboxvalues";
		cookie=new Cookie(eoiCookieName, sessionid);
		cookie.setDomain(".aexp.com");
		cookie.setPath("/");
		cookie.setSecure(true);
		cookie.setMaxAge(300);
		response.addCookie(cookie);
		eoicookie.setCookie(sessionid, response);			
	}*/
	
	/*@Test
	public void testgetCookiedFEPLoginResponse(){
		redesignAppForm =new RedesignOSBNForm();
		request =EasyMock.createNiceMock(HttpServletRequest.class);
		response =EasyMock.createNiceMock(HttpServletResponse.class);
		form=EasyMock.createNiceMock(ActionForm.class);
		session = EasyMock.createNiceMock(HttpSession.class);
		expect(request.getSession()).andReturn(session);
		replay(request);
        cardMemberAppDTO=new CardMemberAppDTO();
        cardMemberAppDTO.setFlowType("shorpa");
        cardMemberAppDTO.setStableAndSingleCard(true);
        PricingFeature pricingFeature=new PricingFeature();
        pricingFeature.setBasicFeeCode("3");
        Status status=new Status();
        status.setStatusCode("00");
        Reason reason=new Reason();
        reason.setReasonCode(1013);
        reason.setReasonMsg("ReasonMessage");
        List<Reason> errorList = new ArrayList<Reason>();
        errorList.add(reason);
        status.setErrorList(errorList);
        acquisitionResponse =new AcquisitionResponse();
        acquisitionResponse.setAcquisitionStatus(status);
        acquisitionResponse.setPricingFeature(pricingFeature);               
        cardMemberHelper=new CardMemberHelper(form, request, response);	
        assertNull(cardMemberHelper.getCookiedFEPLoginResponse(redesignAppForm));
        verify(request);
	   }*/
	
	
	
	/*@Test
	public void testgetFEPLoginResponse(){
		cardMemberAppDTO= new CardMemberAppDTO();
		cardMemberAppDTO.setFlowType("shortpa");
		RedesignOSBNForm redesignAppForm=new RedesignOSBNForm();
		AcquisitionRequest acquisitionRequest = new AcquisitionRequest();
		FEPRequestMapper fepRequestMapper = new FEPRequestMapper();
		AcquisitionResponse acquisitionResponse =new AcquisitionResponse();
		PricingFeature pricingFeature=new PricingFeature();
		pricingFeature.setBasicFeeCode("3");
		pricingFeature.setChargeIndicator("12345");
		acquisitionResponse.setPricingFeature(pricingFeature);
		CardMemberFepResponseMapper cardMemberFepResponseMapper=new CardMemberFepResponseMapper(acquisitionResponse);												
		assertNotNull(cardMemberHelper.getFEPLoginResponse(redesignAppForm));		    
	}*/

}