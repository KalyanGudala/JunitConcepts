/*
 * -------------------------------------------------------------------------
 *
 * (C) Copyright / American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.
 *
 * -------------------------------------------------------------------------
 */

package com.americanexpress.acquisitions.open.web.Test;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.americanexpress.acquisitions.open.commons.common.constants.Constants;
import com.americanexpress.acquisitions.open.commons.common.constants.OPENConstants;
import com.americanexpress.acquisitions.open.commons.formbeans.RedesignOSBNForm;
import com.americanexpress.acquisitions.open.commons.mapper.FEPRequestMapper;
import com.americanexpress.acquisitions.open.web.beans.CardMemberAppDTO;
import com.americanexpress.acquisitions.open.web.managers.CardMemberFepResponseMapper;
import com.americanexpress.acquisitions.open.web.managers.CardMemberLoginHelper;
import com.americanexpress.acquisitions.open.web.managers.DTWManager;
import com.americanexpress.acquisitions.services.ccc.domain.AcquisitionRequest;
import com.americanexpress.acquisitions.services.ccc.domain.AcquisitionResponse;
import com.americanexpress.acquisitions.services.ccc.domain.CardData;
import com.americanexpress.acquisitions.services.ccc.domain.Reason;
import com.americanexpress.acquisitions.services.ccc.domain.SecurityData;
import com.americanexpress.acquisitions.services.ccc.domain.Status;
import com.americanexpress.wss.shr.authorization.token.SecurityToken;

import org.apache.struts.action.ActionForm;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.replay;
import static org.easymock.EasyMock.verify;
/**
 * CardMemberLoginHelperTest
 *
 * @author 387142
 * @version $Id$
 */
public class CardMemberLoginHelperTest {
	
	RedesignOSBNForm redesignOSBNForm;
	CardMemberLoginHelper cardMemberLoginHelper;
	ActionForm form;
	HttpServletRequest request;
	HttpServletResponse response;
	HttpSession session=null;
	AcquisitionResponse acquisitionResponse;	
	CardMemberAppDTO cardMemberAppDTO;
	Status acquisitionStatus;
	String mainFlow;
	String subFlow;
	String businessUnit;
	CardMemberFepResponseMapper cardMemberFepResponseMapper;
	List<Reason> errorList = new ArrayList<Reason>();
	SecurityToken securityToken=null;	
	List<CardData> cardList=new ArrayList<CardData>();
	AcquisitionRequest acquisitionRequest;
	Cookie cookie;
	FEPRequestMapper fepRequestMapper;	
	@Test
	public void testgetCardMemberAppDTO(){
		form=EasyMock.createNiceMock(ActionForm.class);		
		request=EasyMock.createNiceMock(HttpServletRequest.class);
		response=EasyMock.createNiceMock(HttpServletResponse.class);		
		cardMemberLoginHelper=new CardMemberLoginHelper(form,request,response);
		assertNull(cardMemberLoginHelper.getCardMemberAppDTO());		
	}
	
	
	/*@Test
	public void testvalidateUserLoginInfo(){		
		form=EasyMock.createNiceMock(ActionForm.class);		
		request=EasyMock.createNiceMock(HttpServletRequest.class);
		response=EasyMock.createNiceMock(HttpServletResponse.class);
		session=EasyMock.createNiceMock(HttpSession.class);
		session.setAttribute(OPENConstants.CARDMEMBERAPP_DTO, "true");						
		expect(request.getSession(false)).andReturn(session);		
		replay(request);		
		mainFlow = OPENConstants.FLOW_TYPE_SHORT_NPA;
        subFlow = OPENConstants.SUB_FLOW_CARDSELECTORPAGE;
		cardMemberLoginHelper=new CardMemberLoginHelper(form,request,response);
		acquisitionStatus=new Status();		
		acquisitionStatus.setStatusCode("00");		
		acquisitionResponse=new AcquisitionResponse();
		acquisitionResponse.setAcquisitionStatus(acquisitionStatus);
		cardMemberAppDTO=new CardMemberAppDTO();
		cardMemberAppDTO.setFlowType("shortnpa");			
		cardMemberAppDTO.setPublicGuid("369");
		cardMemberAppDTO.setStableAndSingleCard(true);
		cardMemberAppDTO.setCardType("businessCard");
		//session.setAttribute(OPENConstants.SHORTNPA_OPTION,cardMemberAppDTO);
		redesignOSBNForm=new RedesignOSBNForm();
		redesignOSBNForm.setFirstName("Joe");
		redesignOSBNForm.setLastName("Smith");		
        businessUnit=Constants.OPEN_APP;
        //cardMemberFepResponseMapper = new CardMemberFepResponseMapper(acquisitionResponse);       
		if(cardMemberLoginHelper!=null){
		assertNull(cardMemberLoginHelper.validateUserLoginInfo(redesignOSBNForm));
		}				
		verify(request);
	}*/
	
	
	@Test
	public void testvalidateUserLoginInfo(){		
		form=EasyMock.createNiceMock(ActionForm.class);		
		request=EasyMock.createNiceMock(HttpServletRequest.class);
		//replay(request);
		response=EasyMock.createNiceMock(HttpServletResponse.class);
		cardMemberAppDTO=new CardMemberAppDTO();
		cardMemberAppDTO.setAppId("appid");
		cardMemberAppDTO.setFlowType("shortnpa");			
		cardMemberAppDTO.setPublicGuid("369");
		cardMemberAppDTO.setStableAndSingleCard(true);
		cardMemberAppDTO.setCardType("businessCard");		
		session=EasyMock.createNiceMock(HttpSession.class);
		cookie=EasyMock.createNiceMock(Cookie.class);
		expect(request.getSession(false)).andReturn(session);
		expect(session.getAttribute(OPENConstants.CARDMEMBERAPP_DTO)).andReturn(cardMemberAppDTO);
		expect(request.getAttribute(OPENConstants.APP_ID)).andReturn("1234");
		expect(request.getCookies()).andReturn(null);
		replay(request);
		replay(session);
		replay(cookie);
		mainFlow = OPENConstants.FLOW_TYPE_SHORT_NPA;
        subFlow = OPENConstants.SUB_FLOW_CARDSELECTORPAGE;
        businessUnit=Constants.OPEN_APP;
		cardMemberLoginHelper=new CardMemberLoginHelper(form,request,response);
		//String appId = (String) request.getSession().getAttribute(OPENConstants.APP_ID);
		acquisitionStatus=new Status();		
		acquisitionStatus.setStatusCode("00");									
		acquisitionRequest=EasyMock.createNiceMock(AcquisitionRequest.class);		
		expect(acquisitionRequest.getApplicationExperienceKey()).andReturn("RWDCM");		
		replay(acquisitionRequest);		
		acquisitionResponse=new AcquisitionResponse();		
		acquisitionResponse.setAcquisitionStatus(acquisitionStatus);
		acquisitionResponse.setInvalidShortFlowUser(true);
		redesignOSBNForm=new RedesignOSBNForm();
		redesignOSBNForm.setuserid("RJS");
		redesignOSBNForm.setpassword("SJR");
		redesignOSBNForm.setPublicGuid("123456");
		redesignOSBNForm.setFirstName("HJJJ");
		redesignOSBNForm.setLastName("JJJ");
		redesignOSBNForm.setSecurityToken(securityToken);
		
		fepRequestMapper=EasyMock.createNiceMock(FEPRequestMapper.class);		
		expect(fepRequestMapper.buildShortAppFepRequestBean(request, response, redesignOSBNForm, businessUnit, mainFlow, subFlow)).andReturn(acquisitionRequest);		
		replay(fepRequestMapper);		
		//acquisitionResponse=fepRequestMapper.fepResponseBuilder(acquisitionRequest);				
		
		assertNull(cardMemberLoginHelper.validateUserLoginInfo(redesignOSBNForm));					
		verify(session);
		//verify(fepRequestMapper);
		//verify(request);				
	}

	@Test(expected=NullPointerException.class)
	public void testisInValidUserResponse()
	{
		form=EasyMock.createNiceMock(ActionForm.class);		
		request=EasyMock.createNiceMock(HttpServletRequest.class);
		response=EasyMock.createNiceMock(HttpServletResponse.class);
		session=EasyMock.createNiceMock(HttpSession.class);
		expect(request.getSession(false)).andReturn(session);		
		replay(request);
		replay(session);
		acquisitionResponse=new AcquisitionResponse();		
		acquisitionResponse.setPreApprovedStatus("false");
		cardMemberAppDTO=new CardMemberAppDTO();								
		cardMemberAppDTO.setPublicGuid(null);
		cardMemberAppDTO.setSecurityToken(securityToken);
		cardMemberAppDTO.setSortedIndex("-1");
		cardMemberAppDTO.setFlowType("shortpa");
		cardList.add(null);
		cardMemberAppDTO.setCardDataList(cardList);		
		cardMemberLoginHelper=new CardMemberLoginHelper(form,request,response);		
		assertTrue(cardMemberLoginHelper.isInValidUserResponse(acquisitionResponse));
		verify(request);
	}
	
	@Test
	public void testisInvalidAcquisitionResponse()
	{
		form=EasyMock.createNiceMock(ActionForm.class);		
		request=EasyMock.createNiceMock(HttpServletRequest.class);
		response=EasyMock.createNiceMock(HttpServletResponse.class);
		session=EasyMock.createNiceMock(HttpSession.class);
		expect(request.getSession(false)).andReturn(session);		
		replay(request);
		cardMemberLoginHelper=new CardMemberLoginHelper(form,request,response);
		acquisitionResponse=new AcquisitionResponse();		
		Reason reason=new Reason();
		reason.setReasonCode(2641);
		reason.setReasonMsg("reasonmessage");
		errorList.add(reason);
		acquisitionStatus=new Status();	
		acquisitionStatus.setStatusCode("00");
		acquisitionResponse.setAcquisitionStatus(acquisitionStatus);
		acquisitionStatus.setErrorList(errorList);
		assertTrue(cardMemberLoginHelper.isInvalidAcquisitionResponse(acquisitionResponse));
	}
	
	@Test
	public void testisInvalidAcquisitionResponse1()
	{
		form=EasyMock.createNiceMock(ActionForm.class);		
		request=EasyMock.createNiceMock(HttpServletRequest.class);
		response=EasyMock.createNiceMock(HttpServletResponse.class);
		session=EasyMock.createNiceMock(HttpSession.class);
		expect(request.getSession(false)).andReturn(session);		
		replay(request);
		cardMemberLoginHelper=new CardMemberLoginHelper(form,request,response);
		acquisitionResponse=new AcquisitionResponse();		
		Reason reason=new Reason();
		reason.setReasonCode(2642);
		reason.setReasonMsg("reasonmessage");
		errorList.add(reason);
		acquisitionStatus=new Status();	
		acquisitionStatus.setStatusCode("00");
		acquisitionResponse.setAcquisitionStatus(acquisitionStatus);
		acquisitionStatus.setErrorList(errorList);
		assertTrue(cardMemberLoginHelper.isInvalidAcquisitionResponse(acquisitionResponse));
	}
	
	@Test
	public void testisInvalidAcquisitionResponse2()
	{
		form=EasyMock.createNiceMock(ActionForm.class);		
		request=EasyMock.createNiceMock(HttpServletRequest.class);
		response=EasyMock.createNiceMock(HttpServletResponse.class);
		session=EasyMock.createNiceMock(HttpSession.class);
		expect(request.getSession(false)).andReturn(session);		
		replay(request);
		cardMemberLoginHelper=new CardMemberLoginHelper(form,request,response);
		acquisitionResponse=new AcquisitionResponse();		
		Reason reason=new Reason();
		reason.setReasonCode(2643);
		reason.setReasonMsg("reasonmessage");
		errorList.add(reason);
		acquisitionStatus=new Status();	
		acquisitionStatus.setStatusCode("00");
		acquisitionResponse.setAcquisitionStatus(acquisitionStatus);
		acquisitionStatus.setErrorList(errorList);
		assertTrue(cardMemberLoginHelper.isInvalidAcquisitionResponse(acquisitionResponse));
	}
	
	@Test
	public void testisInvalidAcquisitionResponse3()
	{
		form=EasyMock.createNiceMock(ActionForm.class);		
		request=EasyMock.createNiceMock(HttpServletRequest.class);
		response=EasyMock.createNiceMock(HttpServletResponse.class);
		session=EasyMock.createNiceMock(HttpSession.class);
		expect(request.getSession(false)).andReturn(session);		
		replay(request);
		cardMemberLoginHelper=new CardMemberLoginHelper(form,request,response);
		acquisitionResponse=new AcquisitionResponse();		
		Reason reason=new Reason();
		reason.setReasonCode(18);
		reason.setReasonMsg("reasonmessage");
		errorList.add(reason);
		acquisitionStatus=new Status();	
		acquisitionStatus.setStatusCode("00");
		acquisitionResponse.setAcquisitionStatus(acquisitionStatus);
		acquisitionStatus.setErrorList(errorList);
		assertTrue(cardMemberLoginHelper.isInvalidAcquisitionResponse(acquisitionResponse));
	}
	
	@Test
	public void testisInvalidAcquisitionResponse4()
	{
		form=EasyMock.createNiceMock(ActionForm.class);		
		request=EasyMock.createNiceMock(HttpServletRequest.class);
		response=EasyMock.createNiceMock(HttpServletResponse.class);
		session=EasyMock.createNiceMock(HttpSession.class);
		expect(request.getSession(false)).andReturn(session);		
		replay(request);
		cardMemberLoginHelper=new CardMemberLoginHelper(form,request,response);
		acquisitionResponse=new AcquisitionResponse();		
		Reason reason=new Reason();
		reason.setReasonCode(16);
		reason.setReasonMsg("reasonmessage");
		errorList.add(reason);
		acquisitionStatus=new Status();	
		acquisitionStatus.setStatusCode("00");
		acquisitionResponse.setAcquisitionStatus(acquisitionStatus);
		acquisitionStatus.setErrorList(errorList);
		assertTrue(cardMemberLoginHelper.isInvalidAcquisitionResponse(acquisitionResponse));
	}
	
	@Test
	public void testisInvalidAcquisitionResponse5()
	{
		form=EasyMock.createNiceMock(ActionForm.class);		
		request=EasyMock.createNiceMock(HttpServletRequest.class);
		response=EasyMock.createNiceMock(HttpServletResponse.class);
		session=EasyMock.createNiceMock(HttpSession.class);
		expect(request.getSession(false)).andReturn(session);		
		replay(request);
		cardMemberLoginHelper=new CardMemberLoginHelper(form,request,response);
		acquisitionResponse=new AcquisitionResponse();		
		Reason reason=new Reason();
		reason.setReasonCode(19);
		reason.setReasonMsg("reasonmessage");
		errorList.add(reason);
		acquisitionStatus=new Status();	
		acquisitionStatus.setStatusCode("00");
		acquisitionResponse.setAcquisitionStatus(acquisitionStatus);
		acquisitionStatus.setErrorList(errorList);
		assertTrue(cardMemberLoginHelper.isInvalidAcquisitionResponse(acquisitionResponse));
	}
	
	@Test
	public void testisInvalidAcquisitionResponse6()
	{
		form=EasyMock.createNiceMock(ActionForm.class);		
		request=EasyMock.createNiceMock(HttpServletRequest.class);
		response=EasyMock.createNiceMock(HttpServletResponse.class);
		session=EasyMock.createNiceMock(HttpSession.class);
		expect(request.getSession(false)).andReturn(session);		
		replay(request);
		cardMemberLoginHelper=new CardMemberLoginHelper(form,request,response);
		acquisitionResponse=new AcquisitionResponse();		
		Reason reason=new Reason();
		reason.setReasonCode(21);
		reason.setReasonMsg("reasonmessage");
		errorList.add(reason);
		acquisitionStatus=new Status();	
		acquisitionStatus.setStatusCode("00");
		acquisitionResponse.setAcquisitionStatus(acquisitionStatus);
		acquisitionStatus.setErrorList(errorList);
		assertTrue(cardMemberLoginHelper.isInvalidAcquisitionResponse(acquisitionResponse));
	}
	
	@Test
	public void testisInvalidAcquisitionResponse7()
	{
		form=EasyMock.createNiceMock(ActionForm.class);		
		request=EasyMock.createNiceMock(HttpServletRequest.class);
		response=EasyMock.createNiceMock(HttpServletResponse.class);
		session=EasyMock.createNiceMock(HttpSession.class);
		expect(request.getSession(false)).andReturn(session);		
		replay(request);
		cardMemberLoginHelper=new CardMemberLoginHelper(form,request,response);
		acquisitionResponse=new AcquisitionResponse();				
		assertTrue(cardMemberLoginHelper.isInvalidAcquisitionResponse(acquisitionResponse));
	}
	
	
  @Test(expected=NullPointerException.class)
	public void testsetBlueBoxCookies()
	{
		form=EasyMock.createNiceMock(ActionForm.class);		
		request=EasyMock.createNiceMock(HttpServletRequest.class);
		response=EasyMock.createNiceMock(HttpServletResponse.class);
		session=EasyMock.createNiceMock(HttpSession.class);
		expect(request.getSession()).andReturn(session);		
		replay(request);		
		cardMemberAppDTO=new CardMemberAppDTO();				
	    cardMemberAppDTO.setSecurityToken(securityToken);		
		cardMemberAppDTO.setPublicGuid("123456");		
		//String sessionid="0DEFC54864E651F1A92E5A7B4B77107D";
		cardMemberLoginHelper=new CardMemberLoginHelper(form,request,response);
		cardMemberLoginHelper.setBlueBoxCookies();
		verify(request);
	}		
}
