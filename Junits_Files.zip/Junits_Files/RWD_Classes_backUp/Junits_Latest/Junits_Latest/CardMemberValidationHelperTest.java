/*
 * -------------------------------------------------------------------------
 *
 * (C) Copyright / American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.
 *
 * -------------------------------------------------------------------------
 */

package com.americanexpress.acquisitions.open.web.Test;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.americanexpress.acquisitions.open.commons.common.constants.OPENConstants;
import com.americanexpress.acquisitions.open.commons.formbeans.RedesignOSBNForm;
import com.americanexpress.acquisitions.open.web.beans.CardMemberAppDTO;
import com.americanexpress.acquisitions.open.web.managers.CardMemberValidationHelper;

import org.apache.struts.action.ActionForm;
import org.easymock.EasyMock;
import org.junit.Test;
import static org.easymock.EasyMock.replay;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.verify;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
/**
 * CardMemberValidationHelperTest
 *
 * @author 387142
 * @version $Id$
 */
public class CardMemberValidationHelperTest {
	  HttpServletRequest request;
	  HttpServletResponse response;
	  ActionForm form;
	  CardMemberValidationHelper cardMemberValidationHelper;
	  RedesignOSBNForm redesignOSBNForm;
	  CardMemberAppDTO cardMemberAppDTO;
	  HttpSession session;
	  @Test
		 public void testvalidateUserCardInfo(){
		 redesignOSBNForm=new RedesignOSBNForm();		 		 
		 request =EasyMock.createNiceMock(HttpServletRequest.class);	
		 response =EasyMock.createNiceMock(HttpServletResponse.class);
		 form=EasyMock.createNiceMock(ActionForm.class);
		 session = EasyMock.createNiceMock(HttpSession.class);
		 cardMemberAppDTO=new CardMemberAppDTO();
		 cardMemberAppDTO.setFlowType("shortnpa");		 
		 cardMemberAppDTO.setCardType("smallBusinessCard");
		 cardMemberAppDTO.setPublicGuid("1234");
		 cardMemberAppDTO.setStableId("Y");		
		 //session.setAttribute(OPENConstants.CARDMEMBERAPP_DTO,cardMemberAppDTO);
		 expect(request.getSession(false)).andReturn(session);		 
		 replay(request);
		 redesignOSBNForm.setPublicGuid("1234");
		 cardMemberValidationHelper=new CardMemberValidationHelper(form,request,response);
		 if(cardMemberValidationHelper!=null){
		 assertNull(cardMemberValidationHelper.validateUserCardInfo(redesignOSBNForm));		 
		 }		
		 verify(request);		 
	  }
}
