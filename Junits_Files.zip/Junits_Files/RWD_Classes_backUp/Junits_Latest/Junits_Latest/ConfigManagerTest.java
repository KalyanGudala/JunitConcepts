/*
 * -------------------------------------------------------------------------
 *
 * (C) Copyright / American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.
 *
 * -------------------------------------------------------------------------
 */

package com.americanexpress.acquisitions.open.web.Test;

import com.americanexpress.acquisitions.open.web.managers.ConfigManager;

import org.junit.Test;


/**
 * ConfigManagerTest
 *
 * @author 387142
 * @version $Id$
 */
public class ConfigManagerTest {

	
	@Test
	public void testgetPropertiesValue(){
		ConfigManager.getPropertiesValue("jConfigName", "jconfig", "SBS");
	
		
	}
	
}
