/*
 * -------------------------------------------------------------------------
 *
 * (C) Copyright / American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.
 *
 * -------------------------------------------------------------------------
 */

package com.americanexpress.acquisitions.open.web.Test;

import static org.junit.Assert.assertNotNull;

import java.util.Hashtable;

import com.americanexpress.acquisitions.open.commons.formbeans.RedesignOSBNForm;
import com.americanexpress.acquisitions.open.web.managers.CustomerFileVSFormBean;

import org.junit.Test;

/**
 * CustomerFileVSFormBeanTest
 *
 * @author 387142
 * @version $Id$
 */
public class CustomerFileVSFormBeanTest {
	RedesignOSBNForm redesignOSBNForm;
	CustomerFileVSFormBean customerFileVSFormBean;
	
	@Test
	 public void testcustomerFileToRedesignAppForm(){
		redesignOSBNForm=new RedesignOSBNForm();
		Hashtable customerFileHash=new Hashtable();
		customerFileHash.put("phone", "123-456-7890");
		customerFileHash.put("socialShort","123-456-7890");
		customerFileHash.put("businessPhone","123-456-7890");
		customerFileHash.put("date","12/12/2013");
		boolean isPreapproved=true;
		boolean isValueBlank=true;		
		customerFileVSFormBean=new CustomerFileVSFormBean();
		assertNotNull(customerFileVSFormBean.customerFileToRedesignAppForm(redesignOSBNForm,customerFileHash,isPreapproved,isValueBlank));
	}
	
	@Test
	 public void testcustomerFileToRedesignAppForm1(){
		redesignOSBNForm=new RedesignOSBNForm();
		Hashtable customerFileHash=new Hashtable();
		customerFileHash.put("phone", "###");
		customerFileHash.put("socialShort","###");
		customerFileHash.put("businessPhone","###");
		customerFileHash.put("date","###");
		boolean isPreapproved=false;
		boolean isValueBlank=true;		
		customerFileVSFormBean=new CustomerFileVSFormBean();
		assertNotNull(customerFileVSFormBean.customerFileToRedesignAppForm(redesignOSBNForm,customerFileHash,isPreapproved,isValueBlank));
	}
	
	@Test
	 public void testcustomerFileToRedesignAppForm2(){
		redesignOSBNForm=new RedesignOSBNForm();
		Hashtable customerFileHash=new Hashtable();
		customerFileHash.put("phone","");
		customerFileHash.put("socialShort","");
		customerFileHash.put("businessPhone","");
		customerFileHash.put("date","");
		boolean isPreapproved=false;
		boolean isValueBlank=true;		
		customerFileVSFormBean=new CustomerFileVSFormBean();
		assertNotNull(customerFileVSFormBean.customerFileToRedesignAppForm(redesignOSBNForm,customerFileHash,isPreapproved,isValueBlank));
	}
	
	@Test
	 public void testcustomerFileToRedesignAppForm3(){
		redesignOSBNForm=new RedesignOSBNForm();
		Hashtable customerFileHash=new Hashtable();
		customerFileHash.put("phone", "123-456-7890");
		customerFileHash.put("socialShort","123-456-7890");
		customerFileHash.put("businessPhone","123-456-7890");
		customerFileHash.put("date","12/12/2013");
		boolean isPreapproved=false;
		boolean isValueBlank=true;
		String value="123-456-7890";		
		customerFileVSFormBean=new CustomerFileVSFormBean();
		assertNotNull(customerFileVSFormBean.customerFileToRedesignAppForm(redesignOSBNForm,customerFileHash,isPreapproved,isValueBlank));
	}
	
	@Test
	 public void testcustomerFileToRedesignAppForm4(){
		redesignOSBNForm=new RedesignOSBNForm();
		Hashtable customerFileHash=new Hashtable();
		customerFileHash.put("phone","");
		customerFileHash.put("socialShort","");
		customerFileHash.put("businessPhone","");
		customerFileHash.put("date","");
		boolean isPreapproved=false;
		boolean isValueBlank=true;
		customerFileVSFormBean=new CustomerFileVSFormBean();
		assertNotNull(customerFileVSFormBean.customerFileToRedesignAppForm(redesignOSBNForm,customerFileHash,isPreapproved,isValueBlank));
	}
	
	@Test
	 public void testcustomerFileToRedesignAppForm5(){
		redesignOSBNForm=new RedesignOSBNForm();
		Hashtable customerFileHash=new Hashtable();
		customerFileHash.put("phone","123-456-7890");
		customerFileHash.put("socialShort","123-456-7890");
		customerFileHash.put("businessPhone","123-456-7890");
		customerFileHash.put("date","12/12/2013");		
		customerFileHash.put("CompanyNameName","CTS");
		String value="123-456-7890";
		redesignOSBNForm.setPhone(value);
		boolean isPreapproved=false;
		boolean isValueBlank=true;		
		customerFileVSFormBean=new CustomerFileVSFormBean();
		assertNotNull(customerFileVSFormBean.customerFileToRedesignAppForm(redesignOSBNForm,customerFileHash,isPreapproved,isValueBlank));
	}
	
	 @Test
	 public void testsetRedesignFormFields(){
		 redesignOSBNForm=new RedesignOSBNForm();
		 customerFileVSFormBean=new CustomerFileVSFormBean();
		 String fieldName="fielName";
		 String fieldValue="fieldValue";
		 customerFileVSFormBean.setRedesignFormFields(redesignOSBNForm,fieldName,fieldValue);		 
	 }
	 
	 @Test
	 public void testgetFieldValue(){		 
		 customerFileVSFormBean=new CustomerFileVSFormBean();		
		 String name="fieldValue";
		 customerFileVSFormBean.getFieldValue(name);		 
	 }
	 
	 @Test
	 public void testallowOnlyDigits(){		 
		 customerFileVSFormBean=new CustomerFileVSFormBean();		
		 String phoneNumber="123-456-7890";
		 customerFileVSFormBean.allowOnlyDigits(phoneNumber);		 
	 }
	 @Test
	 public void testallowOnlyDigits1(){		 
		 customerFileVSFormBean=new CustomerFileVSFormBean();		
		 String phoneNumber="";
		 customerFileVSFormBean.allowOnlyDigits(phoneNumber);		 
	 }
	 
	 @Test
	 public void testcustomerFileToRedesignAppForm6(){
		redesignOSBNForm=new RedesignOSBNForm();
		Hashtable customerFileHash=new Hashtable();
		customerFileHash.put("phone","123-456-7890");
		customerFileHash.put("socialShort","123-456-7890");
		customerFileHash.put("businessPhone","123-456-7890");
		customerFileHash.put("date","12/12/2013");		
		customerFileHash.put("CompanyNameName","");
		String value="123-456-7890";
		redesignOSBNForm.setPhone(value);
		boolean isPreapproved=true;
		boolean isValueBlank=false;		
		customerFileVSFormBean=new CustomerFileVSFormBean();
		assertNotNull(customerFileVSFormBean.customerFileToRedesignAppForm(redesignOSBNForm,customerFileHash,isPreapproved,isValueBlank));
	}
	 @Test
	 public void testcustomerFileToRedesignAppForm7(){
		redesignOSBNForm=new RedesignOSBNForm();
		Hashtable customerFileHash=new Hashtable();
		customerFileHash.put("phone","123-456-7890");
		customerFileHash.put("socialShort","123-456-7890");
		customerFileHash.put("businessPhone","123-456-7890");
		customerFileHash.put("date","12/12/2013");		
		customerFileHash.put("CompanyNameName","");
		String value="123-456-7890";
		redesignOSBNForm.setPhone(value);
		boolean isPreapproved=true;
		boolean isValueBlank=false;		
		customerFileVSFormBean=new CustomerFileVSFormBean();
		assertNotNull(customerFileVSFormBean.customerFileToRedesignAppForm(redesignOSBNForm,customerFileHash,isPreapproved,isValueBlank));
	}
	 
}
