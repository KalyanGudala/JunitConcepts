/*
 * -------------------------------------------------------------------------
 *
 * (C) Copyright / American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.
 *
 * -------------------------------------------------------------------------
 */

package com.americanexpress.acquisitions.open.web.Test;



import static org.easymock.EasyMock.replay;
import static org.easymock.EasyMock.verify;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.Properties;

import com.americanexpress.acquisitions.open.commons.common.domain.BasicPage;
import com.americanexpress.acquisitions.open.web.managers.DTWManager;

import org.easymock.EasyMock;
import org.junit.Test;
/**
 * DTWManagerTest
 *
 * @author 387142
 * @version $Id$
 */

public class DTWManagerTest {
	
	DTWManager dtwmanager;	
	public String str="10-1-35";	
	Properties properties;
	
	@Test
	public void testgetDate(){
		dtwmanager=new DTWManager();
		String newdate="25-11-2013";
		assertNotNull(dtwmanager.getDate(newdate));
	}

	@Test
	public void testsetValuesintoBasicPage(){				
		dtwmanager=new DTWManager();
		properties=new Properties();
		BasicPage basicPage = EasyMock.createNiceMock(BasicPage.class);
		replay(basicPage);		
		assertNotNull(dtwmanager.setValuesintoBasicPage(properties));
		verify(basicPage);
	}
	
	@Test
	public void testsetValuesintoBasicPage1(){				
		dtwmanager=new DTWManager();
		properties=new Properties();
		properties.getProperty("cmrsvp");
		BasicPage basicPage = EasyMock.createNiceMock(BasicPage.class);
		replay(basicPage);		
		assertNotNull(dtwmanager.setValuesintoBasicPage(properties));
		verify(basicPage);
	}
		
	
			
	@Test
	public void testcheckFirstPOBox()
	{		
		dtwmanager=new DTWManager();
		assertNotNull(dtwmanager.checkFirstPOBox(str));
	}
	
	@Test
	public void testcheckFirstPOBox1()
	{		
		dtwmanager=new DTWManager();
		assertTrue(dtwmanager.checkFirstPOBox(""));
	}
	
		
	@Test
	public void testcheckFirstPOBox2()
	{		
		dtwmanager=new DTWManager();
		assertFalse(dtwmanager.checkFirstPOBox("PBox"));
	}
	
	@Test
	public void testcheckFirstPOBox3()
	{		
		dtwmanager=new DTWManager();
		assertFalse(dtwmanager.checkFirstPOBox("POBox"));
	}
	
	@Test
	public void testcheckFirstPOBox4()
	{		
		dtwmanager=new DTWManager();
		assertFalse(dtwmanager.checkFirstPOBox("P.O.BOX"));
	}
	
	@Test
	public void testcheckFirstPOBox5()
	{		
		dtwmanager=new DTWManager();
		assertFalse(dtwmanager.checkFirstPOBox("POSTOFFICEBOX"));
	}
	
	@Test
	public void testcheckFirstPOBox6()
	{		
		dtwmanager=new DTWManager();
		assertFalse(dtwmanager.checkFirstPOBox("POB"));
	}
	
	@Test
	public void testcheckFirstPOBox7()
	{		
		dtwmanager=new DTWManager();
		assertFalse(dtwmanager.checkFirstPOBox("BoX"));
	}
	
	@Test
	public void testcheckFirstPOBox8()
	{		
		dtwmanager=new DTWManager();
		assertFalse(dtwmanager.checkFirstPOBox("POSTOFFICEBOX"));
	}
 }
