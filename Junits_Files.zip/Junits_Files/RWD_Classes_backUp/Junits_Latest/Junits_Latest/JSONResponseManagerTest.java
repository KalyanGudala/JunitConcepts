/*
 * -------------------------------------------------------------------------
 *
 * (C) Copyright / American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.
 *
 * -------------------------------------------------------------------------
 */

package com.americanexpress.acquisitions.open.web.Test;

import static org.easymock.EasyMock.replay;
import static org.junit.Assert.assertNotNull;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.americanexpress.acquisitions.open.commons.common.constants.OPENConstants;
import com.americanexpress.acquisitions.open.commons.common.domain.SuppCardCollection;
import com.americanexpress.acquisitions.open.commons.formbeans.RedesignOSBNForm;
import com.americanexpress.acquisitions.open.commons.shortapp.cardservice.Eligiblecard;
import com.americanexpress.acquisitions.open.web.beans.CardMemberAppDTO;
import com.americanexpress.acquisitions.open.web.managers.JSONResponseManager;
import com.americanexpress.acquisitions.services.ccc.domain.AcquisitionResponse;
import org.easymock.EasyMock;
import org.junit.Test;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.verify;
/**
 * JSONResponseManagerTest
 *
 * @author 387142
 * @version $Id$
 */


public class JSONResponseManagerTest {
	
	public AcquisitionResponse acquisitionResponse;
	public JSONResponseManager jsonResponsemanager;
	public HttpSession session;
	public HttpServletRequest request;
	public CardMemberAppDTO cardMemberDTO;
	@Test
	public void testGetLongAppJSONResponse(){
		RedesignOSBNForm osbnform =new RedesignOSBNForm();
		acquisitionResponse= EasyMock.createNiceMock(AcquisitionResponse.class);
		request =EasyMock.createNiceMock(HttpServletRequest.class);
		replay(request);
		jsonResponsemanager=new JSONResponseManager();
		session = EasyMock.createNiceMock(HttpSession.class);		
		replay(acquisitionResponse);
		assertNotNull(jsonResponsemanager.getLongAppJSONResponse(osbnform,session));
		verify(request);
	}
	
	/*@Test(expected=Exception.class)
	public void testGetLongAppJSONResponse1() {
		RedesignOSBNForm osbnform =new RedesignOSBNForm();
		acquisitionResponse= EasyMock.createNiceMock(AcquisitionResponse.class);
		jsonResponsemanager=new JSONResponseManager();
		replay(acquisitionResponse);
		assertNotNull(jsonResponsemanager.getLongAppJSONResponse(osbnform,acquisitionResponse));
	}*/
	
	@Test
	public void testGetDTWJSONResponseNPA(){
		RedesignOSBNForm osbnform =new RedesignOSBNForm();
		boolean isNPA=false;
		acquisitionResponse= EasyMock.createNiceMock(AcquisitionResponse.class);
		jsonResponsemanager=new JSONResponseManager();
		replay(acquisitionResponse);
		assertNotNull(jsonResponsemanager.getDTWJSONResponse(osbnform,acquisitionResponse,isNPA));		
	}
	
	@Test
	public void testGetDTWJSONResponsePA(){
		RedesignOSBNForm osbnform =new RedesignOSBNForm();
		boolean isNPA=true;
		acquisitionResponse= EasyMock.createNiceMock(AcquisitionResponse.class);
		jsonResponsemanager=new JSONResponseManager();
		replay(acquisitionResponse);
		assertNotNull(jsonResponsemanager.getDTWJSONResponse(osbnform,acquisitionResponse,isNPA));		
	}
	
	@Test
	public void testgetShortAppJSONResponse1(){		
		jsonResponsemanager=new JSONResponseManager();
		boolean isCidRequired=true;
		Eligiblecard eligibleCard1=new Eligiblecard();
		eligibleCard1.setCardType("smallBusinessCard");
		Eligiblecard eligibleCard2=new Eligiblecard();
		eligibleCard2.setCardType("personalCard");
		ArrayList<Eligiblecard> arrayCards1= new ArrayList<Eligiblecard>();	
		arrayCards1.add(eligibleCard1);
		arrayCards1.add(eligibleCard2);		
		HashMap<String, List<Eligiblecard>> cards=new HashMap();		
		cards.put("smallBus_cards", arrayCards1);
		cards.put("personal_cards", arrayCards1);				
		assertNotNull(jsonResponsemanager.getShortAppJSONResponse(cards,isCidRequired));		
	}
	
	@Test
	public void testgetShortAppJSONResponse2(){		
		jsonResponsemanager=new JSONResponseManager();				
		Eligiblecard eligibleCard1=new Eligiblecard();
		eligibleCard1.setCardType("smallBusinessCard");
		Eligiblecard eligibleCard2=new Eligiblecard();
		eligibleCard2.setCardType("personalCard");
		ArrayList<Eligiblecard> arrayCards1= new ArrayList<Eligiblecard>();	
		arrayCards1.add(eligibleCard1);
		arrayCards1.add(eligibleCard2);		
		HashMap<String, List<Eligiblecard>> cards=new HashMap();		
		cards.put("smallBus_cards", arrayCards1);
		cards.put("personal_cards", arrayCards1);
		boolean isCidRequired=false;		
		assertNotNull(jsonResponsemanager.getShortAppJSONResponse(cards,isCidRequired));	
	}

	@Test
	public void testgetShortAppJSONResponse3(){		
		jsonResponsemanager=new JSONResponseManager();			
		ArrayList<Eligiblecard> arrayCards1= new ArrayList<Eligiblecard>();					
		HashMap<String, List<Eligiblecard>> cards=new HashMap();		
		cards.put("smallBus_cards", arrayCards1);
		cards.put("personal_cards", arrayCards1);		
		boolean isCidRequired=false;		
		assertNotNull(jsonResponsemanager.getShortAppJSONResponse(cards,isCidRequired));	
	}
	
	@Test
	public void testgetShortAppJSONResponse4(){		
		jsonResponsemanager=new JSONResponseManager();								
		HashMap<String, List<Eligiblecard>> cards=new HashMap();		
		cards.size();
		boolean isCidRequired=false;		
		assertNotNull(jsonResponsemanager.getShortAppJSONResponse(cards,isCidRequired));	
	}
	
	@Test
	public void testgetShortAppJSONResponse5(){		
		jsonResponsemanager=new JSONResponseManager();			
		ArrayList<Eligiblecard> arrayCards1= new ArrayList<Eligiblecard>();					
		HashMap<String, List<Eligiblecard>> cards=new HashMap();		
		cards.put("smallBus_cards", arrayCards1);
		cards.put("personal_cards", arrayCards1);		
		boolean isCidRequired=true;		
		assertNotNull(jsonResponsemanager.getShortAppJSONResponse(cards,isCidRequired));	
	}
	
	@Test
	public void testgetShortAppJSONResponse6(){		
		jsonResponsemanager=new JSONResponseManager();								
		HashMap<String, List<Eligiblecard>> cards=new HashMap();		
		cards.size();
		boolean isCidRequired=true;		
		assertNotNull(jsonResponsemanager.getShortAppJSONResponse(cards,isCidRequired));	
	}
	
	@Test
	public void testgetShortAppJSONResponse7(){		
		jsonResponsemanager=new JSONResponseManager();
		Eligiblecard eligibleCard1=new Eligiblecard();
		eligibleCard1.setCardType("smallBusinessCard");
		eligibleCard1.setAccountNumber("1234567");
		ArrayList<Eligiblecard> arrayCards1= new ArrayList<Eligiblecard>();
		arrayCards1.add(eligibleCard1);
		HashMap<String, List<Eligiblecard>> cards=new HashMap();		
		cards.put("smallBus_cards", arrayCards1);				
		boolean isCidRequired=false;		
		assertNotNull(jsonResponsemanager.getShortAppJSONResponse(cards,isCidRequired));	
	}
	
	@Test
	public void testgetShortAppJSONResponse8(){		
		jsonResponsemanager=new JSONResponseManager();
		Eligiblecard eligibleCard1=new Eligiblecard();
		eligibleCard1.setCardType("personalCard");
		eligibleCard1.setAccountNumber("1234567");
		ArrayList<Eligiblecard> arrayCards1= new ArrayList<Eligiblecard>();
		arrayCards1.add(eligibleCard1);
		HashMap<String, List<Eligiblecard>> cards=new HashMap();		
		cards.put("personal_cards", arrayCards1);				
		boolean isCidRequired=false;		
		assertNotNull(jsonResponsemanager.getShortAppJSONResponse(cards,isCidRequired));	
	}
		
	@Test
	public void testgetSuppAppJSONResponse(){
		RedesignOSBNForm osbnform =new RedesignOSBNForm();
		SuppCardCollection collection=new SuppCardCollection();
		acquisitionResponse= EasyMock.createNiceMock(AcquisitionResponse.class);
		jsonResponsemanager=new JSONResponseManager();
		replay(acquisitionResponse);		
		assertNotNull(jsonResponsemanager.getSuppAppJSONResponse(osbnform,acquisitionResponse,collection));
	}
	
	@Test
	public void testgetSuppAppJSONResponse1(){
		RedesignOSBNForm osbnform =new RedesignOSBNForm();
		SuppCardCollection collection=new SuppCardCollection();
		acquisitionResponse= EasyMock.createNiceMock(AcquisitionResponse.class);
		jsonResponsemanager=new JSONResponseManager();
		replay(acquisitionResponse);
		int counter = 1;
		assertNotNull(jsonResponsemanager.getSuppAppJSONResponse(osbnform,acquisitionResponse,collection));
	}
			
	@Test
	public void testgetLongPrefillJSON1(){
		cardMemberDTO=new CardMemberAppDTO();		
		cardMemberDTO.setMycaLoggedIn("Y");
		RedesignOSBNForm osbnform =new RedesignOSBNForm();
		request =EasyMock.createNiceMock(HttpServletRequest.class);
		replay(request);		
		session = EasyMock.createNiceMock(HttpSession.class);		
		expect(session.getAttribute(OPENConstants.CARDMEMBERAPP_DTO)).andReturn(cardMemberDTO);
		replay(session);		
		jsonResponsemanager=new JSONResponseManager();			
		boolean isIntlUser=true;
		boolean isSsnFtdOptional=true;		
		session.setAttribute(OPENConstants.CARDMEMBERAPP_DTO, cardMemberDTO);
		assertNotNull(jsonResponsemanager.getLongPrefillJSON(osbnform, isIntlUser, isSsnFtdOptional,session));		
		verify(request);		
	}
	
	@Test
	public void testgetLongPrefillJSON2(){
		cardMemberDTO=new CardMemberAppDTO();
		cardMemberDTO.setMycaLoggedIn("Y");
		RedesignOSBNForm osbnform =new RedesignOSBNForm();
		request =EasyMock.createNiceMock(HttpServletRequest.class);
		replay(request);		
		session = EasyMock.createNiceMock(HttpSession.class);		
		expect(session.getAttribute(OPENConstants.CARDMEMBERAPP_DTO)).andReturn(cardMemberDTO);
		replay(session);		
		jsonResponsemanager=new JSONResponseManager();			
		boolean isIntlUser=false;
		boolean isSsnFtdOptional=false;		
		session.setAttribute(OPENConstants.CARDMEMBERAPP_DTO, cardMemberDTO);
		assertNotNull(jsonResponsemanager.getLongPrefillJSON(osbnform, isIntlUser, isSsnFtdOptional,session));		
		verify(request);		
	}
	
	@Test
	public void testgetLongPrefillJSON3(){
		cardMemberDTO=new CardMemberAppDTO();
		cardMemberDTO.setMycaLoggedIn("N");
		RedesignOSBNForm osbnform =new RedesignOSBNForm();
		request =EasyMock.createNiceMock(HttpServletRequest.class);
		replay(request);		
		session = EasyMock.createNiceMock(HttpSession.class);		
		expect(session.getAttribute(OPENConstants.CARDMEMBERAPP_DTO)).andReturn(cardMemberDTO);
		replay(session);		
		jsonResponsemanager=new JSONResponseManager();			
		boolean isIntlUser=false;
		boolean isSsnFtdOptional=true;		
		session.setAttribute(OPENConstants.CARDMEMBERAPP_DTO, cardMemberDTO);
		assertNotNull(jsonResponsemanager.getLongPrefillJSON(osbnform, isIntlUser, isSsnFtdOptional,session));		
		verify(request);		
	}
	
	@Test
	public void testgetObscenityJSONResponse(){
		HashMap obsErrors=new HashMap();
		obsErrors.put("error", "errorvalue");
		jsonResponsemanager=new JSONResponseManager();
		assertNotNull(jsonResponsemanager.getObscenityJSONResponse(obsErrors));		
	}
	
	@Test
	public void testgetObscenityJSONResponse1(){
		HashMap obsErrors=new HashMap();
		obsErrors=null;
		jsonResponsemanager=new JSONResponseManager();
		assertNotNull(jsonResponsemanager.getObscenityJSONResponse(obsErrors));		
	}
	
	@Test
	public void testgetObscenityJSONResponse2(){
		HashMap obsErrors=new HashMap();		
		obsErrors.size();
		jsonResponsemanager=new JSONResponseManager();
		assertNotNull(jsonResponsemanager.getObscenityJSONResponse(obsErrors));		
	}
	
	@Test
	public void testgetErrorJSONResponse(){
		HashMap<String, String> errorMap=new HashMap();		
		errorMap.put("errorkey", "erroValue");
		jsonResponsemanager=new JSONResponseManager();
		assertNotNull(jsonResponsemanager.getErrorJSONResponse(errorMap));		
	}
	@Test
	public void testgetErrorJSONResponse1(){
		HashMap<String, String> errorMap=new HashMap();				
		jsonResponsemanager=new JSONResponseManager();
		assertNotNull(jsonResponsemanager.getErrorJSONResponse(errorMap));		
	}
	
	@Test
	public void testgetStableUserJSONResponse(){
		jsonResponsemanager=new JSONResponseManager();
		assertNotNull(jsonResponsemanager.getStableUserJSONResponse());
	}
}
